use l8p_json::{canonical_encode, decode, signing_payload, DecodeError, Limits, Value};

fn lim() -> Limits {
    Limits::default()
}

// ---- JSON-01..08: canonical acceptance / rejection basics ----

#[test]
fn json_01_accepts_minimal_object() {
    let v = decode(br#"{"a":1,"b":null}"#, &lim()).unwrap();
    assert_eq!(
        v,
        Value::Object(vec![
            ("a".into(), Value::Integer(1)),
            ("b".into(), Value::Null),
        ])
    );
}

#[test]
fn json_02_rejects_any_whitespace() {
    // Whitespace *inside* a value's grammar -> NonCanonicalWhitespace.
    // (Whitespace trailing a fully-parsed top-level value is instead
    // caught by the top-level TrailingBytes check — see json_08.)
    let cases: &[&[u8]] = &[
        br#"{ "a":1}"#,
        br#"{"a": 1}"#,
        br#"{"a":1 }"#,
        b"[1, 2]",
        b" [1,2]",
    ];
    for c in cases {
        let err = decode(c, &lim()).unwrap_err();
        assert!(
            matches!(err, DecodeError::NonCanonicalWhitespace { .. }),
            "expected NonCanonicalWhitespace for {:?}, got {:?}",
            std::str::from_utf8(c),
            err
        );
    }
}

#[test]
fn json_03_rejects_duplicate_keys() {
    let err = decode(br#"{"a":1,"a":2}"#, &lim()).unwrap_err();
    assert!(matches!(err, DecodeError::DuplicateKey { .. }));
}

#[test]
fn json_04_rejects_out_of_order_keys() {
    let err = decode(br#"{"b":1,"a":2}"#, &lim()).unwrap_err();
    assert!(matches!(err, DecodeError::NonCanonicalKeyOrder { .. }));
}

#[test]
fn json_05_rejects_leading_zero() {
    for c in [&b"01"[..], b"-01", b"[01]"] {
        let err = decode(c, &lim()).unwrap_err();
        assert!(matches!(err, DecodeError::InvalidNumber { .. }), "{:?} -> {:?}", c, err);
    }
}

#[test]
fn json_06_rejects_negative_zero() {
    let err = decode(b"-0", &lim()).unwrap_err();
    assert!(matches!(err, DecodeError::InvalidNumber { .. }));
}

#[test]
fn json_07_rejects_floats() {
    for c in [&b"1.5"[..], b"1e10", b"1E10", b"[1.0]"] {
        let err = decode(c, &lim()).unwrap_err();
        assert!(matches!(err, DecodeError::FloatNotAllowed { .. }), "{:?} -> {:?}", c, err);
    }
}

#[test]
fn json_08_rejects_trailing_bytes() {
    let err = decode(b"1 ", &lim()).unwrap_err();
    // Whitespace check fires first inside parse_value's dispatch only
    // for values; here it's genuinely trailing content after a complete
    // top-level value, so this must be TrailingBytes, not a value-parse
    // error, confirming the top-level trailing check is reachable and
    // distinct from in-value whitespace rejection.
    assert!(matches!(err, DecodeError::TrailingBytes { .. }));
    let err2 = decode(b"1junk", &lim()).unwrap_err();
    assert!(matches!(err2, DecodeError::TrailingBytes { .. }));
}

// ---- JSON-09..12: string escaping canonicality ----

#[test]
fn json_09_rejects_escaped_solidus() {
    let err = decode(br#""\/""#, &lim()).unwrap_err();
    assert!(matches!(err, DecodeError::NonCanonicalEscape { .. }));
}

#[test]
fn json_10_rejects_unnecessary_unicode_escape() {
    // 'A' (0x41) never needs escaping.
    let err = decode(br#""\u0041""#, &lim()).unwrap_err();
    assert!(matches!(err, DecodeError::NonCanonicalEscape { .. }));
}

#[test]
fn json_11_rejects_non_minimal_control_escape() {
    // \n has a short form; \u000a is valid JSON but non-canonical.
    let err = decode(br#""\u000a""#, &lim()).unwrap_err();
    assert!(matches!(err, DecodeError::NonCanonicalEscape { .. }));
}

#[test]
fn json_12_accepts_minimal_control_escape_and_rejects_literal_control() {
    let v = decode(br#""\n""#, &lim()).unwrap();
    assert_eq!(v, Value::Str("\n".to_string()));
    let err = decode(b"\"\x01\"", &lim()).unwrap_err();
    assert!(matches!(err, DecodeError::UnescapedControlChar { .. }));
}

#[test]
fn json_13_accepts_required_short_form_for_uncommon_control_code() {
    // 0x01 has no short form; \u0001 IS the canonical minimal form.
    let v = decode(br#""\u0001""#, &lim()).unwrap();
    assert_eq!(v, Value::Str("\u{1}".to_string()));
}

#[test]
fn json_14_rejects_lone_high_surrogate_pair_as_noncanonical() {
    // A valid UTF-16 surrogate pair for an astral character is always
    // non-canonical: direct UTF-8 is always shorter and always available.
    let err = decode(br#""\ud83d\ude00""#, &lim()).unwrap_err();
    assert!(matches!(err, DecodeError::NonCanonicalEscape { .. }));
}

#[test]
fn json_15_rejects_lone_low_surrogate() {
    let err = decode(br#""\udc00""#, &lim()).unwrap_err();
    assert!(matches!(err, DecodeError::InvalidEscape { .. }));
}

// ---- JSON-16..19: bounds ----

#[test]
fn json_16_rejects_depth_beyond_limit() {
    let l = Limits { max_depth: 3, ..Limits::default() };
    let ok = b"[[[1]]]"; // depth 3
    assert!(decode(ok, &l).is_ok());
    let bad = b"[[[[1]]]]"; // depth 4
    let err = decode(bad, &l).unwrap_err();
    assert!(matches!(err, DecodeError::DepthLimitExceeded { .. }));
}

#[test]
fn json_17_rejects_array_beyond_element_limit() {
    let l = Limits { max_array_elems: 2, ..Limits::default() };
    assert!(decode(b"[1,2]", &l).is_ok());
    let err = decode(b"[1,2,3]", &l).unwrap_err();
    assert!(matches!(err, DecodeError::ArrayTooLong { .. }));
}

#[test]
fn json_18_rejects_object_beyond_entry_limit() {
    let l = Limits { max_object_entries: 1, ..Limits::default() };
    assert!(decode(br#"{"a":1}"#, &l).is_ok());
    let err = decode(br#"{"a":1,"b":2}"#, &l).unwrap_err();
    assert!(matches!(err, DecodeError::ObjectTooLong { .. }));
}

#[test]
fn json_19_rejects_input_beyond_total_size_budget() {
    let l = Limits { max_total_bytes: 4, ..Limits::default() };
    let err = decode(b"[1,2]", &l).unwrap_err();
    assert!(matches!(err, DecodeError::InputTooLarge));
}

#[test]
fn json_20_rejects_string_beyond_length_limit() {
    let l = Limits { max_string_bytes: 4, ..Limits::default() };
    let err = decode(br#""abcdefgh""#, &l).unwrap_err();
    assert!(matches!(err, DecodeError::StringTooLong { .. }));
}

// ---- JSON-21..24: truncation at every prefix of a valid object ----

#[test]
fn json_21_truncation_at_every_prefix_never_panics_and_is_determinate() {
    let full = br#"{"a":1,"b":[2,3],"c":"x\n"}"#;
    for i in 0..full.len() {
        let prefix = &full[..i];
        let r1 = decode(prefix, &lim());
        let r2 = decode(prefix, &lim());
        assert_eq!(r1, r2, "nondeterministic result at prefix len {}", i);
        assert!(r1.is_err(), "prefix len {} unexpectedly decoded", i);
    }
    assert!(decode(full, &lim()).is_ok());
}

// ---- JSON-22: single-byte mutation fuzz over a valid object, no panics ----

#[test]
fn json_22_single_byte_mutation_never_panics() {
    let full = br#"{"a":1,"b":[2,3],"c":"xy"}"#.to_vec();
    for i in 0..full.len() {
        for delta in [1u8, 37, 129, 255] {
            let mut mutated = full.clone();
            mutated[i] = mutated[i].wrapping_add(delta);
            let _ = decode(&mutated, &lim()); // must not panic
        }
    }
}

// ---- JSON-23: deterministic PRNG fuzz, bounded input, no panics ----

#[test]
fn json_23_prng_fuzz_no_panics() {
    // xorshift32, fixed seed -> fully reproducible across runs (I7-style
    // determinism-on-repeat, applied to the fuzz harness itself).
    let mut state: u32 = 0x9E3779B9;
    let mut next = move || {
        state ^= state << 13;
        state ^= state >> 17;
        state ^= state << 5;
        state
    };
    for _ in 0..3000 {
        let len = (next() % 40) as usize;
        let bytes: Vec<u8> = (0..len).map(|_| (next() % 256) as u8).collect();
        let _ = decode(&bytes, &lim());
    }
}

// ---- JSON-24: canonical round trip (I5) ----

#[test]
fn json_24_decode_then_encode_round_trips_byte_identical() {
    let cases: &[&[u8]] = &[
        br#"{"a":1,"b":[true,false,null],"c":"line\n\u0001"}"#,
        b"[]",
        br#"{}"#,
        br#""hello world""#,
        b"-123456789",
        b"0",
    ];
    for c in cases {
        let v = decode(c, &lim()).unwrap();
        let re = canonical_encode(&v);
        assert_eq!(re.as_slice(), *c, "round trip mismatch for {:?}", std::str::from_utf8(c));
    }
}

#[test]
fn json_25_encoder_sorts_keys_regardless_of_construction_order() {
    let v = Value::Object(vec![
        ("z".into(), Value::Integer(1)),
        ("a".into(), Value::Integer(2)),
    ]);
    let bytes = canonical_encode(&v);
    assert_eq!(bytes, br#"{"a":2,"z":1}"#);
    // and it must decode back cleanly, in canonical (sorted) order —
    // Value::Object equality is structural/order-sensitive, so compare
    // against the sorted form, not the as-constructed form.
    let back = decode(&bytes, &lim()).unwrap();
    let sorted = Value::Object(vec![
        ("a".into(), Value::Integer(2)),
        ("z".into(), Value::Integer(1)),
    ]);
    assert_eq!(back, sorted);
}

// ---- JSON-26..28: signing payload construction ----

#[test]
fn json_26_signing_payload_excludes_named_keys_and_is_deterministic() {
    let a = decode(br#"{"claim":1,"sig":"AAAA","wit":[]}"#, &lim()).unwrap();
    let b = decode(br#"{"claim":1,"sig":"BBBB","wit":["x"]}"#, &lim()).unwrap();
    let ha = signing_payload(&a, &["sig", "auth_sig", "wit"]).unwrap();
    let hb = signing_payload(&b, &["sig", "auth_sig", "wit"]).unwrap();
    assert_eq!(ha, hb, "signing payload must not depend on excluded fields");

    let c = decode(br#"{"claim":2,"sig":"AAAA","wit":[]}"#, &lim()).unwrap();
    let hc = signing_payload(&c, &["sig", "auth_sig", "wit"]).unwrap();
    assert_ne!(ha, hc, "signing payload must depend on non-excluded fields");
}

#[test]
fn json_27_signing_payload_matches_direct_blake3_of_stripped_canonical_bytes() {
    let full = decode(br#"{"a":1,"sig":"AAAA"}"#, &lim()).unwrap();
    let stripped_bytes = canonical_encode(&decode(br#"{"a":1}"#, &lim()).unwrap());
    let expected = l8p_json::blake3_hash(&stripped_bytes);
    let got = signing_payload(&full, &["sig", "auth_sig", "wit"]).unwrap();
    assert_eq!(got, expected);
}

#[test]
fn json_28_signing_payload_rejects_non_object() {
    let v = decode(b"[1,2,3]", &lim()).unwrap();
    assert!(signing_payload(&v, &["sig"]).is_err());
}

// ---- JSON-29: no float variant exists at the type level (I8) ----

#[test]
fn json_29_value_type_has_no_float_variant() {
    // Compile-time guarantee: this match is exhaustive over exactly six
    // variants. If a Float variant were ever added to Value, this match
    // would fail to compile until updated, making the guarantee visible
    // here rather than silently stale.
    fn describe(v: &Value) -> &'static str {
        match v {
            Value::Null => "null",
            Value::Bool(_) => "bool",
            Value::Integer(_) => "integer",
            Value::Str(_) => "string",
            Value::Array(_) => "array",
            Value::Object(_) => "object",
        }
    }
    assert_eq!(describe(&Value::Integer(1)), "integer");
}

// ---- JSON-30: differential check against a second, independent decode of the same bytes ----

#[test]
fn json_30_repeated_decode_is_deterministic() {
    let bytes = br#"{"a":[1,2,3],"b":{"c":null,"d":true}}"#;
    let r1 = decode(bytes, &lim());
    let r2 = decode(bytes, &lim());
    assert_eq!(r1, r2);
}
