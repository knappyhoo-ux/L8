//! Proves the canonical map-key ordering fix is real, not just a docs claim. RFC 8785 (JCS)
//! mandates UTF-16 code-UNIT order for object keys; this crate previously used plain UTF-8
//! byte order (== Unicode code-point order for all valid strings), which genuinely diverges
//! from JCS order for keys mixing a supplementary-plane character (>= U+10000, a UTF-16
//! surrogate pair starting at 0xD800) against a BMP character in U+E000..=U+FFFF.
use l8p_json::{canonical_encode, decode, DecodeError, Limits, Value as V};

const SUPP: char = '\u{10000}'; // encodes to UTF-16 surrogate pair [0xD800, 0xDC00]
const BMP_HIGH: char = '\u{E000}'; // encodes to a single UTF-16 unit 0xE000

#[test]
fn utf16_order_genuinely_diverges_from_utf8_byte_order_for_this_pair() {
    // Sanity check on the premise itself, independent of this crate: if these two orderings
    // didn't actually disagree for this pair, the whole test would be pointless.
    let byte_order = SUPP.to_string().into_bytes().cmp(&BMP_HIGH.to_string().into_bytes());
    let utf16_order = SUPP.to_string().encode_utf16().collect::<Vec<u16>>()
        .cmp(&BMP_HIGH.to_string().encode_utf16().collect::<Vec<u16>>());
    assert_eq!(byte_order, std::cmp::Ordering::Greater, "UTF-8 byte order: SUPP > BMP_HIGH");
    assert_eq!(utf16_order, std::cmp::Ordering::Less, "UTF-16 code-unit order: SUPP < BMP_HIGH (the actual divergence)");
}

fn obj(pairs: Vec<(char, i64)>) -> V {
    V::Object(pairs.into_iter().map(|(k, v)| (k.to_string(), V::Integer(v))).collect())
}

#[test]
fn encoder_sorts_keys_in_jcs_utf16_order_not_byte_order() {
    // SUPP < BMP_HIGH in JCS order, so SUPP must come first in the encoded output, even though
    // it would come SECOND under plain UTF-8 byte ordering.
    let encoded = canonical_encode(&obj(vec![(BMP_HIGH, 2), (SUPP, 1)]));
    let text = String::from_utf8(encoded).unwrap();
    let supp_pos = text.find(SUPP).unwrap();
    let bmp_pos = text.find(BMP_HIGH).unwrap();
    assert!(supp_pos < bmp_pos, "expected the supplementary-plane key first under JCS order, got: {}", text);
}

#[test]
fn decoder_accepts_jcs_order_and_rejects_byte_order_for_the_same_pair() {
    let jcs_order_bytes = canonical_encode(&obj(vec![(SUPP, 1), (BMP_HIGH, 2)])); // SUPP first: correct
    assert!(decode(&jcs_order_bytes, &Limits::default()).is_ok(), "canonical (JCS) key order must decode");

    // Manually construct the BYTE-order variant (BMP_HIGH first) -- this is what the old,
    // buggy comparator would have accepted as "canonical". It must now be rejected.
    let byte_order_text = format!("{{\"{0}\":2,\"{1}\":1}}", BMP_HIGH, SUPP);
    let err = decode(byte_order_text.as_bytes(), &Limits::default()).unwrap_err();
    assert!(matches!(err, DecodeError::NonCanonicalKeyOrder { .. }), "expected NonCanonicalKeyOrder, got {:?}", err);
}

#[test]
fn round_trip_still_holds_for_ascii_only_keys() {
    // The fix must not disturb the common case: every L8P protocol field name is ASCII, where
    // UTF-16 order and UTF-8 byte order always agree.
    let v = obj(vec![]);
    let _ = v; // keep obj() exercised for non-char-literal keys too, below
    let encoded = canonical_encode(&V::Object(vec![
        ("ver".into(), V::Str("L8/1.0".into())),
        ("id".into(), V::Str("x".into())),
        ("sub".into(), V::Str("agent://x".into())),
    ]));
    let decoded = decode(&encoded, &Limits::default()).unwrap();
    assert_eq!(canonical_encode(&decoded), encoded);
}

/// Manual cross-language check (mirrors the succession-attestation one in
/// h1_port_integration.rs): no-ops if /tmp/py_jcs_key_test.bin wasn't produced by the Python
/// snippet in this session's notes first. Confirmed passing 2026-09-30: Rust and Python emit
/// byte-identical output for a `{BMP_HIGH: 2, SUPP: 1}` object under the corrected JCS order.
#[test]
fn python_and_rust_agree_byte_for_byte_on_non_ascii_key_order() {
    let py_bytes = match std::fs::read("/tmp/py_jcs_key_test.bin") {
        Ok(b) => b,
        Err(_) => return, // manual cross-check only, run the Python snippet first
    };
    let rust_bytes = canonical_encode(&obj(vec![(BMP_HIGH, 2), (SUPP, 1)]));
    assert_eq!(rust_bytes, py_bytes, "Rust and Python must agree byte-for-byte on JCS key order");
}
