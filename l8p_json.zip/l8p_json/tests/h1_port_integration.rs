//! Real end-to-end evidence that H1.3 (failure preservation) + H1.4 (Ed25519 verification,
//! checkpoints) port cleanly onto the REAL l8p_json crate (not a reconstruction). No envelope
//! framing exists here (unlike the CBOR-era crate) -- attestations are self-delimiting
//! canonical JSON, so `Gate::admit` and friends operate on raw bytes directly.
#![cfg(feature = "reference-signer")]

use l8p_json::crypto::ed25519::{public_key_from_seed, sign_reference};
use l8p_json::crypto::encode_b64url;
use l8p_json::emit::checkpoint::{check_freshness, check_log_against_checkpoint, parse_checkpoint};
use l8p_json::emit::{EmitConfig, Emitter, ReferenceSigner};
use l8p_json::failure::{Admission, FailureKind, Gate, LogConfig};
use l8p_json::validation_error::ValidationError;
use l8p_json::hash::signing_payload;
use l8p_json::verify::SigCode;
use l8p_json::{canonical_encode, DecodeError, Limits, Value as V};

fn txt(s: &str) -> V { V::Str(s.to_string()) }
fn kvs(pairs: Vec<(&str, V)>) -> V { V::Object(pairs.into_iter().map(|(k, v)| (k.to_string(), v)).collect()) }
fn b64(d: &[u8]) -> V { V::Str(encode_b64url(d)) }
fn uuid_from(d: &[u8]) -> String {
    let mut b = [0u8; 16];
    b.copy_from_slice(&d[..16]);
    b[6] = (b[6] & 0x0f) | 0x80;
    b[8] = (b[8] & 0x3f) | 0x80;
    let h: String = b.iter().map(|x| format!("{:02x}", x)).collect();
    format!("{}-{}-{}-{}-{}", &h[0..8], &h[8..12], &h[12..16], &h[16..20], &h[20..32])
}

/// Build a real, correctly dual-signed `succession` attestation: rotation from `old_seed` to `new_seed`.
fn build_succession(old_seed: [u8; 32], new_seed: [u8; 32]) -> Vec<u8> {
    let old_pk = public_key_from_seed(&old_seed);
    let new_pk = public_key_from_seed(&new_seed);
    let body = kvs(vec![
        ("prev_pk", b64(&old_pk)),
        ("next_pk", b64(&new_pk)),
        ("prev_fp", b64(&old_pk)),
        ("next_fp", b64(&new_pk)),
        ("reason", txt("key_rotation")),
        ("scope_unchanged", V::Bool(true)),
    ]);
    let fields = vec![
        ("ver", txt("L8/1.0")),
        ("id", txt(&uuid_from(&[7u8; 32]))),
        ("sub", txt("agent://test-identity")),
        ("claim", kvs(vec![("type", txt("succession")), ("body", body)])),
        ("ts_unix_ns", V::Integer(1_800_000_000_000_000_000)),
        ("ts_rfc3339", txt("2026-09-25T00:00:00.000000000Z")),
        ("prev", V::Null),
        ("pk", b64(&new_pk)),
        ("wit", V::Array(vec![])),
        ("meta", kvs(vec![("sentinel", txt("test")), ("scope", txt("test")), ("env", txt("test"))])),
    ];
    let unsigned = kvs(fields.clone());
    let payload = signing_payload(&unsigned, &["sig", "auth_sig", "wit"]).expect("object payload");
    let sig = sign_reference(&new_seed, &payload);
    let auth_sig = sign_reference(&old_seed, &payload);
    let mut signed = fields;
    signed.push(("sig", b64(&sig)));
    signed.push(("auth_sig", b64(&auth_sig)));
    canonical_encode(&kvs(signed))
}

#[test]
fn valid_succession_is_accepted() {
    let bytes = build_succession([1u8; 32], [2u8; 32]);
    let mut gate = Gate::new_verifying(Limits::default(), LogConfig::default());
    match gate.admit(&bytes) {
        Admission::Accepted(_) => {}
        other => panic!("expected acceptance, got {:?}", other),
    }
    assert_eq!(gate.accepted_count(), 1);
}

#[test]
fn corrupted_signature_is_rejected_and_preserved_in_the_failure_log() {
    let mut bytes = build_succession([3u8; 32], [4u8; 32]);
    let marker = b"\"sig\":\"";
    let start = bytes.windows(marker.len()).position(|w| w == marker).expect("sig field present") + marker.len();
    bytes[start + 2] ^= 0x01;
    let mut gate = Gate::new_verifying(Limits::default(), LogConfig::default());
    match gate.admit(&bytes) {
        Admission::Rejected { seq } => {
            assert_eq!(seq, 0);
            let rec = gate.log().records().next().unwrap();
            match &rec.kind {
                FailureKind::Signature(e) if matches!(e.code, SigCode::SignatureInvalid | SigCode::AuthSignatureInvalid) => {}
                other => panic!("expected a signature failure, got {:?}", other),
            }
        }
        other => panic!("expected rejection, got {:?}", other),
    }
    assert_eq!(gate.accepted_count(), 0);
}

#[test]
fn non_canonical_json_is_rejected_at_the_wire_layer() {
    let mut gate = Gate::new(Limits::default(), LogConfig::default());
    match gate.admit(b"{ \"a\":1}") {
        Admission::Rejected { .. } => {
            let rec = gate.log().records().next().unwrap();
            assert!(matches!(rec.kind, FailureKind::Wire(DecodeError::NonCanonicalWhitespace { .. })), "got {:?}", rec.kind);
        }
        other => panic!("expected rejection, got {:?}", other),
    }
}

#[test]
fn missing_required_field_is_rejected_at_the_structure_layer() {
    let mut gate = Gate::new(Limits::default(), LogConfig::default());
    match gate.admit(&canonical_encode(&V::Object(vec![]))) {
        Admission::Rejected { .. } => {
            let rec = gate.log().records().next().unwrap();
            match &rec.kind {
                FailureKind::Structure(ValidationError::MissingField(_)) => {}
                other => panic!("expected MissingField, got {:?}", other),
            }
        }
        other => panic!("expected rejection, got {:?}", other),
    }
}

fn signer_and_cfg(seed: [u8; 32], name: &str) -> (ReferenceSigner, EmitConfig) {
    (ReferenceSigner::from_seed(seed), EmitConfig {
        subject: format!("agent://{}", name), sentinel: "test".into(), scope: "test".into(), env: "test".into(),
    })
}

#[test]
fn emitted_anomaly_attestations_pass_the_crate_own_verifying_gate() {
    let mut gate = Gate::new(Limits::default(), LogConfig::default());
    let _ = gate.admit(b"{ \"a\":1}");
    let _ = gate.admit(&canonical_encode(&V::Object(vec![])));

    let (signer, cfg) = signer_and_cfg([9u8; 32], "emitter-test");
    let mut emitter = Emitter::new(cfg, signer).expect("valid config");
    let batch = emitter.emit_pending(gate.log(), 1_800_000_000_000_000_000);
    assert!(batch.error.is_none(), "emission should not fail: {:?}", batch.error);
    assert_eq!(batch.attestations.len(), 2);

    let mut verifying = Gate::new_verifying(Limits::default(), LogConfig::default());
    for att in &batch.attestations {
        match verifying.admit(att) {
            Admission::Accepted(_) => {}
            other => panic!("emitted attestation should verify against its own signer: {:?}", other),
        }
    }
}

#[test]
fn checkpoint_round_trips_and_detects_truncation() {
    let mut gate = Gate::new(Limits::default(), LogConfig::default());
    let _ = gate.admit(b"{ \"a\":1}");
    let _ = gate.admit(&canonical_encode(&V::Object(vec![])));

    let emitter_seed = [11u8; 32];
    let emitter_pk = public_key_from_seed(&emitter_seed);
    let (signer, cfg) = signer_and_cfg(emitter_seed, "checkpoint-test");
    let mut emitter = Emitter::new(cfg, signer).expect("valid config");
    let cp_bytes = emitter.emit_checkpoint(gate.log(), 1_800_000_000_000_000_000).expect("checkpoint signs");

    let cp = parse_checkpoint(&cp_bytes, &emitter_pk).expect("checkpoint parses and verifies");
    assert_eq!(cp.total_rejected, 2);

    let full_snapshot = gate.log().snapshot();
    check_log_against_checkpoint(&full_snapshot, &cp).expect("full log matches its own checkpoint");

    let mut truncated = full_snapshot.clone();
    truncated.records.pop();
    truncated.next_seq -= 1;
    truncated.head = truncated.records.last().unwrap().digest;
    let err = check_log_against_checkpoint(&truncated, &cp).unwrap_err();
    assert!(matches!(err, l8p_json::emit::checkpoint::LogCheckError::Truncated));

    let stale = parse_checkpoint(&cp_bytes, &emitter_pk).unwrap();
    check_freshness(Some(&stale), &cp).expect("identical checkpoint is not a rollback");
}

/// Manual cross-language check, not part of the normal suite: run the Python snippet in
/// l8p_json_py's session notes to produce /tmp/py_succession.json, then `cargo test --ignored
/// python_built`. Confirmed passing this session (2026-09-30) in both directions: Rust-built
/// attestations verify in Python (cryptography lib) and Python-built ones verify in Rust
/// (hand-rolled Ed25519) -- canonical encoding, signing_payload exclusion set, and BLAKE3 all
/// agree byte-for-byte across the two implementations for this new failure/emit/verify layer.
#[test]
#[ignore]
fn python_built_succession_attestation_verifies_in_rust() {
    let raw = std::fs::read("/tmp/py_succession.json").expect("python side must run first");
    let mut gate = Gate::new_verifying(Limits::default(), LogConfig::default());
    match gate.admit(&raw) {
        Admission::Accepted(_) => {}
        other => panic!("Python-built attestation should verify in Rust: {:?}", other),
    }
}
