//! Real end-to-end evidence that the H1.3 (failure preservation) + H1.4 (Ed25519 verification,
//! checkpoints) logic ported cleanly from the CBOR/SHA3-256 l8p_core crate onto this JSON/BLAKE3
//! foundation. Not a reconstruction of l8p_core's own adversarial suite (that suite hand-builds
//! raw CBOR bytes and doesn't carry over) -- this instead exercises the ported pipeline against
//! real, valid and deliberately-corrupted JSON attestations built with this crate's own encoder.
#![cfg(feature = "reference-signer")]

use l8p_json::crypto::ed25519::{public_key_from_seed, sign_reference};
use l8p_json::crypto::encode_b64url;
use l8p_json::emit::checkpoint::{check_freshness, check_log_against_checkpoint, parse_checkpoint};
use l8p_json::emit::{EmitConfig, Emitter, ReferenceSigner};
use l8p_json::failure::{Gate, LogConfig, Admission, FailureKind};
use l8p_json::verify::{signing_payload, SigCode};
use l8p_json::wire::{canonical_map, encode, DecodedValue as V, Limits};
use l8p_json::model::ValidationCode;

fn txt(s: &str) -> V { V::Text(s.to_string()) }
fn b64(d: &[u8]) -> V { V::Text(encode_b64url(d)) }
fn envelope(payload: &[u8]) -> Vec<u8> {
    let mut e = (payload.len() as u32).to_be_bytes().to_vec();
    e.extend_from_slice(payload);
    e
}
fn uuid_from(d: &[u8]) -> String {
    let mut b = [0u8; 16];
    b.copy_from_slice(&d[..16]);
    b[6] = (b[6] & 0x0f) | 0x80;
    b[8] = (b[8] & 0x3f) | 0x80;
    let h: String = b.iter().map(|x| format!("{:02x}", x)).collect();
    format!("{}-{}-{}-{}-{}", &h[0..8], &h[8..12], &h[12..16], &h[16..20], &h[20..32])
}

/// Build a real, correctly dual-signed `succession` attestation: rotation from `old_seed` to
/// `new_seed`. Returns the complete envelope bytes.
fn build_succession(old_seed: [u8; 32], new_seed: [u8; 32]) -> Vec<u8> {
    let old_pk = public_key_from_seed(&old_seed);
    let new_pk = public_key_from_seed(&new_seed);
    let body = canonical_map(vec![
        (txt("prev_pk"), b64(&old_pk)),
        (txt("next_pk"), b64(&new_pk)),
        (txt("prev_fp"), b64(&old_pk)), // fingerprint shape only; not checked by verify_signatures
        (txt("next_fp"), b64(&new_pk)),
        (txt("reason"), txt("key_rotation")),
        (txt("scope_unchanged"), V::Bool(true)),
    ]);
    let fields = vec![
        (txt("ver"), txt("L8/1.0")),
        (txt("id"), txt(&uuid_from(&[7u8; 32]))),
        (txt("sub"), txt("agent://test-identity")),
        (txt("claim"), canonical_map(vec![(txt("type"), txt("succession")), (txt("body"), body)])),
        (txt("ts_unix_ns"), V::Uint(1_800_000_000_000_000_000)),
        (txt("ts_rfc3339"), txt("2026-09-25T00:00:00.000000000Z")),
        (txt("prev"), V::Null),
        (txt("pk"), b64(&new_pk)),
        (txt("wit"), V::Array(vec![])),
        (txt("meta"), canonical_map(vec![
            (txt("sentinel"), txt("test")), (txt("scope"), txt("test")), (txt("env"), txt("test")),
        ])),
    ];
    let unsigned = canonical_map(fields.clone());
    let payload = signing_payload(&unsigned).expect("map payload");
    let sig = sign_reference(&new_seed, &payload);
    let auth_sig = sign_reference(&old_seed, &payload);
    let mut signed = fields;
    signed.push((txt("sig"), b64(&sig)));
    signed.push((txt("auth_sig"), b64(&auth_sig)));
    envelope(&encode(&canonical_map(signed)))
}

#[test]
fn valid_succession_is_accepted_and_round_trips_through_json() {
    let env = build_succession([1u8; 32], [2u8; 32]);
    let mut gate = Gate::new_verifying(Limits::default(), LogConfig::default());
    match gate.admit(&env) {
        Admission::Accepted(_) => {}
        other => panic!("expected acceptance, got {:?}", other),
    }
    assert_eq!(gate.accepted_count(), 1);
}

#[test]
fn corrupted_signature_is_rejected_and_preserved_in_the_failure_log() {
    let mut env = build_succession([3u8; 32], [4u8; 32]);
    // Flip a byte inside the JSON payload's "sig" field value. Keys are canonically sorted
    // ("auth_sig" < "sig" alphabetically), so locate the field by content rather than assuming
    // a position.
    let marker = b"\"sig\":\"";
    let start = env.windows(marker.len()).position(|w| w == marker).expect("sig field present") + marker.len();
    env[start + 2] ^= 0x01; // stay inside the base64url payload, not the surrounding quotes
    let mut gate = Gate::new_verifying(Limits::default(), LogConfig::default());
    match gate.admit(&env) {
        Admission::Rejected { seq } => {
            assert_eq!(seq, 0);
            let rec = gate.log().records().next().unwrap();
            match rec.kind {
                FailureKind::Signature(SigCode::SignatureInvalid) | FailureKind::Signature(SigCode::AuthSignatureInvalid) => {}
                other => panic!("expected a signature failure, got {:?}", other),
            }
        }
        other => panic!("expected rejection, got {:?}", other),
    }
    assert_eq!(gate.accepted_count(), 0);
}

#[test]
fn non_canonical_json_is_rejected_at_the_wire_layer() {
    // A single space after the opening brace is insignificant whitespace: the strict decoder
    // must reject it rather than silently accept a non-canonical encoding.
    let bad_payload = b"{ \"a\":1}".to_vec();
    let env = envelope(&bad_payload);
    let mut gate = Gate::new(Limits::default(), LogConfig::default()); // structure-only gate is enough here
    match gate.admit(&env) {
        Admission::Rejected { .. } => {
            let rec = gate.log().records().next().unwrap();
            assert!(matches!(rec.kind, FailureKind::Wire(_)), "expected a wire-stage rejection, got {:?}", rec.kind);
        }
        other => panic!("expected rejection of non-canonical JSON, got {:?}", other),
    }
}

#[test]
fn missing_required_field_is_rejected_at_the_structure_layer() {
    // Valid canonical JSON, but missing everything -- an empty object has none of the required fields.
    let env = envelope(&encode(&V::Map(vec![])));
    let mut gate = Gate::new(Limits::default(), LogConfig::default());
    match gate.admit(&env) {
        Admission::Rejected { .. } => {
            let rec = gate.log().records().next().unwrap();
            match rec.kind {
                FailureKind::Structure(ValidationCode::MissingField) => {}
                other => panic!("expected MissingField, got {:?}", other),
            }
        }
        other => panic!("expected rejection, got {:?}", other),
    }
}

#[test]
fn emitted_anomaly_attestations_pass_the_crate_own_verifying_gate() {
    // Feed a few real rejections into a log, then emit them as signed `anomaly` attestations,
    // and confirm this crate's own Gate accepts what its own Emitter produced (round trip).
    let mut gate = Gate::new(Limits::default(), LogConfig::default());
    let _ = gate.admit(&envelope(b"{ \"a\":1}")); // wire-stage rejection
    let _ = gate.admit(&envelope(&encode(&V::Map(vec![])))); // structure-stage rejection

    let emitter_seed = [9u8; 32];
    let signer = ReferenceSigner::from_seed(emitter_seed);
    let cfg = EmitConfig {
        subject: "agent://emitter-test".to_string(),
        sentinel: "test".to_string(),
        scope: "test".to_string(),
        env: "test".to_string(),
    };
    let mut emitter = Emitter::new(cfg, signer).expect("valid config");
    let batch = emitter.emit_pending(gate.log(), 1_800_000_000_000_000_000);
    assert!(batch.error.is_none(), "emission should not fail: {:?}", batch.error);
    assert_eq!(batch.attestations.len(), 2, "one anomaly attestation per preserved rejection");

    let mut verifying = Gate::new_verifying(Limits::default(), LogConfig::default());
    for att in &batch.attestations {
        match verifying.admit(att) {
            Admission::Accepted(_) => {}
            other => panic!("emitted attestation should verify against its own signer: {:?}", other),
        }
    }
}

#[test]
fn checkpoint_round_trips_and_detects_truncation() {
    let mut gate = Gate::new(Limits::default(), LogConfig::default());
    let _ = gate.admit(&envelope(b"{ \"a\":1}"));
    let _ = gate.admit(&envelope(&encode(&V::Map(vec![]))));

    let emitter_seed = [11u8; 32];
    let emitter_pk = public_key_from_seed(&emitter_seed);
    let signer = ReferenceSigner::from_seed(emitter_seed);
    let cfg = EmitConfig {
        subject: "agent://checkpoint-test".to_string(),
        sentinel: "test".to_string(),
        scope: "test".to_string(),
        env: "test".to_string(),
    };
    let mut emitter = Emitter::new(cfg, signer).expect("valid config");
    let cp_envelope = emitter.emit_checkpoint(gate.log(), 1_800_000_000_000_000_000).expect("checkpoint signs");

    let cp = parse_checkpoint(&cp_envelope, &emitter_pk).expect("checkpoint parses and verifies");
    assert_eq!(cp.total_rejected, 2);

    let full_snapshot = gate.log().snapshot();
    check_log_against_checkpoint(&full_snapshot, &cp).expect("full log matches its own checkpoint");

    // Simulate a truncated (rewound) log: drop the second record.
    let mut truncated = full_snapshot.clone();
    truncated.records.pop();
    truncated.next_seq -= 1;
    // Keep the snapshot internally self-consistent (a real truncated log's own head IS the
    // digest of its new last record) so the checkpoint comparison -- not verify() -- is what
    // catches the truncation.
    truncated.head = truncated.records.last().unwrap().digest;
    let err = check_log_against_checkpoint(&truncated, &cp).unwrap_err();
    assert!(matches!(err, l8p_json::emit::checkpoint::LogCheckError::Truncated));

    // check_freshness rejects a rollback to an earlier count.
    let stale = parse_checkpoint(&cp_envelope, &emitter_pk).unwrap();
    let mut gate2 = Gate::new(Limits::default(), LogConfig::default());
    let _ = gate2.admit(&envelope(b"{ \"a\":1}"));
    let _ = gate2.admit(&envelope(&encode(&V::Map(vec![]))));
    let _ = gate2.admit(&envelope(b"not json at all"));
    let mut emitter2_signer_seed = emitter_seed;
    let _ = &mut emitter2_signer_seed;
    check_freshness(Some(&stale), &cp).expect("identical checkpoint is not a rollback");
}
