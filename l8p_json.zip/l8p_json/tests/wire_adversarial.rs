use l8p_json::wire::{decode, encode, DecodedValue as V, FailureCode, Limits};

fn lim() -> Limits { Limits::default() }

fn expect_code(input: &[u8], code: FailureCode) {
    match decode(input, &lim()) {
        Err(e) => assert_eq!(e.code, code, "input {:?}: expected {:?}, got {:?}", String::from_utf8_lossy(input), code, e.code),
        Ok(v) => panic!("input {:?}: expected {:?}, got Ok({:?})", String::from_utf8_lossy(input), code, v),
    }
}

#[test]
fn round_trip_accepts_and_reproduces_canonical_forms() {
    let cases: &[&[u8]] = &[
        b"null", b"true", b"false", b"0", b"123", b"-1", b"-123456789",
        b"\"\"", b"\"hello\"", b"\"line\\nbreak\"", b"\"quote\\\"here\"",
        b"[]", b"[1,2,3]", b"{}", b"{\"a\":1,\"b\":2}",
        b"{\"a\":[1,{\"b\":true,\"c\":null}]}",
    ];
    for c in cases {
        let v = decode(c, &lim()).unwrap_or_else(|e| panic!("input {:?} should decode, got {:?}", String::from_utf8_lossy(c), e));
        let re = encode(&v);
        assert_eq!(re.as_slice(), *c, "round trip mismatch for {:?}", String::from_utf8_lossy(c));
    }
}

#[test]
fn insignificant_whitespace_is_rejected() {
    expect_code(b"{ \"a\":1}", FailureCode::InvalidJson);
    expect_code(b"{\"a\": 1}", FailureCode::InvalidJson);
    expect_code(b"{\"a\":1 }", FailureCode::InvalidJson);
    expect_code(b" null", FailureCode::InvalidJson);
    expect_code(b"[1, 2]", FailureCode::InvalidJson);
}

#[test]
fn leading_zero_is_rejected() {
    expect_code(b"01", FailureCode::NonCanonical);
    expect_code(b"-01", FailureCode::NonCanonical);
}

#[test]
fn negative_zero_is_rejected() {
    expect_code(b"-0", FailureCode::NonCanonical);
}

#[test]
fn floats_are_rejected() {
    expect_code(b"1.5", FailureCode::InvalidJson);
    expect_code(b"1e10", FailureCode::InvalidJson);
    expect_code(b"1E10", FailureCode::InvalidJson);
}

#[test]
fn duplicate_object_key_is_rejected() {
    expect_code(b"{\"a\":1,\"a\":2}", FailureCode::DuplicateKey);
}

#[test]
fn out_of_order_object_key_is_rejected() {
    expect_code(b"{\"b\":1,\"a\":2}", FailureCode::NonCanonical);
}

#[test]
fn non_minimal_solidus_escape_is_rejected() {
    // '/' never requires escaping; "\/" is valid JSON grammar but non-canonical.
    expect_code(b"\"a\\/b\"", FailureCode::NonCanonical);
}

#[test]
fn unicode_escape_of_a_plain_ascii_char_is_rejected() {
    // 'A' (0x41) needs no escape at all.
    expect_code(b"\"\\u0041\"", FailureCode::NonCanonical);
}

#[test]
fn unicode_escape_of_a_named_escape_value_is_rejected() {
    // 0x0A ('\n') has a named escape; using \u000a instead is non-minimal.
    expect_code(b"\"\\u000a\"", FailureCode::NonCanonical);
}

#[test]
fn raw_unescaped_control_char_in_string_is_rejected() {
    let mut s = b"\"".to_vec();
    s.push(0x01);
    s.push(b'"');
    expect_code(&s, FailureCode::InvalidJson);
}

#[test]
fn truncated_input_is_rejected() {
    expect_code(b"{\"a\":1", FailureCode::Truncated);
    expect_code(b"\"unterminated", FailureCode::Truncated);
    expect_code(b"[1,2", FailureCode::Truncated);
}

#[test]
fn trailing_bytes_after_a_valid_value_are_rejected() {
    expect_code(b"1 ", FailureCode::InvalidJson);
    expect_code(b"nullnull", FailureCode::InvalidJson);
}

#[test]
fn depth_limit_is_enforced() {
    let mut limits = lim();
    limits.max_depth = 3;
    let shallow = b"[[[1]]]";
    let deep = b"[[[[1]]]]";
    assert!(decode(shallow, &limits).is_ok());
    match decode(deep, &limits) {
        Err(e) => assert_eq!(e.code, FailureCode::DepthExceeded),
        Ok(_) => panic!("expected depth to be exceeded"),
    }
}

#[test]
fn element_limit_is_enforced() {
    let mut limits = lim();
    limits.max_elements = 2;
    assert!(decode(b"[1,2]", &limits).is_ok());
    match decode(b"[1,2,3]", &limits) {
        Err(e) => assert_eq!(e.code, FailureCode::ElementLimitExceeded),
        Ok(_) => panic!("expected element limit to be exceeded"),
    }
}

#[test]
fn text_length_limit_is_enforced() {
    let mut limits = lim();
    limits.max_text_len = 3;
    assert!(decode(b"\"abc\"", &limits).is_ok());
    match decode(b"\"abcd\"", &limits) {
        Err(e) => assert_eq!(e.code, FailureCode::LengthLimitExceeded),
        Ok(_) => panic!("expected length limit to be exceeded"),
    }
}

#[test]
fn envelope_oversize_is_enforced() {
    let mut limits = lim();
    limits.max_envelope_bytes = 4;
    match decode(b"12345", &limits) {
        Err(e) => assert_eq!(e.code, FailureCode::EnvelopeOversize),
        Ok(_) => panic!("expected envelope oversize"),
    }
}

#[test]
fn encoder_always_sorts_keys_regardless_of_construction_order() {
    let v = V::Map(vec![
        (V::Text("z".into()), V::Uint(1)),
        (V::Text("a".into()), V::Uint(2)),
    ]);
    assert_eq!(encode(&v), b"{\"a\":2,\"z\":1}".to_vec());
}

#[test]
fn deterministic_prng_mutation_fuzz_never_panics() {
    // Simple xorshift PRNG, deterministic across runs.
    struct Xs(u64);
    impl Xs { fn next(&mut self) -> u64 { self.0 ^= self.0 << 13; self.0 ^= self.0 >> 7; self.0 ^= self.0 << 17; self.0 } }
    let base = b"{\"a\":[1,2,{\"b\":true,\"c\":null}],\"d\":\"text\"}".to_vec();
    let mut rng = Xs(0xC0FFEE);
    for _ in 0..2000 {
        let mut mutated = base.clone();
        let idx = (rng.next() as usize) % mutated.len();
        mutated[idx] ^= (rng.next() % 256) as u8;
        let _ = decode(&mutated, &lim()); // must never panic, Ok or Err both fine
    }
}
