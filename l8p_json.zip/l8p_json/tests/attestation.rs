use l8p_json::{decode, validate, ActionBody, ClaimBody, Limits, ValidationError};

fn lim() -> Limits {
    Limits::default()
}

fn succession_json() -> &'static [u8] {
    br#"{"claim":{"body":{"next_fp":"nf","next_pk":"npk","prev_fp":"pf","prev_pk":"ppk","reason":"key_rotation","scope_unchanged":true},"type":"succession"},"id":"a1","meta":{"env":"prod","scope":"global","sentinel":"s1"},"pk":"newpk","prev":"blk0","sig":"sigX","sub":"agent-a","ts_rfc3339":"2026-09-24T00:00:00Z","ts_unix_ns":1,"ver":"L8/1.0","wit":["w1"]}"#
}

fn revocation_json() -> &'static [u8] {
    br#"{"claim":{"body":{"action_type":"identity_revocation","authorized_by":"agent-a","effective_at":"2026-09-24T00:00:01Z","reason":"user_request","replaced_by":"agent-c","revoked_at":"2026-09-24T00:00:00Z","subject":"agent-a"},"type":"action"},"id":"a2","meta":{},"pk":"pk-a","prev":"blk1","sig":"sigY","sub":"agent-a","ts_rfc3339":"2026-09-24T00:00:02Z","ts_unix_ns":2,"ver":"L8/1.0","wit":[]}"#
}

// ---- ATT-01: succession round trip through decode + validate ----

#[test]
fn att_01_succession_validates_with_typed_body() {
    let v = decode(succession_json(), &lim()).unwrap();
    let att = validate(&v).unwrap();
    assert_eq!(att.id, "a1");
    assert_eq!(att.sub, "agent-a");
    assert_eq!(att.ts_unix_ns, 1);
    assert_eq!(att.wit.len(), 1);
    match att.claim {
        ClaimBody::Succession(s) => {
            assert_eq!(s.reason, "key_rotation");
            assert!(s.scope_unchanged);
            assert_eq!(s.prev_pk, "ppk");
            assert_eq!(s.next_pk, "npk");
        }
        other => panic!("expected Succession, got {:?}", other),
    }
}

// ---- ATT-02: identity_revocation round trip ----

#[test]
fn att_02_identity_revocation_validates_with_typed_body() {
    let v = decode(revocation_json(), &lim()).unwrap();
    let att = validate(&v).unwrap();
    match att.claim {
        ClaimBody::Action(ActionBody::IdentityRevocation(r)) => {
            assert_eq!(r.subject, "agent-a");
            assert_eq!(r.reason, "user_request");
            assert_eq!(r.replaced_by.as_deref(), Some("agent-c"));
        }
        other => panic!("expected IdentityRevocation, got {:?}", other),
    }
}

// ---- ATT-03: an action claim that is NOT identity_revocation stays untyped, not guessed ----

#[test]
fn att_03_other_action_type_stays_untyped() {
    let json = br#"{"claim":{"body":{"action_type":"some_future_action","x":1},"type":"action"},"id":"a3","meta":{},"pk":"pk","prev":null,"sig":"s","sub":"agent-b","ts_rfc3339":"t","ts_unix_ns":0,"ver":"L8/1.0","wit":[]}"#;
    let v = decode(json, &lim()).unwrap();
    let att = validate(&v).unwrap();
    match att.claim {
        ClaimBody::Action(ActionBody::Other { action_type, .. }) => {
            assert_eq!(action_type.as_deref(), Some("some_future_action"));
        }
        other => panic!("expected Other action, got {:?}", other),
    }
}

// ---- ATT-04: deployment/witness stay untyped, honestly -- the ratified spec marks these two
// rows TBD deliberately, so a minimal non-conforming body still validates (there's no field
// list to check it against yet). identity/binding/null/anomaly WERE this way too until this
// session typed them against the ratified spec -- now a minimal non-conforming body correctly
// REJECTS for those four instead, which the second test below checks.

#[test]
fn att_04_still_unestablished_claim_bodies_stay_untyped_not_guessed() {
    for ctype in ["deployment", "witness"] {
        let json = format!(
            r#"{{"claim":{{"body":{{"whatever":1}},"type":"{}"}},"id":"a","meta":{{}},"pk":"pk","prev":null,"sig":"s","sub":"agent","ts_rfc3339":"t","ts_unix_ns":0,"ver":"L8/1.0","wit":[]}}"#,
            ctype
        );
        let v = decode(json.as_bytes(), &lim()).unwrap();
        let att = validate(&v).unwrap();
        match att.claim {
            ClaimBody::Untyped { claim_type, .. } => assert_eq!(claim_type, ctype),
            other => panic!("expected Untyped for {}, got {:?}", ctype, other),
        }
    }
}

#[test]
fn att_04b_now_typed_claim_bodies_reject_a_non_conforming_minimal_body() {
    for ctype in ["identity", "binding", "null", "anomaly"] {
        let json = format!(
            r#"{{"claim":{{"body":{{"whatever":1}},"type":"{}"}},"id":"a","meta":{{}},"pk":"pk","prev":null,"sig":"s","sub":"agent","ts_rfc3339":"t","ts_unix_ns":0,"ver":"L8/1.0","wit":[]}}"#,
            ctype
        );
        let v = decode(json.as_bytes(), &lim()).unwrap();
        let err = validate(&v).unwrap_err();
        assert!(matches!(err, ValidationError::MissingField(_)), "expected MissingField for {}, got {:?}", ctype, err);
    }
}

#[test]
fn att_04c_minimal_conforming_bodies_validate_with_typed_shapes() {
    let cases: &[(&str, &str)] = &[
        ("identity", r#"{"delegate_of":null,"kind":"human","pk":"pk","scope":"s","uuid":"u"}"#),
        ("binding", r#"{"binding_sig":"bs","pk":"pk","uuid":"u"}"#),
        ("null", r#"{"interval_end":"e","interval_start":"s","reason":"r"}"#),
        ("anomaly", r#"{"anomaly_id":"aid","category":"c","description":"d","detected_by":"db","related_attestations":[],"severity":"info"}"#),
    ];
    for (ctype, body) in cases {
        let json = format!(
            r#"{{"claim":{{"body":{},"type":"{}"}},"id":"a","meta":{{}},"pk":"pk","prev":null,"sig":"s","sub":"agent","ts_rfc3339":"t","ts_unix_ns":0,"ver":"L8/1.0","wit":[]}}"#,
            body, ctype
        );
        let v = decode(json.as_bytes(), &lim()).unwrap();
        let att = validate(&v).unwrap_or_else(|e| panic!("expected {} to validate, got {:?}", ctype, e));
        match (*ctype, att.claim) {
            ("identity", ClaimBody::Identity(_)) => {}
            ("binding", ClaimBody::Binding(_)) => {}
            ("null", ClaimBody::Null(_)) => {}
            ("anomaly", ClaimBody::Anomaly(_)) => {}
            (c, other) => panic!("expected typed {}, got {:?}", c, other),
        }
    }
}

#[test]
fn att_04d_identity_rejects_unknown_kind() {
    let json = br#"{"claim":{"body":{"delegate_of":null,"kind":"robot","pk":"pk","scope":"s","uuid":"u"},"type":"identity"},"id":"a","meta":{},"pk":"pk","prev":null,"sig":"s","sub":"agent","ts_rfc3339":"t","ts_unix_ns":0,"ver":"L8/1.0","wit":[]}"#;
    let v = decode(json, &lim()).unwrap();
    let err = validate(&v).unwrap_err();
    assert_eq!(err, ValidationError::UnknownIdentityKind("robot".to_string()));
}

#[test]
fn att_04e_general_action_body_types_when_shape_matches() {
    let json = br#"{"claim":{"body":{"action_id":"aid","category":"c","params":{},"resource":"r","result":null},"type":"action"},"id":"a","meta":{},"pk":"pk","prev":null,"sig":"s","sub":"agent","ts_rfc3339":"t","ts_unix_ns":0,"ver":"L8/1.0","wit":[]}"#;
    let v = decode(json, &lim()).unwrap();
    let att = validate(&v).unwrap();
    match att.claim {
        ClaimBody::Action(ActionBody::General(g)) => {
            assert_eq!(g.action_id, "aid");
            assert_eq!(g.resource, "r");
        }
        other => panic!("expected General action, got {:?}", other),
    }
}

// ---- ATT-05..08: adversarial rejections, one per field class ----

#[test]
fn att_05_rejects_unknown_claim_type() {
    let json = br#"{"claim":{"body":{},"type":"not_a_real_type"},"id":"a","meta":{},"pk":"p","prev":null,"sig":"s","sub":"x","ts_rfc3339":"t","ts_unix_ns":0,"ver":"L8/1.0","wit":[]}"#;
    let v = decode(json, &lim()).unwrap();
    let err = validate(&v).unwrap_err();
    assert_eq!(err, ValidationError::UnknownClaimType("not_a_real_type".to_string()));
}

#[test]
fn att_06_rejects_unknown_succession_reason() {
    let json = br#"{"claim":{"body":{"next_fp":"a","next_pk":"b","prev_fp":"c","prev_pk":"d","reason":"made_up_reason","scope_unchanged":true},"type":"succession"},"id":"a","meta":{},"pk":"p","prev":null,"sig":"s","sub":"x","ts_rfc3339":"t","ts_unix_ns":0,"ver":"L8/1.0","wit":[]}"#;
    let v = decode(json, &lim()).unwrap();
    let err = validate(&v).unwrap_err();
    assert_eq!(err, ValidationError::UnknownSuccessionReason("made_up_reason".to_string()));
}

#[test]
fn att_07_rejects_unknown_revocation_reason() {
    let json = br#"{"claim":{"body":{"action_type":"identity_revocation","authorized_by":"x","effective_at":"t","reason":"because_i_said_so","revoked_at":"t","subject":"x"},"type":"action"},"id":"a","meta":{},"pk":"p","prev":null,"sig":"s","sub":"x","ts_rfc3339":"t","ts_unix_ns":0,"ver":"L8/1.0","wit":[]}"#;
    let v = decode(json, &lim()).unwrap();
    let err = validate(&v).unwrap_err();
    assert_eq!(err, ValidationError::UnknownRevocationReason("because_i_said_so".to_string()));
}

#[test]
fn att_08_missing_required_field_is_named_specifically() {
    // sub is missing entirely
    let json = br#"{"claim":{"body":{},"type":"deployment"},"id":"a","meta":{},"pk":"p","prev":null,"sig":"s","ts_rfc3339":"t","ts_unix_ns":0,"ver":"L8/1.0","wit":[]}"#;
    let v = decode(json, &lim()).unwrap();
    let err = validate(&v).unwrap_err();
    assert_eq!(err, ValidationError::MissingField("sub"));
}

#[test]
fn att_09_wrong_type_field_is_named_specifically() {
    // ts_unix_ns given as a string instead of an integer
    let json = br#"{"claim":{"body":{},"type":"deployment"},"id":"a","meta":{},"pk":"p","prev":null,"sig":"s","sub":"x","ts_rfc3339":"t","ts_unix_ns":"0","ver":"L8/1.0","wit":[]}"#;
    let v = decode(json, &lim()).unwrap();
    let err = validate(&v).unwrap_err();
    assert_eq!(err, ValidationError::WrongType("ts_unix_ns"));
}

#[test]
fn att_10_prev_null_is_accepted_as_none_for_genesis_attestations() {
    let json = br#"{"claim":{"body":{},"type":"deployment"},"id":"a","meta":{},"pk":"p","prev":null,"sig":"s","sub":"x","ts_rfc3339":"t","ts_unix_ns":0,"ver":"L8/1.0","wit":[]}"#;
    let v = decode(json, &lim()).unwrap();
    let att = validate(&v).unwrap();
    assert_eq!(att.prev, None);
}

#[test]
fn att_11_every_required_field_omitted_one_at_a_time_is_rejected() {
    let base = serde_free_full_object();
    for field in ["ver", "id", "sub", "claim", "ts_unix_ns", "ts_rfc3339", "sig", "pk"] {
        let json = remove_field(&base, field);
        let v = decode(json.as_bytes(), &lim()).unwrap();
        let err = validate(&v).unwrap_err();
        match err {
            ValidationError::MissingField(f) => assert_eq!(f, field),
            other => panic!("field {}: expected MissingField, got {:?}", field, other),
        }
    }
}

// minimal hand-rolled helpers (no serde in this crate, on purpose)
fn serde_free_full_object() -> String {
    r#"{"claim":{"body":{},"type":"deployment"},"id":"a","meta":{},"pk":"p","prev":null,"sig":"s","sub":"x","ts_rfc3339":"t","ts_unix_ns":0,"ver":"L8/1.0","wit":[]}"#.to_string()
}

fn remove_field(json: &str, field: &str) -> String {
    // crude but sufficient for this fixed, known-canonical test fixture:
    // find "field":...  up to the next top-level comma or closing brace.
    let key = format!("\"{}\":", field);
    let start = json.find(&key).expect("field present in fixture");
    let mut depth = 0i32;
    let mut end = start;
    let bytes = json.as_bytes();
    let mut i = start;
    while i < bytes.len() {
        match bytes[i] {
            b'{' | b'[' => depth += 1,
            b'}' | b']' if depth > 0 => depth -= 1,
            b',' if depth == 0 => {
                end = i + 1;
                break;
            }
            b'}' if depth == 0 => {
                // last field before the object's closing brace: remove
                // the field and its own leading comma instead, since
                // there's no trailing comma to also consume here.
                let comma = json[..start].rfind(',').expect("a preceding field exists");
                let mut out = json.to_string();
                out.replace_range(comma..i, "");
                return out;
            }
            _ => {}
        }
        i += 1;
    }
    if end == start {
        end = bytes.len();
    }
    let mut out = json.to_string();
    out.replace_range(start..end, "");
    // if we removed a trailing field before '}', may leave a dangling comma
    out.replace(",}", "}")
}
