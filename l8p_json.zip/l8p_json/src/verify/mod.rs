//! H1.4: cryptographic signature verification of structurally valid attestations.
//! Signing payload: BLAKE3 over the canonical JSON encoding of the attestation map with `sig`,
//! `auth_sig` and `wit` removed -- this is the ratified L8/1.0 construction, not a proposal.
//! Both `sig` and (for succession) `auth_sig` sign that same digest.
use crate::crypto::{decode_b64url, ed25519, blake3_256};
use crate::model::{Attestation, ClaimBody};
use crate::wire::{encode, DecodedValue};

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum SigCode {
    BadEncoding,
    BadKeyLength,
    BadSigLength,
    KeyMismatch,
    SignatureInvalid,
    AuthSignatureInvalid,
}

impl SigCode {
    pub const ALL: [SigCode; 6] = [
        SigCode::BadEncoding, SigCode::BadKeyLength, SigCode::BadSigLength,
        SigCode::KeyMismatch, SigCode::SignatureInvalid, SigCode::AuthSignatureInvalid,
    ];
    pub fn as_str(&self) -> &'static str {
        match self {
            SigCode::BadEncoding => "BAD_ENCODING",
            SigCode::BadKeyLength => "BAD_KEY_LENGTH",
            SigCode::BadSigLength => "BAD_SIG_LENGTH",
            SigCode::KeyMismatch => "KEY_MISMATCH",
            SigCode::SignatureInvalid => "SIGNATURE_INVALID",
            SigCode::AuthSignatureInvalid => "AUTH_SIGNATURE_INVALID",
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SigError {
    pub code: SigCode,
    pub path: &'static str,
}
fn fail<T>(code: SigCode, path: &'static str) -> Result<T, SigError> { Err(SigError { code, path }) }

const EXCLUDED: [&str; 3] = ["sig", "auth_sig", "wit"];

/// Digest that `sig` / `auth_sig` must sign. None if the value is not a map.
pub fn signing_payload(decoded: &DecodedValue) -> Option<[u8; 32]> {
    let pairs = match decoded { DecodedValue::Map(p) => p, _ => return None };
    let kept: Vec<(DecodedValue, DecodedValue)> = pairs.iter()
        .filter(|(k, _)| !matches!(k, DecodedValue::Text(s) if EXCLUDED.contains(&s.as_str())))
        .cloned().collect();
    Some(blake3_256(&encode(&DecodedValue::Map(kept))))
}

fn key(s: &str, path: &'static str) -> Result<[u8; 32], SigError> {
    let b = match decode_b64url(s) { Some(b) => b, None => return fail(SigCode::BadEncoding, path) };
    <[u8; 32]>::try_from(b.as_slice()).or_else(|_| fail(SigCode::BadKeyLength, path))
}
fn sig(s: &str, path: &'static str) -> Result<[u8; 64], SigError> {
    let b = match decode_b64url(s) { Some(b) => b, None => return fail(SigCode::BadEncoding, path) };
    <[u8; 64]>::try_from(b.as_slice()).or_else(|_| fail(SigCode::BadSigLength, path))
}

/// Verify `att` (already structurally valid) against the raw decoded value it came from.
/// NOT checked here: fingerprints (`prev_fp`/`next_fp`), witness signatures (`wit`), chain linkage (`prev`), Levels.
pub fn verify_signatures(decoded: &DecodedValue, att: &Attestation) -> Result<(), SigError> {
    let pk = key(&att.pk, "pk")?;
    let sg = sig(&att.sig, "sig")?;
    let payload = match signing_payload(decoded) { Some(p) => p, None => return fail(SigCode::BadEncoding, "") };
    match &att.claim.body {
        ClaimBody::Succession(s) => {
            let prev_pk = key(&s.prev_pk, "claim.body.prev_pk")?;
            let next_pk = key(&s.next_pk, "claim.body.next_pk")?;
            let auth = sig(att.auth_sig.as_deref().unwrap_or(""), "auth_sig")?;
            if next_pk != pk { return fail(SigCode::KeyMismatch, "claim.body.next_pk"); }
            if !ed25519::verify(&pk, &payload, &sg) { return fail(SigCode::SignatureInvalid, "sig"); }
            if !ed25519::verify(&prev_pk, &payload, &auth) { return fail(SigCode::AuthSignatureInvalid, "auth_sig"); }
            Ok(())
        }
        _ => {
            if !ed25519::verify(&pk, &payload, &sg) { return fail(SigCode::SignatureInvalid, "sig"); }
            Ok(())
        }
    }
}
