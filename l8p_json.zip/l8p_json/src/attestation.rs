use crate::validation_error::ValidationError as VErr;
use crate::value::Value;

fn get_str<'a>(v: &'a Value, field: &'static str) -> Result<&'a str, VErr> {
    match v.get(field) {
        None => Err(VErr::MissingField(field)),
        Some(Value::Str(s)) => Ok(s.as_str()),
        Some(_) => Err(VErr::WrongType(field)),
    }
}

fn get_int(v: &Value, field: &'static str) -> Result<i64, VErr> {
    match v.get(field) {
        None => Err(VErr::MissingField(field)),
        Some(Value::Integer(n)) => Ok(*n),
        Some(_) => Err(VErr::WrongType(field)),
    }
}

fn get_opt_str<'a>(v: &'a Value, field: &'static str) -> Result<Option<&'a str>, VErr> {
    match v.get(field) {
        None | Some(Value::Null) => Ok(None),
        Some(Value::Str(s)) => Ok(Some(s.as_str())),
        Some(_) => Err(VErr::WrongType(field)),
    }
}

fn get_bool(v: &Value, field: &'static str) -> Result<bool, VErr> {
    match v.get(field) {
        None => Err(VErr::MissingField(field)),
        Some(Value::Bool(b)) => Ok(*b),
        Some(_) => Err(VErr::WrongType(field)),
    }
}

/// The identity_revocation subtype of an `action` claim — the one
/// action body shape whose fields are concretely established (found in
/// the Privacy & Compliance layer during the real-format reconciliation
/// earlier this project). `reason` is checked against the four named
/// codes; anything else is a specific `UnknownRevocationReason`, not a
/// silently-accepted string.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct IdentityRevocationBody {
    pub subject: String,
    pub reason: String, // one of: user_request | breach_response | legal_order | scheduled_expiration
    pub revoked_at: String,
    pub effective_at: String,
    pub authorized_by: String,
    pub replaced_by: Option<String>,
}

const REVOCATION_REASONS: [&str; 4] =
    ["user_request", "breach_response", "legal_order", "scheduled_expiration"];

fn parse_identity_revocation(body: &Value) -> Result<IdentityRevocationBody, VErr> {
    let reason = get_str(body, "reason")?.to_string();
    if !REVOCATION_REASONS.contains(&reason.as_str()) {
        return Err(VErr::UnknownRevocationReason(reason));
    }
    Ok(IdentityRevocationBody {
        subject: get_str(body, "subject")?.to_string(),
        reason,
        revoked_at: get_str(body, "revoked_at")?.to_string(),
        effective_at: get_str(body, "effective_at")?.to_string(),
        authorized_by: get_str(body, "authorized_by")?.to_string(),
        replaced_by: get_opt_str(body, "replaced_by")?.map(|s| s.to_string()),
    })
}

/// The general (non-revocation) `action` shape, per the ratified H1.2 spec §3.1:
/// `action_id`, `category`, `resource`, `params` (Map), `result`.
#[derive(Debug, Clone, PartialEq)]
pub struct GeneralActionBody {
    pub action_id: String,
    pub category: String,
    pub resource: String,
    pub params: Value, // Map, shape otherwise open (no ratified sub-schema for `params`)
    pub result: Value,
    pub raw: Value,
}

fn parse_general_action(body: &Value) -> Result<GeneralActionBody, VErr> {
    let params = body.get("params").ok_or(VErr::MissingField("params"))?;
    if params.as_object().is_none() {
        return Err(VErr::WrongType("params"));
    }
    let result = body.get("result").ok_or(VErr::MissingField("result"))?;
    Ok(GeneralActionBody {
        action_id: get_str(body, "action_id")?.to_string(),
        category: get_str(body, "category")?.to_string(),
        resource: get_str(body, "resource")?.to_string(),
        params: params.clone(),
        result: result.clone(),
        raw: body.clone(),
    })
}

/// An `action` claim body. The ratified H1.2 spec §3.1 names exactly two shapes --
/// `identity_revocation` or the general shape -- with no explicit third case. But an action
/// claim using some OTHER `action_type` the spec doesn't yet name (a real possibility this
/// protocol has to tolerate; `action_type` isn't a closed enum) won't carry the general
/// shape's five required fields either, and the already-shipped `att_03` test establishes that
/// such a claim should validate as a known, honestly-untyped shape rather than fail outright.
/// So: try General first; only fall back to `Other` when it doesn't match that shape AT ALL.
#[derive(Debug, Clone, PartialEq)]
pub enum ActionBody {
    IdentityRevocation(IdentityRevocationBody),
    General(GeneralActionBody),
    Other { action_type: Option<String>, raw: Value },
}

fn parse_action(body: &Value) -> Result<ActionBody, VErr> {
    let action_type = get_opt_str(body, "action_type")?.map(|s| s.to_string());
    if action_type.as_deref() == Some("identity_revocation") {
        return Ok(ActionBody::IdentityRevocation(parse_identity_revocation(body)?));
    }
    match parse_general_action(body) {
        Ok(g) => Ok(ActionBody::General(g)),
        Err(_) => Ok(ActionBody::Other { action_type, raw: body.clone() }),
    }
}

/// An `identity` claim body, per the ratified H1.2 spec §3.1: `uuid`, `pk`, `kind` (one of
/// `human`, `machine`, `agent`), `delegate_of` (Null or TextString), `scope`.
#[derive(Debug, Clone, PartialEq)]
pub struct IdentityBody {
    pub uuid: String,
    pub pk: String,
    pub kind: String, // human | machine | agent
    pub delegate_of: Option<String>,
    pub scope: String,
}

const IDENTITY_KINDS: [&str; 3] = ["human", "machine", "agent"];

fn parse_identity(body: &Value) -> Result<IdentityBody, VErr> {
    let kind = get_str(body, "kind")?.to_string();
    if !IDENTITY_KINDS.contains(&kind.as_str()) {
        return Err(VErr::UnknownIdentityKind(kind));
    }
    Ok(IdentityBody {
        uuid: get_str(body, "uuid")?.to_string(),
        pk: get_str(body, "pk")?.to_string(),
        kind,
        delegate_of: get_opt_str(body, "delegate_of")?.map(|s| s.to_string()),
        scope: get_str(body, "scope")?.to_string(),
    })
}

/// A `binding` claim body, per the ratified H1.2 spec §3.1: `uuid`, `pk`, `binding_sig`.
#[derive(Debug, Clone, PartialEq)]
pub struct BindingBody {
    pub uuid: String,
    pub pk: String,
    pub binding_sig: String,
}

fn parse_binding(body: &Value) -> Result<BindingBody, VErr> {
    Ok(BindingBody {
        uuid: get_str(body, "uuid")?.to_string(),
        pk: get_str(body, "pk")?.to_string(),
        binding_sig: get_str(body, "binding_sig")?.to_string(),
    })
}

/// A `null` claim body, per the ratified H1.2 spec §3.1: `interval_start`, `interval_end`,
/// `reason`. No enum constraint on `reason` is given in the spec (unlike succession/revocation).
#[derive(Debug, Clone, PartialEq)]
pub struct NullBody {
    pub interval_start: String,
    pub interval_end: String,
    pub reason: String,
}

fn parse_null(body: &Value) -> Result<NullBody, VErr> {
    Ok(NullBody {
        interval_start: get_str(body, "interval_start")?.to_string(),
        interval_end: get_str(body, "interval_end")?.to_string(),
        reason: get_str(body, "reason")?.to_string(),
    })
}

/// An `anomaly` claim body, per the ratified H1.2 spec §3.1: `anomaly_id`, `category`,
/// `severity`, `related_attestations` (Array), `description`, `detected_by`. No enum
/// constraint is given for `category`/`severity` in the spec, so any string is accepted.
///
/// This is the one body H1.3's own emitter (`emit/mod.rs`) also produces, for its
/// `input_rejected`/`failure_gap`/`log_checkpoint` categories -- a real gap found this session:
/// the emitter was originally built against an ad-hoc shape under the (wrong, unchecked)
/// assumption that no ratified schema existed yet for `anomaly`. It has since been migrated to
/// emit the 6 fields below plus its own forensic extras (`hash`/`stage`/`code`/digests/etc, kept
/// in `raw`) -- this crate's `validate()` doesn't reject unknown fields, so both can coexist.
#[derive(Debug, Clone, PartialEq)]
pub struct AnomalyBody {
    pub anomaly_id: String,
    pub category: String,
    pub severity: String,
    pub related_attestations: Vec<String>,
    pub description: String,
    pub detected_by: String,
    pub raw: Value,
}

fn parse_anomaly(body: &Value) -> Result<AnomalyBody, VErr> {
    let related_val = body.get("related_attestations").ok_or(VErr::MissingField("related_attestations"))?;
    let related_arr = match related_val {
        Value::Array(a) => a,
        _ => return Err(VErr::WrongType("related_attestations")),
    };
    let mut related_attestations = Vec::with_capacity(related_arr.len());
    for item in related_arr {
        match item {
            Value::Str(s) => related_attestations.push(s.clone()),
            _ => return Err(VErr::WrongType("related_attestations")),
        }
    }
    Ok(AnomalyBody {
        anomaly_id: get_str(body, "anomaly_id")?.to_string(),
        category: get_str(body, "category")?.to_string(),
        severity: get_str(body, "severity")?.to_string(),
        related_attestations,
        description: get_str(body, "description")?.to_string(),
        detected_by: get_str(body, "detected_by")?.to_string(),
        raw: body.clone(),
    })
}

/// A `succession` claim body — dual-signed key rotation/evolution.
/// `sig` (new key) and `auth_sig` (old key) live at the top-level
/// Attestation, not in this body, per the real format.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SuccessionBody {
    pub prev_pk: String,
    pub next_pk: String,
    pub prev_fp: String,
    pub next_fp: String,
    pub reason: String, // key_rotation | algorithm_migration | compromise_recovery | scheduled_evolution
    pub scope_unchanged: bool,
}

const SUCCESSION_REASONS: [&str; 4] =
    ["key_rotation", "algorithm_migration", "compromise_recovery", "scheduled_evolution"];

fn parse_succession(body: &Value) -> Result<SuccessionBody, VErr> {
    let reason = get_str(body, "reason")?.to_string();
    if !SUCCESSION_REASONS.contains(&reason.as_str()) {
        return Err(VErr::UnknownSuccessionReason(reason));
    }
    Ok(SuccessionBody {
        prev_pk: get_str(body, "prev_pk")?.to_string(),
        next_pk: get_str(body, "next_pk")?.to_string(),
        prev_fp: get_str(body, "prev_fp")?.to_string(),
        next_fp: get_str(body, "next_fp")?.to_string(),
        reason,
        scope_unchanged: get_bool(body, "scope_unchanged")?,
    })
}

/// A claim body. Six of the eight ratified H1.2 §3.1 claim-type shapes are typed:
/// `identity`, `binding`, `action`, `null`, `anomaly`, `succession`. `deployment` and `witness`
/// remain `Untyped` -- the spec itself marks those two rows TBD, deliberately, not guessed at.
#[derive(Debug, Clone, PartialEq)]
pub enum ClaimBody {
    Identity(IdentityBody),
    Binding(BindingBody),
    Action(ActionBody),
    Null(NullBody),
    Anomaly(AnomalyBody),
    Succession(SuccessionBody),
    /// Only ever `deployment` or `witness` in practice -- the two rows the ratified spec marks
    /// TBD. Any other claim type hits `UnknownClaimType` before reaching this arm at all.
    Untyped { claim_type: String, raw: Value },
}

const KNOWN_CLAIM_TYPES: [&str; 8] = [
    "identity", "binding", "action", "null", "anomaly", "succession", "deployment", "witness",
];

fn parse_claim(claim: &Value) -> Result<ClaimBody, VErr> {
    let ctype = get_str(claim, "type")?.to_string();
    if !KNOWN_CLAIM_TYPES.contains(&ctype.as_str()) {
        return Err(VErr::UnknownClaimType(ctype));
    }
    let body = claim.get("body").ok_or(VErr::MissingClaimField("body"))?;
    if body.as_object().is_none() {
        return Err(VErr::ClaimNotAnObject);
    }
    match ctype.as_str() {
        "identity" => Ok(ClaimBody::Identity(parse_identity(body)?)),
        "binding" => Ok(ClaimBody::Binding(parse_binding(body)?)),
        "action" => Ok(ClaimBody::Action(parse_action(body)?)),
        "null" => Ok(ClaimBody::Null(parse_null(body)?)),
        "anomaly" => Ok(ClaimBody::Anomaly(parse_anomaly(body)?)),
        "succession" => Ok(ClaimBody::Succession(parse_succession(body)?)),
        other => Ok(ClaimBody::Untyped { claim_type: other.to_string(), raw: body.clone() }),
    }
}

/// A structurally-validated L8/1.0 Attestation:
/// `{ver, id, sub, claim:{type,body}, ts_unix_ns, ts_rfc3339, prev, sig,
/// pk, wit[], meta:{sentinel,scope,env}}`.
///
/// This checks presence and type of every top-level field and dispatches
/// the claim body per `ClaimBody` above. It does NOT check signatures,
/// `prev` chain linkage, witness validity, or Level — that's a separate
/// concern one layer up (mirrors the real ledger's own Non-Intervention
/// split: structural validity vs semantic/trust judgments).
#[derive(Debug, Clone, PartialEq)]
pub struct Attestation {
    pub ver: String,
    pub id: String,
    pub sub: String,
    pub claim: ClaimBody,
    pub ts_unix_ns: i64,
    pub ts_rfc3339: String,
    pub prev: Option<String>,
    pub sig: String,
    /// Present iff `claim` is `succession` (old-key signature over the same payload `sig`
    /// covers). Was documented above as living at the top level but never actually parsed
    /// here -- added as a real fix while porting H1.4 signature verification onto this crate,
    /// not a new guess: dual-signed succession is established ground truth from earlier work
    /// on this project, not an invention.
    pub auth_sig: Option<String>,
    pub pk: String,
    pub wit: Vec<Value>,
    pub meta: Value,
}

pub fn validate(v: &Value) -> Result<Attestation, VErr> {
    if v.as_object().is_none() {
        return Err(VErr::NotAnObject);
    }
    let claim_val = v.get("claim").ok_or(VErr::MissingField("claim"))?;
    if claim_val.as_object().is_none() {
        return Err(VErr::WrongType("claim"));
    }
    let wit = match v.get("wit") {
        None => Vec::new(),
        Some(Value::Array(items)) => items.clone(),
        Some(_) => return Err(VErr::WrongType("wit")),
    };
    let meta = v.get("meta").cloned().unwrap_or(Value::Object(Vec::new()));
    Ok(Attestation {
        ver: get_str(v, "ver")?.to_string(),
        id: get_str(v, "id")?.to_string(),
        sub: get_str(v, "sub")?.to_string(),
        claim: parse_claim(claim_val)?,
        ts_unix_ns: get_int(v, "ts_unix_ns")?,
        ts_rfc3339: get_str(v, "ts_rfc3339")?.to_string(),
        prev: get_opt_str(v, "prev")?.map(|s| s.to_string()),
        sig: get_str(v, "sig")?.to_string(),
        auth_sig: get_opt_str(v, "auth_sig")?.map(|s| s.to_string()),
        pk: get_str(v, "pk")?.to_string(),
        wit,
        meta,
    })
}
