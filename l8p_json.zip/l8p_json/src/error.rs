use std::fmt;

/// Fixed set of failure classes the bounded decoder can return.
/// A trust boundary must classify every rejection explicitly — no
/// generic "parse error" catch-all that hides which invariant failed.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DecodeError {
    /// Input ended before a complete value was parsed.
    TruncatedInput { at: usize },
    /// Bytes remained after a complete top-level value was parsed.
    TrailingBytes { at: usize },
    /// Byte sequence is not valid UTF-8.
    InvalidUtf8 { at: usize },
    /// A number token is malformed (leading zero, bare '-', empty digits,
    /// a '+' sign, or a fractional/exponent part — see FloatNotAllowed).
    InvalidNumber { at: usize },
    /// A fractional or exponent part was present. The canonical L8/1.0
    /// JSON form carries no floats (ts_unix_ns is integer, ts_rfc3339 is
    /// a string) — floats are a structural rejection, not a parse detail.
    FloatNotAllowed { at: usize },
    /// Integer literal does not fit in i64.
    NumberOutOfRange { at: usize },
    /// An object had two entries with the same key.
    DuplicateKey { at: usize },
    /// An object's keys were not in strict ascending UTF-8 byte order.
    NonCanonicalKeyOrder { at: usize },
    /// Whitespace appeared outside a string literal. Canonical JSON
    /// (JCS/RFC 8785 style) has no insignificant whitespace at all.
    NonCanonicalWhitespace { at: usize },
    /// A string escape was valid JSON but not the canonical minimal form
    /// (e.g. `\/` for `/`, or `\u0041` for `A`).
    NonCanonicalEscape { at: usize },
    /// An unescaped control character (U+0000-U+001F) appeared literally
    /// inside a string.
    UnescapedControlChar { at: usize },
    /// A `\` was followed by something other than one of the fixed
    /// canonical escape letters or a `uXXXX` sequence.
    InvalidEscape { at: usize },
    /// A token did not match any expected value start.
    UnexpectedToken { at: usize },
    /// Nesting depth exceeded the configured bound.
    DepthLimitExceeded { at: usize },
    /// A string exceeded the configured maximum byte length.
    StringTooLong { at: usize },
    /// An array exceeded the configured maximum element count.
    ArrayTooLong { at: usize },
    /// An object exceeded the configured maximum entry count.
    ObjectTooLong { at: usize },
    /// Total input size exceeded the configured aggregate budget.
    InputTooLarge,
}

impl fmt::Display for DecodeError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{:?}", self)
    }
}

impl std::error::Error for DecodeError {}

impl DecodeError {
    /// Stable small index for this variant (ignores any embedded `at`), used by the H1.3
    /// failure log for lifetime per-code counters -- added while porting failure preservation
    /// onto this crate. l8p_core's dataless `FailureCode` could use "position in a fixed ALL
    /// array" for this; these variants carry data, so an explicit match is used instead.
    pub fn tag(&self) -> u8 {
        match self {
            DecodeError::TruncatedInput { .. } => 0,
            DecodeError::TrailingBytes { .. } => 1,
            DecodeError::InvalidUtf8 { .. } => 2,
            DecodeError::InvalidNumber { .. } => 3,
            DecodeError::FloatNotAllowed { .. } => 4,
            DecodeError::NumberOutOfRange { .. } => 5,
            DecodeError::DuplicateKey { .. } => 6,
            DecodeError::NonCanonicalKeyOrder { .. } => 7,
            DecodeError::NonCanonicalWhitespace { .. } => 8,
            DecodeError::NonCanonicalEscape { .. } => 9,
            DecodeError::UnescapedControlChar { .. } => 10,
            DecodeError::InvalidEscape { .. } => 11,
            DecodeError::UnexpectedToken { .. } => 12,
            DecodeError::DepthLimitExceeded { .. } => 13,
            DecodeError::StringTooLong { .. } => 14,
            DecodeError::ArrayTooLong { .. } => 15,
            DecodeError::ObjectTooLong { .. } => 16,
            DecodeError::InputTooLarge => 17,
        }
    }
    pub const TAG_COUNT: usize = 18;

    pub fn code_str(&self) -> &'static str {
        match self {
            DecodeError::TruncatedInput { .. } => "TRUNCATED_INPUT",
            DecodeError::TrailingBytes { .. } => "TRAILING_BYTES",
            DecodeError::InvalidUtf8 { .. } => "INVALID_UTF8",
            DecodeError::InvalidNumber { .. } => "INVALID_NUMBER",
            DecodeError::FloatNotAllowed { .. } => "FLOAT_NOT_ALLOWED",
            DecodeError::NumberOutOfRange { .. } => "NUMBER_OUT_OF_RANGE",
            DecodeError::DuplicateKey { .. } => "DUPLICATE_KEY",
            DecodeError::NonCanonicalKeyOrder { .. } => "NON_CANONICAL_KEY_ORDER",
            DecodeError::NonCanonicalWhitespace { .. } => "NON_CANONICAL_WHITESPACE",
            DecodeError::NonCanonicalEscape { .. } => "NON_CANONICAL_ESCAPE",
            DecodeError::UnescapedControlChar { .. } => "UNESCAPED_CONTROL_CHAR",
            DecodeError::InvalidEscape { .. } => "INVALID_ESCAPE",
            DecodeError::UnexpectedToken { .. } => "UNEXPECTED_TOKEN",
            DecodeError::DepthLimitExceeded { .. } => "DEPTH_LIMIT_EXCEEDED",
            DecodeError::StringTooLong { .. } => "STRING_TOO_LONG",
            DecodeError::ArrayTooLong { .. } => "ARRAY_TOO_LONG",
            DecodeError::ObjectTooLong { .. } => "OBJECT_TOO_LONG",
            DecodeError::InputTooLarge => "INPUT_TOO_LARGE",
        }
    }
}
