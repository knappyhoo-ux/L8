use super::decoder::DecodedValue;

fn escape_string(s: &str, o: &mut Vec<u8>) {
    o.push(b'"');
    for b in s.bytes() {
        match b {
            b'"' => o.extend_from_slice(b"\\\""),
            b'\\' => o.extend_from_slice(b"\\\\"),
            0x08 => o.extend_from_slice(b"\\b"),
            0x0C => o.extend_from_slice(b"\\f"),
            b'\n' => o.extend_from_slice(b"\\n"),
            b'\r' => o.extend_from_slice(b"\\r"),
            b'\t' => o.extend_from_slice(b"\\t"),
            0x00..=0x1F => o.extend_from_slice(format!("\\u{:04x}", b).as_bytes()),
            _ => o.push(b), // ASCII printable or a raw UTF-8 continuation/lead byte, passed through verbatim
        }
    }
    o.push(b'"');
}

/// Canonical JSON encoding: no insignificant whitespace, minimal escaping, object keys always
/// re-sorted regardless of construction order (defensive -- the decoder's canonical-order
/// invariant should already hold for anything it produced, but the encoder never assumes it).
/// Property (tested): for every input the decoder accepts, encode(decode(x)) == x.
pub fn encode(v: &DecodedValue) -> Vec<u8> {
    let mut o = Vec::new();
    encode_into(v, &mut o);
    o
}

fn encode_into(v: &DecodedValue, o: &mut Vec<u8>) {
    match v {
        DecodedValue::Uint(n) => o.extend_from_slice(n.to_string().as_bytes()),
        DecodedValue::NegInt(n) => {
            o.push(b'-');
            o.extend_from_slice((*n + 1).to_string().as_bytes());
        }
        DecodedValue::Text(s) => escape_string(s, o),
        DecodedValue::Array(a) => {
            o.push(b'[');
            for (i, x) in a.iter().enumerate() {
                if i > 0 { o.push(b','); }
                encode_into(x, o);
            }
            o.push(b']');
        }
        DecodedValue::Map(m) => {
            let mut sorted: Vec<&(DecodedValue, DecodedValue)> = m.iter().collect();
            sorted.sort_by(|a, b| key_text(&a.0).cmp(key_text(&b.0)));
            o.push(b'{');
            for (i, (k, val)) in sorted.iter().enumerate() {
                if i > 0 { o.push(b','); }
                encode_into(k, o);
                o.push(b':');
                encode_into(val, o);
            }
            o.push(b'}');
        }
        DecodedValue::Bool(false) => o.extend_from_slice(b"false"),
        DecodedValue::Bool(true) => o.extend_from_slice(b"true"),
        DecodedValue::Null => o.extend_from_slice(b"null"),
    }
}

fn key_text(k: &DecodedValue) -> &str {
    match k {
        DecodedValue::Text(s) => s.as_str(),
        _ => "", // JSON object keys are always Text for any value this crate constructs
    }
}

/// Build a canonically ordered map (sorted by key) from unordered pairs.
pub fn canonical_map(pairs: Vec<(DecodedValue, DecodedValue)>) -> DecodedValue {
    // encode() re-sorts on its own, so construction order doesn't matter; this just gives
    // callers (emit/mod.rs, checkpoint.rs) the same ergonomic entry point the CBOR encoder had.
    DecodedValue::Map(pairs)
}
