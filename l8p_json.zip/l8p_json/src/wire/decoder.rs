use super::errors::{DecodeError, FailureCode};
use super::limits::Limits;

/// Untyped, structurally admissible value decoded from strict canonical JSON.
/// No identity/signature/provenance meaning is attached here (that's the model/validate layer).
/// `NegInt(n)` represents the value `-1 - n` (mirrors the CBOR-era encoding so negative
/// integers never need a signed-overflow-prone i64 path). No `Bytes` variant: JSON has no
/// byte-string primitive, so binary fields (pk/sig/wit digests) travel as base64url `Text`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DecodedValue {
    Uint(u64),
    NegInt(u64),
    Text(String),
    Array(Vec<DecodedValue>),
    /// Ordered pairs exactly as they appear on the wire (already verified canonically
    /// sorted by key, no duplicates). Keys are always `Text` in valid JSON objects.
    Map(Vec<(DecodedValue, DecodedValue)>),
    Bool(bool),
    Null,
}

struct Ctx<'a> {
    buf: &'a [u8],
    pos: usize,
    limits: &'a Limits,
    items: usize,
    max_depth: usize,
}

fn err<T>(code: FailureCode, offset: usize) -> Result<T, DecodeError> {
    Err(DecodeError::new(code, offset))
}

/// Canonical JSON object-key order (JCS/RFC 8785-style): lexicographic over the key's
/// Unicode scalar sequence. Rust's `str`/`String` `Ord` compares by UTF-8 byte value, which
/// agrees with codepoint order for the BMP; treated as the working definition here.
fn key_order(a: &str, b: &str) -> std::cmp::Ordering {
    a.cmp(b)
}

/// Decode a bare canonical-JSON payload (no envelope). Deterministic and total: never panics.
pub fn decode(payload: &[u8], limits: &Limits) -> Result<DecodedValue, DecodeError> {
    if payload.len() > limits.max_envelope_bytes {
        return err(FailureCode::EnvelopeOversize, 0);
    }
    let mut c = Ctx { buf: payload, pos: 0, limits, items: 0, max_depth: limits.effective_depth() };
    let v = c.value(0)?;
    if c.pos != payload.len() {
        return err(FailureCode::InvalidJson, c.pos);
    }
    Ok(v)
}

impl<'a> Ctx<'a> {
    fn peek(&self) -> Option<u8> {
        self.buf.get(self.pos).copied()
    }
    fn bump_items(&mut self, offset: usize) -> Result<(), DecodeError> {
        self.items += 1;
        if self.items > self.limits.max_total_items {
            return err(FailureCode::BudgetExceeded, offset);
        }
        Ok(())
    }
    fn expect(&mut self, b: u8, offset: usize) -> Result<(), DecodeError> {
        if self.peek() == Some(b) {
            self.pos += 1;
            Ok(())
        } else if self.pos >= self.buf.len() {
            err(FailureCode::Truncated, self.buf.len())
        } else {
            err(FailureCode::InvalidJson, offset)
        }
    }

    fn value(&mut self, depth: usize) -> Result<DecodedValue, DecodeError> {
        if depth > self.max_depth {
            return err(FailureCode::DepthExceeded, self.pos);
        }
        let start = self.pos;
        self.bump_items(start)?;
        match self.peek() {
            None => err(FailureCode::Truncated, self.buf.len()),
            Some(b'{') => self.object(depth),
            Some(b'[') => self.array(depth),
            Some(b'"') => self.string().map(DecodedValue::Text),
            Some(b't') => self.literal(b"true", DecodedValue::Bool(true)),
            Some(b'f') => self.literal(b"false", DecodedValue::Bool(false)),
            Some(b'n') => self.literal(b"null", DecodedValue::Null),
            Some(b'-') | Some(b'0'..=b'9') => self.number(),
            Some(_) => err(FailureCode::InvalidJson, start),
        }
    }

    fn literal(&mut self, lit: &'static [u8], val: DecodedValue) -> Result<DecodedValue, DecodeError> {
        let start = self.pos;
        if self.buf.len() < start + lit.len() {
            return err(FailureCode::Truncated, self.buf.len());
        }
        if &self.buf[start..start + lit.len()] != lit {
            return err(FailureCode::InvalidJson, start);
        }
        self.pos += lit.len();
        Ok(val)
    }

    fn number(&mut self) -> Result<DecodedValue, DecodeError> {
        let start = self.pos;
        let neg = self.peek() == Some(b'-');
        if neg {
            self.pos += 1;
        }
        let digits_start = self.pos;
        if self.peek().is_none() {
            return err(FailureCode::Truncated, self.buf.len());
        }
        if !matches!(self.peek(), Some(b'0'..=b'9')) {
            return err(FailureCode::InvalidJson, start);
        }
        let first = self.peek().unwrap();
        self.pos += 1;
        if first == b'0' {
            // Leading zero: "0" itself is fine, but "0<more digits>" is non-canonical/invalid.
            if matches!(self.peek(), Some(b'0'..=b'9')) {
                return err(FailureCode::NonCanonical, digits_start);
            }
        } else {
            while matches!(self.peek(), Some(b'0'..=b'9')) {
                self.pos += 1;
            }
        }
        // No floats: a following '.', 'e' or 'E' is explicitly rejected rather than left to
        // surface as a generic "unexpected trailing bytes" error.
        if matches!(self.peek(), Some(b'.') | Some(b'e') | Some(b'E')) {
            return err(FailureCode::InvalidJson, self.pos);
        }
        let digits = std::str::from_utf8(&self.buf[digits_start..self.pos]).unwrap();
        let magnitude: u64 = match digits.parse() {
            Ok(v) => v,
            Err(_) => return err(FailureCode::InvalidJson, start),
        };
        if neg {
            if magnitude == 0 {
                return err(FailureCode::NonCanonical, start); // "-0" forbidden
            }
            Ok(DecodedValue::NegInt(magnitude - 1))
        } else {
            Ok(DecodedValue::Uint(magnitude))
        }
    }

    fn string(&mut self) -> Result<String, DecodeError> {
        let start = self.pos;
        self.expect(b'"', start)?;
        let mut out: Vec<u8> = Vec::new();
        loop {
            let b = match self.peek() {
                Some(b) => b,
                None => return err(FailureCode::Truncated, self.buf.len()),
            };
            match b {
                b'"' => {
                    self.pos += 1;
                    return String::from_utf8(out).map_err(|_| DecodeError::new(FailureCode::InvalidJson, start));
                }
                b'\\' => {
                    let esc_pos = self.pos;
                    self.pos += 1;
                    let e = match self.peek() {
                        Some(e) => e,
                        None => return err(FailureCode::Truncated, self.buf.len()),
                    };
                    match e {
                        b'"' => { out.push(b'"'); self.pos += 1; }
                        b'\\' => { out.push(b'\\'); self.pos += 1; }
                        b'b' => { out.push(0x08); self.pos += 1; }
                        b'f' => { out.push(0x0C); self.pos += 1; }
                        b'n' => { out.push(b'\n'); self.pos += 1; }
                        b'r' => { out.push(b'\r'); self.pos += 1; }
                        b't' => { out.push(b'\t'); self.pos += 1; }
                        b'u' => {
                            self.pos += 1;
                            if self.pos + 4 > self.buf.len() {
                                return err(FailureCode::Truncated, self.buf.len());
                            }
                            let hex = std::str::from_utf8(&self.buf[self.pos..self.pos + 4])
                                .map_err(|_| DecodeError::new(FailureCode::InvalidJson, self.pos))?;
                            let cp = u16::from_str_radix(hex, 16)
                                .map_err(|_| DecodeError::new(FailureCode::InvalidJson, self.pos))?;
                            self.pos += 4;
                            // Minimal escaping: \uXXXX is only canonical for control characters
                            // with no named escape (0x00-0x07, 0x0B, 0x0E-0x1F). Everything else
                            // -- including the named-escape values and any char >= 0x20, and any
                            // surrogate (>= 0xD800) -- must appear either as a named escape or as
                            // raw (possibly multi-byte) UTF-8, never via \u.
                            let canonical_u = matches!(cp, 0x00..=0x07 | 0x0B | 0x0E..=0x1F);
                            if !canonical_u {
                                return err(FailureCode::NonCanonical, esc_pos);
                            }
                            out.push(cp as u8);
                        }
                        _ => return err(FailureCode::NonCanonical, esc_pos), // e.g. non-minimal "\/"
                    }
                }
                0x00..=0x1F => return err(FailureCode::InvalidJson, self.pos), // raw control char, must be escaped
                0x20..=0x7F => { out.push(b); self.pos += 1; }
                _ => {
                    // Multi-byte UTF-8 lead byte; consume the expected continuation bytes.
                    let need = if b & 0xE0 == 0xC0 { 1 }
                        else if b & 0xF0 == 0xE0 { 2 }
                        else if b & 0xF8 == 0xF0 { 3 }
                        else { return err(FailureCode::InvalidJson, self.pos); };
                    if self.pos + 1 + need > self.buf.len() {
                        return err(FailureCode::Truncated, self.buf.len());
                    }
                    for i in 1..=need {
                        if self.buf[self.pos + i] & 0xC0 != 0x80 {
                            return err(FailureCode::InvalidJson, self.pos);
                        }
                    }
                    out.extend_from_slice(&self.buf[self.pos..self.pos + 1 + need]);
                    self.pos += 1 + need;
                }
            }
            if out.len() > self.limits.max_text_len {
                return err(FailureCode::LengthLimitExceeded, self.pos);
            }
        }
    }

    fn array(&mut self, depth: usize) -> Result<DecodedValue, DecodeError> {
        let start = self.pos;
        self.expect(b'[', start)?;
        let mut items = Vec::new();
        if self.peek() == Some(b']') {
            self.pos += 1;
            return Ok(DecodedValue::Array(items));
        }
        loop {
            let v = self.value(depth + 1)?;
            items.push(v);
            if items.len() > self.limits.max_elements {
                return err(FailureCode::ElementLimitExceeded, self.pos);
            }
            match self.peek() {
                Some(b',') => { self.pos += 1; }
                Some(b']') => { self.pos += 1; return Ok(DecodedValue::Array(items)); }
                Some(_) => return err(FailureCode::InvalidJson, self.pos),
                None => return err(FailureCode::Truncated, self.buf.len()),
            }
        }
    }

    fn object(&mut self, depth: usize) -> Result<DecodedValue, DecodeError> {
        let start = self.pos;
        self.expect(b'{', start)?;
        let mut pairs: Vec<(DecodedValue, DecodedValue)> = Vec::new();
        let mut last_key: Option<String> = None;
        if self.peek() == Some(b'}') {
            self.pos += 1;
            return Ok(DecodedValue::Map(pairs));
        }
        loop {
            let key_pos = self.pos;
            let key = self.string()?;
            if let Some(lk) = &last_key {
                match key_order(lk, &key) {
                    std::cmp::Ordering::Equal => return err(FailureCode::DuplicateKey, key_pos),
                    std::cmp::Ordering::Greater => return err(FailureCode::NonCanonical, key_pos),
                    std::cmp::Ordering::Less => {}
                }
            }
            self.expect(b':', self.pos)?;
            let v = self.value(depth + 1)?;
            last_key = Some(key.clone());
            pairs.push((DecodedValue::Text(key), v));
            if pairs.len() > self.limits.max_elements {
                return err(FailureCode::ElementLimitExceeded, self.pos);
            }
            match self.peek() {
                Some(b',') => { self.pos += 1; }
                Some(b'}') => { self.pos += 1; return Ok(DecodedValue::Map(pairs)); }
                Some(_) => return err(FailureCode::InvalidJson, self.pos),
                None => return err(FailureCode::Truncated, self.buf.len()),
            }
        }
    }
}
