use crate::wire::DecodedValue;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ClaimType {
    Identity,
    Binding,
    Action,
    Null,
    Anomaly,
    Succession,
    Deployment,
    Witness,
}

impl ClaimType {
    pub fn parse(s: &str) -> Option<ClaimType> {
        Some(match s {
            "identity" => ClaimType::Identity,
            "binding" => ClaimType::Binding,
            "action" => ClaimType::Action,
            "null" => ClaimType::Null,
            "anomaly" => ClaimType::Anomaly,
            "succession" => ClaimType::Succession,
            "deployment" => ClaimType::Deployment,
            "witness" => ClaimType::Witness,
            _ => return None,
        })
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SuccessionReason { KeyRotation, AlgorithmMigration, CompromiseRecovery, ScheduledEvolution }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RevocationReason { UserRequest, BreachResponse, LegalOrder, ScheduledExpiration }

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Succession {
    pub prev_pk: String,
    pub next_pk: String,
    pub prev_fp: String,
    pub next_fp: String,
    pub reason: SuccessionReason,
    pub scope_unchanged: bool,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct IdentityRevocation {
    pub subject: String,
    pub reason: RevocationReason,
    pub revoked_at: String,
    pub effective_at: String,
    pub authorized_by: String,
    pub replaced_by: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ClaimBody {
    Succession(Succession),
    IdentityRevocation(IdentityRevocation),
    /// Body verified to be a text-keyed map only; deeper schema deliberately NOT asserted (shape not confirmed).
    Unspecified(Vec<(String, DecodedValue)>),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Claim {
    pub claim_type: ClaimType,
    pub body: ClaimBody,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Meta {
    pub sentinel: String,
    pub scope: String,
    pub env: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Attestation {
    pub ver: String,
    pub id: String,
    pub sub: String,
    pub claim: Claim,
    pub ts_unix_ns: u64,
    pub ts_rfc3339: String,
    pub prev: Option<String>,
    pub sig: String,
    pub auth_sig: Option<String>,
    pub pk: String,
    pub wit: Vec<Vec<(String, DecodedValue)>>,
    pub meta: Meta,
}
