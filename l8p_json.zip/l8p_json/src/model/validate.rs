use super::attestation::*;
use super::errors::{ValidationCode as C, ValidationError};
use crate::wire::DecodedValue as V;

type R<T> = Result<T, ValidationError>;

fn e<T>(code: C, path: &str) -> R<T> { Err(ValidationError::new(code, path)) }
fn join(base: &str, k: &str) -> String { if base.is_empty() { k.to_string() } else { format!("{}.{}", base, k) } }

struct Fields<'a> {
    base: String,
    entries: Vec<(&'a str, &'a V, bool)>,
}

impl<'a> Fields<'a> {
    fn new(v: &'a V, base: &str) -> R<Fields<'a>> {
        let pairs = match v { V::Map(p) => p, _ => return e(C::NotAMap, base) };
        let mut entries = Vec::with_capacity(pairs.len());
        for (k, val) in pairs {
            match k {
                V::Text(s) => entries.push((s.as_str(), val, false)),
                _ => return e(C::WrongType, &join(base, "<key>")),
            }
        }
        Ok(Fields { base: base.to_string(), entries })
    }
    fn opt(&mut self, name: &str) -> Option<&'a V> {
        for en in self.entries.iter_mut() {
            if en.0 == name { en.2 = true; return Some(en.1); }
        }
        None
    }
    fn req(&mut self, name: &str) -> R<&'a V> {
        match self.opt(name) { Some(v) => Ok(v), None => e(C::MissingField, &join(&self.base, name)) }
    }
    fn finish(&self) -> R<()> {
        for en in &self.entries {
            if !en.2 { return e(C::UnknownField, &join(&self.base, en.0)); }
        }
        Ok(())
    }
    fn path(&self, name: &str) -> String { join(&self.base, name) }
}

fn text<'a>(v: &'a V, path: &str) -> R<&'a str> {
    match v { V::Text(s) => Ok(s.as_str()), _ => e(C::WrongType, path) }
}

pub const MAX_ID_TEXT: usize = 256;

fn is_uuid(s: &str) -> bool {
    let b = s.as_bytes();
    if b.len() != 36 { return false; }
    b.iter().enumerate().all(|(i, c)| match i {
        8 | 13 | 18 | 23 => *c == b'-',
        _ => matches!(c, b'0'..=b'9' | b'a'..=b'f'),
    })
}

/// Unpadded base64url alphabet, non-empty, plausible length (len % 4 != 1). Not decoded, shape only.
fn is_b64url(s: &str) -> bool {
    !s.is_empty() && s.len() <= 1024 && s.len() % 4 != 1
        && s.bytes().all(|c| matches!(c, b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_'))
}

/// RFC 3339 SHAPE check with per-field ranges (month 01-12, day 01-31, hour 00-23, minute 00-59, second 00-60).
/// Does NOT check calendar validity (e.g. 02-30 passes) - that would need date arithmetic.
fn is_rfc3339(s: &str) -> bool {
    let b = s.as_bytes();
    if b.len() < 20 { return false; }
    let d = |i: usize| b[i].is_ascii_digit();
    let n2 = |i: usize| ((b[i] - b'0') * 10 + (b[i + 1] - b'0')) as u32;
    if !(d(0) && d(1) && d(2) && d(3) && b[4] == b'-' && d(5) && d(6) && b[7] == b'-' && d(8) && d(9)) { return false; }
    if b[10] != b'T' { return false; }
    if !(d(11) && d(12) && b[13] == b':' && d(14) && d(15) && b[16] == b':' && d(17) && d(18)) { return false; }
    let (mo, dy, hh, mi, ss) = (n2(5), n2(8), n2(11), n2(14), n2(17));
    if !(1..=12).contains(&mo) || !(1..=31).contains(&dy) || hh > 23 || mi > 59 || ss > 60 { return false; }
    let mut i = 19;
    if b[i] == b'.' {
        i += 1;
        let st = i;
        while i < b.len() && b[i].is_ascii_digit() { i += 1; }
        if i == st { return false; }
    }
    if i >= b.len() { return false; }
    match b[i] {
        b'Z' => i + 1 == b.len(),
        b'+' | b'-' => i + 6 == b.len() && d(i + 1) && d(i + 2) && b[i + 3] == b':' && d(i + 4) && d(i + 5)
            && n2(i + 1) <= 23 && n2(i + 4) <= 59,
        _ => false,
    }
}

fn id_text(v: &V, path: &str) -> R<String> {
    let s = text(v, path)?;
    if s.is_empty() || s.len() > MAX_ID_TEXT { return e(C::InvalidValue, path); }
    Ok(s.to_string())
}
fn b64(v: &V, path: &str) -> R<String> {
    let s = text(v, path)?;
    if !is_b64url(s) { return e(C::InvalidValue, path); }
    Ok(s.to_string())
}
fn ts(v: &V, path: &str) -> R<String> {
    let s = text(v, path)?;
    if !is_rfc3339(s) { return e(C::InvalidValue, path); }
    Ok(s.to_string())
}

fn generic_map(v: &V, path: &str) -> R<Vec<(String, V)>> {
    let pairs = match v { V::Map(p) => p, _ => return e(C::NotAMap, path) };
    let mut out = Vec::with_capacity(pairs.len());
    for (k, val) in pairs {
        match k { V::Text(s) => out.push((s.clone(), val.clone())), _ => return e(C::WrongType, &join(path, "<key>")) }
    }
    Ok(out)
}

fn succession(v: &V, base: &str) -> R<Succession> {
    let mut f = Fields::new(v, base)?;
    let prev_pk = b64(f.req("prev_pk")?, &f.path("prev_pk"))?;
    let next_pk = b64(f.req("next_pk")?, &f.path("next_pk"))?;
    let prev_fp = b64(f.req("prev_fp")?, &f.path("prev_fp"))?;
    let next_fp = b64(f.req("next_fp")?, &f.path("next_fp"))?;
    let rp = f.path("reason");
    let reason = match text(f.req("reason")?, &rp)? {
        "key_rotation" => SuccessionReason::KeyRotation,
        "algorithm_migration" => SuccessionReason::AlgorithmMigration,
        "compromise_recovery" => SuccessionReason::CompromiseRecovery,
        "scheduled_evolution" => SuccessionReason::ScheduledEvolution,
        _ => return e(C::InvalidValue, &rp),
    };
    let sp = f.path("scope_unchanged");
    let scope_unchanged = match f.req("scope_unchanged")? { V::Bool(b) => *b, _ => return e(C::WrongType, &sp) };
    f.finish()?;
    Ok(Succession { prev_pk, next_pk, prev_fp, next_fp, reason, scope_unchanged })
}

fn revocation(f: &mut Fields, base: &str) -> R<IdentityRevocation> {
    let _ = f.req("action_type")?; // already matched by caller
    let subject = id_text(f.req("subject")?, &join(base, "subject"))?;
    let rp = join(base, "reason");
    let reason = match text(f.req("reason")?, &rp)? {
        "user_request" => RevocationReason::UserRequest,
        "breach_response" => RevocationReason::BreachResponse,
        "legal_order" => RevocationReason::LegalOrder,
        "scheduled_expiration" => RevocationReason::ScheduledExpiration,
        _ => return e(C::InvalidValue, &rp),
    };
    let revoked_at = ts(f.req("revoked_at")?, &join(base, "revoked_at"))?;
    let effective_at = ts(f.req("effective_at")?, &join(base, "effective_at"))?;
    let authorized_by = id_text(f.req("authorized_by")?, &join(base, "authorized_by"))?;
    let rbp = join(base, "replaced_by");
    let replaced_by = match f.req("replaced_by")? { V::Null => None, v => Some(id_text(v, &rbp)?) };
    f.finish()?;
    Ok(IdentityRevocation { subject, reason, revoked_at, effective_at, authorized_by, replaced_by })
}

fn claim(v: &V) -> R<Claim> {
    let mut f = Fields::new(v, "claim")?;
    let tp = f.path("type");
    let ct_s = text(f.req("type")?, &tp)?;
    let claim_type = match ClaimType::parse(ct_s) { Some(c) => c, None => return e(C::UnknownClaimType, &tp) };
    let body_v = f.req("body")?;
    f.finish()?;
    let bp = "claim.body";
    let body = match claim_type {
        ClaimType::Succession => ClaimBody::Succession(succession(body_v, bp)?),
        ClaimType::Action => {
            let mut bf = Fields::new(body_v, bp)?;
            let is_rev = matches!(bf.entries.iter().find(|x| x.0 == "action_type"), Some((_, V::Text(s), _)) if s == "identity_revocation");
            if is_rev {
                ClaimBody::IdentityRevocation(revocation(&mut bf, bp)?)
            } else {
                ClaimBody::Unspecified(generic_map(body_v, bp)?)
            }
        }
        _ => ClaimBody::Unspecified(generic_map(body_v, bp)?),
    };
    Ok(Claim { claim_type, body })
}

/// Pure structural validation: H1.1 output -> typed Attestation. No signature, provenance, chain or Level checks (H1.3+/later).
pub fn validate(decoded: &V) -> Result<Attestation, ValidationError> {
    let mut f = Fields::new(decoded, "")?;
    let vp = f.path("ver");
    let ver = text(f.req("ver")?, &vp)?;
    if ver != "L8/1.0" { return e(C::InvalidValue, &vp); }
    let idp = f.path("id");
    let id = text(f.req("id")?, &idp)?;
    if !is_uuid(id) { return e(C::InvalidValue, &idp); }
    let sub = id_text(f.req("sub")?, &f.path("sub"))?;
    let claim = claim(f.req("claim")?)?;
    let tsp = f.path("ts_unix_ns");
    let ts_unix_ns = match f.req("ts_unix_ns")? { V::Uint(n) => *n, _ => return e(C::WrongType, &tsp) };
    let ts_rfc3339 = ts(f.req("ts_rfc3339")?, &f.path("ts_rfc3339"))?;
    let pp = f.path("prev");
    let prev = match f.req("prev")? { V::Null => None, v => Some(b64(v, &pp)?) };
    let sig = b64(f.req("sig")?, &f.path("sig"))?;
    let pk = b64(f.req("pk")?, &f.path("pk"))?;
    let wp = f.path("wit");
    let wit = match f.req("wit")? {
        V::Array(items) => {
            let mut out = Vec::with_capacity(items.len());
            for (i, it) in items.iter().enumerate() { out.push(generic_map(it, &format!("wit[{}]", i))?); }
            out
        }
        _ => return e(C::WrongType, &wp),
    };
    let mut mf = Fields::new(f.req("meta")?, "meta")?;
    let sentinel = text(mf.req("sentinel")?, "meta.sentinel")?.to_string();
    let scope = text(mf.req("scope")?, "meta.scope")?.to_string();
    let env = text(mf.req("env")?, "meta.env")?.to_string();
    mf.finish()?;
    // auth_sig: REQUIRED for succession, FORBIDDEN otherwise.
    let ap = f.path("auth_sig");
    let auth_sig = match (f.opt("auth_sig"), claim.claim_type == ClaimType::Succession) {
        (Some(v), true) => Some(b64(v, &ap)?),
        (None, true) => return e(C::MissingField, &ap),
        (Some(_), false) => return e(C::ConditionalField, &ap),
        (None, false) => None,
    };
    f.finish()?;
    Ok(Attestation { ver: ver.to_string(), id: id.to_string(), sub, claim, ts_unix_ns, ts_rfc3339, prev, sig, auth_sig, pk, wit, meta: Meta { sentinel, scope, env } })
}
