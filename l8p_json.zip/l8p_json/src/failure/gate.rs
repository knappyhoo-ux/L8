use super::log::{FailureLog, LogConfig};
use super::record::FailureKind;
use crate::attestation::{validate, Attestation};
use crate::decode::decode;
use crate::limits::Limits;
use crate::verify::verify_signatures;

#[derive(Debug)]
pub enum Admission {
    Accepted(Attestation),
    Rejected { seq: u64 },
}

/// Combined structural-admission (H1.1/H1.2-equivalent) and, optionally, signature
/// verification (H1.4) gate, backed by an H1.3 failure-preserving log. Unlike l8p_core's
/// CBOR-era `Gate`, `admit()` takes raw canonical JSON bytes directly -- this crate has no
/// envelope/length-prefix framing, since JSON's own braces self-delimit a single value.
pub struct Gate {
    verify_sigs: bool,
    limits: Limits,
    log: FailureLog,
    accepted: u64,
}

impl Gate {
    /// Structural admission only -- does not check signatures.
    pub fn new(limits: Limits, log_cfg: LogConfig) -> Self {
        Gate { verify_sigs: false, limits, log: FailureLog::new(log_cfg), accepted: 0 }
    }
    /// Structural admission AND Ed25519 signature verification (H1.4).
    pub fn new_verifying(limits: Limits, log_cfg: LogConfig) -> Self {
        Gate { verify_sigs: true, limits, log: FailureLog::new(log_cfg), accepted: 0 }
    }

    pub fn admit(&mut self, input: &[u8]) -> Admission {
        let decoded = match decode(input, &self.limits) {
            Ok(v) => v,
            Err(e) => {
                let seq = self.log.record(FailureKind::Wire(e), input);
                return Admission::Rejected { seq };
            }
        };
        let att = match validate(&decoded) {
            Ok(a) => a,
            Err(e) => {
                let seq = self.log.record(FailureKind::Structure(e), input);
                return Admission::Rejected { seq };
            }
        };
        if self.verify_sigs {
            if let Err(e) = verify_signatures(&decoded, &att) {
                let seq = self.log.record(FailureKind::Signature(e), input);
                return Admission::Rejected { seq };
            }
        }
        self.accepted += 1;
        Admission::Accepted(att)
    }

    pub fn accepted_count(&self) -> u64 { self.accepted }
    pub fn log(&self) -> &FailureLog { &self.log }
}
