use crate::error::DecodeError;
use crate::hash::blake3_hash;
use crate::validation_error::ValidationError;
use crate::verify::SigError;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Stage { Wire = 0, Structure = 1, Signature = 2 }

/// The three stages a submitted input can be rejected at, each carrying its own real error
/// value (not a stripped-down code) -- Wire = `decode()` failed, Structure = `validate()`
/// failed, Signature = `verify_signatures()` failed.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum FailureKind {
    Wire(DecodeError),
    Structure(ValidationError),
    Signature(SigError),
}

impl FailureKind {
    pub fn stage(&self) -> Stage {
        match self {
            FailureKind::Wire(_) => Stage::Wire,
            FailureKind::Structure(_) => Stage::Structure,
            FailureKind::Signature(_) => Stage::Signature,
        }
    }
    pub fn code_str(&self) -> &'static str {
        match self {
            FailureKind::Wire(e) => e.code_str(),
            FailureKind::Structure(e) => e.code_str(),
            FailureKind::Signature(e) => e.code.as_str(),
        }
    }
    pub fn tag(&self) -> u8 {
        match self {
            FailureKind::Wire(e) => e.tag(),
            FailureKind::Structure(e) => e.tag(),
            FailureKind::Signature(e) => e.code.tag(),
        }
    }
}

pub const GENESIS: [u8; 32] = [0u8; 32];

/// One preserved rejection. No wall-clock time is recorded: records are a pure function of the
/// input sequence, matching l8p_core's H1.3 design.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct FailureRecord {
    pub seq: u64,
    pub kind: FailureKind,
    /// Length of the FULL rejected input.
    pub input_len: u64,
    /// BLAKE3 over the FULL rejected input (not just the captured prefix) -- l8p_core used
    /// SHA3-256 here; this crate's ratified hash is BLAKE3, so that's what's used throughout.
    pub input_digest: [u8; 32],
    /// Bounded raw prefix of the input (may be empty by configuration).
    pub capture: Vec<u8>,
    pub prev_digest: [u8; 32],
    pub digest: [u8; 32],
}

impl FailureRecord {
    /// Unambiguous, length-prefixed local layout. Local to this log; NOT an L8 wire format.
    pub fn digest_preimage(&self) -> Vec<u8> {
        let mut o = Vec::with_capacity(96 + self.capture.len());
        o.push(1u8); // layout version
        o.extend_from_slice(&self.seq.to_be_bytes());
        o.push(self.kind.stage() as u8);
        o.push(self.kind.tag());
        o.extend_from_slice(&self.input_len.to_be_bytes());
        o.extend_from_slice(&self.input_digest);
        o.extend_from_slice(&(self.capture.len() as u32).to_be_bytes());
        o.extend_from_slice(&self.capture);
        o.extend_from_slice(&self.prev_digest);
        o
    }
    pub fn compute_digest(&self) -> [u8; 32] { blake3_hash(&self.digest_preimage()) }
}
