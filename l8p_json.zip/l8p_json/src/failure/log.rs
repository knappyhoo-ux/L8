use super::record::{FailureKind, FailureRecord, GENESIS};
use crate::error::DecodeError;
use crate::hash::blake3_hash;
use crate::validation_error::ValidationError;
use crate::verify::SigCode;
use std::collections::VecDeque;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct LogConfig {
    pub max_records: usize,
    pub max_capture: usize,
}
impl Default for LogConfig {
    fn default() -> Self { LogConfig { max_records: 1024, max_capture: 64 } }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum LogError {
    SeqGap { index: usize },
    ChainBroken { index: usize },
    DigestMismatch { index: usize },
    HeadMismatch,
    CountMismatch,
}

#[derive(Clone, Debug)]
pub struct FailureLog {
    cfg: LogConfig,
    records: VecDeque<FailureRecord>,
    next_seq: u64,
    head: [u8; 32],
    anchor: [u8; 32],
    evicted: u64,
    wire_counts: [u64; DecodeError::TAG_COUNT],
    structure_counts: [u64; ValidationError::TAG_COUNT],
    signature_counts: [u64; SigCode::TAG_COUNT],
}

impl FailureLog {
    pub fn new(mut cfg: LogConfig) -> Self {
        if cfg.max_records == 0 { cfg.max_records = 1; }
        FailureLog {
            cfg, records: VecDeque::new(), next_seq: 0, head: GENESIS, anchor: GENESIS, evicted: 0,
            wire_counts: [0; DecodeError::TAG_COUNT],
            structure_counts: [0; ValidationError::TAG_COUNT],
            signature_counts: [0; SigCode::TAG_COUNT],
        }
    }

    /// Preserve one rejection against the FULL rejected input. Total: never panics, never
    /// drops silently (eviction is accounted for via `anchor`/`evicted`).
    pub fn record(&mut self, kind: FailureKind, input: &[u8]) -> u64 {
        let seq = self.next_seq;
        let cap = self.cfg.max_capture.min(input.len());
        let mut rec = FailureRecord {
            seq,
            kind: kind.clone(),
            input_len: input.len() as u64,
            input_digest: blake3_hash(input),
            capture: input[..cap].to_vec(),
            prev_digest: self.head,
            digest: GENESIS,
        };
        rec.digest = rec.compute_digest();
        self.head = rec.digest;
        self.next_seq = self.next_seq.saturating_add(1);
        let t = kind.tag() as usize;
        match kind {
            FailureKind::Wire(_) => if let Some(c) = self.wire_counts.get_mut(t) { *c = c.saturating_add(1); },
            FailureKind::Structure(_) => if let Some(c) = self.structure_counts.get_mut(t) { *c = c.saturating_add(1); },
            FailureKind::Signature(_) => if let Some(c) = self.signature_counts.get_mut(t) { *c = c.saturating_add(1); },
        }
        self.records.push_back(rec);
        while self.records.len() > self.cfg.max_records {
            if let Some(old) = self.records.pop_front() {
                self.anchor = old.digest;
                self.evicted = self.evicted.saturating_add(1);
            }
        }
        seq
    }

    pub fn retained(&self) -> usize { self.records.len() }
    pub fn evicted(&self) -> u64 { self.evicted }
    pub fn total_rejected(&self) -> u64 { self.next_seq }
    pub fn head(&self) -> [u8; 32] { self.head }
    /// Digest of the most recently evicted record (genesis if none evicted).
    pub fn anchor(&self) -> [u8; 32] { self.anchor }
    pub fn records(&self) -> impl Iterator<Item = &FailureRecord> { self.records.iter() }
    pub fn snapshot(&self) -> LogSnapshot {
        LogSnapshot { records: self.records.iter().cloned().collect(), anchor: self.anchor, evicted: self.evicted, head: self.head, next_seq: self.next_seq }
    }
    pub fn verify(&self) -> Result<(), LogError> { self.snapshot().verify() }
}

/// Detached, inspectable copy of a log window. Everything an external verifier needs.
#[derive(Clone, Debug)]
pub struct LogSnapshot {
    pub records: Vec<FailureRecord>,
    pub anchor: [u8; 32],
    pub evicted: u64,
    pub head: [u8; 32],
    pub next_seq: u64,
}

impl LogSnapshot {
    pub fn verify(&self) -> Result<(), LogError> {
        if self.next_seq != self.evicted.saturating_add(self.records.len() as u64) { return Err(LogError::CountMismatch); }
        let mut prev = self.anchor;
        for (i, r) in self.records.iter().enumerate() {
            if r.seq != self.evicted.saturating_add(i as u64) { return Err(LogError::SeqGap { index: i }); }
            if r.prev_digest != prev { return Err(LogError::ChainBroken { index: i }); }
            if r.compute_digest() != r.digest { return Err(LogError::DigestMismatch { index: i }); }
            prev = r.digest;
        }
        if prev != self.head { return Err(LogError::HeadMismatch); }
        Ok(())
    }
    /// Tail truncation or wholesale rewrite is only detectable against an EXTERNALLY anchored head digest.
    pub fn verify_against_head(&self, expected_head: [u8; 32]) -> Result<(), LogError> {
        self.verify()?;
        if self.head != expected_head { return Err(LogError::HeadMismatch); }
        Ok(())
    }
}
