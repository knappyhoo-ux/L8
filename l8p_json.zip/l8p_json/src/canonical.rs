use crate::value::Value;

/// True RFC 8785 (JCS) object-key ordering: compare the UTF-16 code UNIT sequence, not the
/// UTF-8 byte sequence or the Unicode code point sequence. These are NOT the same thing --
/// this was previously a real (if latent) bug here, using plain UTF-8 byte comparison, which
/// happens to equal code-point order for all valid Unicode but genuinely diverges from JCS's
/// UTF-16 order for keys mixing supplementary-plane characters (>= U+10000, encoded in UTF-16
/// as a surrogate pair starting at 0xD800) against BMP characters in U+E000..=U+FFFF: the
/// surrogate pair's leading unit sorts BELOW those BMP units even though the code point it
/// represents is numerically far higher. RFC 8785 mandates UTF-16 order specifically for
/// interoperability with JavaScript's native string comparison (JS strings are UTF-16-based).
/// L8P protocol field names are always ASCII, so this never mattered for any FIXED field name
/// in this schema -- but object keys inside untyped claim bodies (anomaly, future
/// deployment/witness) are not restricted to ASCII, so getting this wrong is a real
/// interop/canonicity bug waiting for the first non-ASCII key, not a theoretical one.
pub(crate) fn jcs_key_cmp(a: &str, b: &str) -> std::cmp::Ordering {
    a.encode_utf16().cmp(b.encode_utf16())
}

/// Encode `v` as canonical JSON (JCS/RFC 8785-style, no floats, no
/// insignificant whitespace, minimal string escaping, keys sorted by
/// UTF-16 code unit order per RFC 8785, not UTF-8 byte value).
///
/// This is deliberately independent of whatever order a caller's
/// `Value::Object` entries arrive in — sorting happens here, at encode
/// time, so this can be used both for values that came from `decode()`
/// (already sorted, since decode rejects anything else) and for values
/// built programmatically in Rust (arbitrary order). Note: if a caller
/// hands in an `Object` with duplicate keys — something `decode()` can
/// never produce, but hand-built `Value`s are not prevented from having —
/// this function does not detect or reject that; it is not a trust
/// boundary in this direction, only decode() is.
pub fn canonical_encode(v: &Value) -> Vec<u8> {
    let mut out = Vec::new();
    write_value(v, &mut out);
    out
}

fn write_value(v: &Value, out: &mut Vec<u8>) {
    match v {
        Value::Null => out.extend_from_slice(b"null"),
        Value::Bool(true) => out.extend_from_slice(b"true"),
        Value::Bool(false) => out.extend_from_slice(b"false"),
        Value::Integer(n) => out.extend_from_slice(n.to_string().as_bytes()),
        Value::Str(s) => write_string(s, out),
        Value::Array(items) => {
            out.push(b'[');
            for (i, item) in items.iter().enumerate() {
                if i > 0 {
                    out.push(b',');
                }
                write_value(item, out);
            }
            out.push(b']');
        }
        Value::Object(entries) => {
            let mut sorted: Vec<&(String, Value)> = entries.iter().collect();
            sorted.sort_by(|a, b| jcs_key_cmp(&a.0, &b.0));
            out.push(b'{');
            for (i, (k, val)) in sorted.iter().enumerate() {
                if i > 0 {
                    out.push(b',');
                }
                write_string(k, out);
                out.push(b':');
                write_value(val, out);
            }
            out.push(b'}');
        }
    }
}

fn write_string(s: &str, out: &mut Vec<u8>) {
    out.push(b'"');
    for b in s.bytes() {
        match b {
            b'"' => out.extend_from_slice(b"\\\""),
            b'\\' => out.extend_from_slice(b"\\\\"),
            0x08 => out.extend_from_slice(b"\\b"),
            0x09 => out.extend_from_slice(b"\\t"),
            0x0A => out.extend_from_slice(b"\\n"),
            0x0C => out.extend_from_slice(b"\\f"),
            0x0D => out.extend_from_slice(b"\\r"),
            0x00..=0x1F => {
                out.extend_from_slice(format!("\\u{:04x}", b).as_bytes());
            }
            _ => out.push(b),
        }
    }
    out.push(b'"');
}
