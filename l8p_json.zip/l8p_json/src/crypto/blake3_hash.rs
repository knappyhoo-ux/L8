/// BLAKE3-256 over arbitrary input, via the vetted `blake3` crate (pinned to =1.5.1 -- newer
/// releases require Cargo's edition2024 feature). This is the real L8/1.0 primary hash
/// (superseding the CBOR-era crate's SHA3-256), confirmed byte-identical to Python's `blake3`
/// package on the same input in earlier work on this project.
pub fn blake3_256(data: &[u8]) -> [u8; 32] {
    *blake3::hash(data).as_bytes()
}
