//! H1.4: cryptographic signature verification of a structurally valid Attestation.
//! Signing payload: BLAKE3 over the canonical JSON encoding of the attestation object with
//! `sig`, `auth_sig` and `wit` removed (via `crate::hash::signing_payload`) -- the ratified
//! L8/1.0 construction. Both `sig` and (for succession) `auth_sig` sign that same digest.
use crate::attestation::{Attestation, ClaimBody};
use crate::crypto::{decode_b64url, ed25519};
use crate::hash::signing_payload;
use crate::value::Value;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum SigCode {
    BadEncoding,
    BadKeyLength,
    BadSigLength,
    KeyMismatch,
    SignatureInvalid,
    MissingAuthSig,
    AuthSignatureInvalid,
}

impl SigCode {
    pub fn tag(&self) -> u8 {
        match self {
            SigCode::BadEncoding => 0,
            SigCode::BadKeyLength => 1,
            SigCode::BadSigLength => 2,
            SigCode::KeyMismatch => 3,
            SigCode::SignatureInvalid => 4,
            SigCode::MissingAuthSig => 5,
            SigCode::AuthSignatureInvalid => 6,
        }
    }
    pub const TAG_COUNT: usize = 7;

    pub fn as_str(&self) -> &'static str {
        match self {
            SigCode::BadEncoding => "BAD_ENCODING",
            SigCode::BadKeyLength => "BAD_KEY_LENGTH",
            SigCode::BadSigLength => "BAD_SIG_LENGTH",
            SigCode::KeyMismatch => "KEY_MISMATCH",
            SigCode::SignatureInvalid => "SIGNATURE_INVALID",
            SigCode::MissingAuthSig => "MISSING_AUTH_SIG",
            SigCode::AuthSignatureInvalid => "AUTH_SIGNATURE_INVALID",
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SigError {
    pub code: SigCode,
    pub path: &'static str,
}
fn fail<T>(code: SigCode, path: &'static str) -> Result<T, SigError> { Err(SigError { code, path }) }

const EXCLUDED: [&str; 3] = ["sig", "auth_sig", "wit"];

fn key(s: &str, path: &'static str) -> Result<[u8; 32], SigError> {
    let b = decode_b64url(s).ok_or(SigError { code: SigCode::BadEncoding, path })?;
    <[u8; 32]>::try_from(b.as_slice()).map_err(|_| SigError { code: SigCode::BadKeyLength, path })
}
fn sig(s: &str, path: &'static str) -> Result<[u8; 64], SigError> {
    let b = decode_b64url(s).ok_or(SigError { code: SigCode::BadEncoding, path })?;
    <[u8; 64]>::try_from(b.as_slice()).map_err(|_| SigError { code: SigCode::BadSigLength, path })
}

/// Verify `att` (already structurally valid) against the raw decoded `Value` it came from.
/// NOT checked here: fingerprints (`prev_fp`/`next_fp`), witness signatures (`wit`), chain
/// linkage (`prev`), Levels -- same scope boundary H1.4 always had on the CBOR side.
pub fn verify_signatures(decoded: &Value, att: &Attestation) -> Result<(), SigError> {
    let pk = key(&att.pk, "pk")?;
    let sg = sig(&att.sig, "sig")?;
    let payload = signing_payload(decoded, &EXCLUDED).map_err(|_| SigError { code: SigCode::BadEncoding, path: "" })?;
    match &att.claim {
        ClaimBody::Succession(s) => {
            let prev_pk = key(&s.prev_pk, "claim.body.prev_pk")?;
            let next_pk = key(&s.next_pk, "claim.body.next_pk")?;
            if next_pk != pk { return fail(SigCode::KeyMismatch, "claim.body.next_pk"); }
            if !ed25519::verify(&pk, &payload, &sg) { return fail(SigCode::SignatureInvalid, "sig"); }
            let auth_sig_str = att.auth_sig.as_deref().ok_or(SigError { code: SigCode::MissingAuthSig, path: "auth_sig" })?;
            let auth = sig(auth_sig_str, "auth_sig")?;
            if !ed25519::verify(&prev_pk, &payload, &auth) { return fail(SigCode::AuthSignatureInvalid, "auth_sig"); }
            Ok(())
        }
        _ => {
            if !ed25519::verify(&pk, &payload, &sg) { return fail(SigCode::SignatureInvalid, "sig"); }
            Ok(())
        }
    }
}

// Silence an unused-import warning on the `Value` type alias used only in the function signature
// above under some feature combinations; kept explicit for readability at the call site.
#[allow(unused_imports)]
use Value as _Unused;
