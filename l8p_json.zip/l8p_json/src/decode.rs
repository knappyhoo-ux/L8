use crate::error::DecodeError;
use crate::limits::Limits;
use crate::value::Value;

/// Decode `input` as canonical JSON under `limits`.
///
/// This is a *strict-acceptance* decoder: it does not merely parse valid
/// JSON, it rejects anything that is not already in the one canonical
/// byte-for-byte form (RFC 8785/JCS-style, no floats, per the ratified
/// L8/1.0 primary serialization). That means: no insignificant
/// whitespace anywhere, object keys in strict ascending byte order with
/// no duplicates, minimal number and string representations, and no
/// fractional/exponent numbers at all.
pub fn decode(input: &[u8], limits: &Limits) -> Result<Value, DecodeError> {
    if input.len() > limits.max_total_bytes {
        return Err(DecodeError::InputTooLarge);
    }
    let mut d = Decoder { input, pos: 0, limits, depth: 0 };
    let v = d.parse_value()?;
    if d.pos != input.len() {
        return Err(DecodeError::TrailingBytes { at: d.pos });
    }
    Ok(v)
}

struct Decoder<'a> {
    input: &'a [u8],
    pos: usize,
    limits: &'a Limits,
    depth: usize,
}

fn is_ws(b: u8) -> bool {
    matches!(b, b' ' | b'\t' | b'\n' | b'\r')
}

impl<'a> Decoder<'a> {
    fn peek(&self) -> Option<u8> {
        self.input.get(self.pos).copied()
    }

    fn expect_literal(&mut self, lit: &[u8]) -> Result<(), DecodeError> {
        let start = self.pos;
        if self.pos + lit.len() > self.input.len() {
            return Err(DecodeError::TruncatedInput { at: start });
        }
        if &self.input[self.pos..self.pos + lit.len()] != lit {
            return Err(DecodeError::UnexpectedToken { at: start });
        }
        self.pos += lit.len();
        Ok(())
    }

    fn enter(&mut self) -> Result<(), DecodeError> {
        if self.depth >= self.limits.max_depth {
            return Err(DecodeError::DepthLimitExceeded { at: self.pos });
        }
        self.depth += 1;
        Ok(())
    }

    fn exit(&mut self) {
        self.depth -= 1;
    }

    fn parse_value(&mut self) -> Result<Value, DecodeError> {
        let b = self.peek().ok_or(DecodeError::TruncatedInput { at: self.pos })?;
        if is_ws(b) {
            return Err(DecodeError::NonCanonicalWhitespace { at: self.pos });
        }
        match b {
            b'n' => {
                self.expect_literal(b"null")?;
                Ok(Value::Null)
            }
            b't' => {
                self.expect_literal(b"true")?;
                Ok(Value::Bool(true))
            }
            b'f' => {
                self.expect_literal(b"false")?;
                Ok(Value::Bool(false))
            }
            b'"' => self.parse_string().map(Value::Str),
            b'-' | b'0'..=b'9' => self.parse_number(),
            b'[' => self.parse_array(),
            b'{' => self.parse_object(),
            _ => Err(DecodeError::UnexpectedToken { at: self.pos }),
        }
    }

    fn parse_number(&mut self) -> Result<Value, DecodeError> {
        let start = self.pos;
        let mut negative = false;
        if self.peek() == Some(b'-') {
            negative = true;
            self.pos += 1;
        }
        let digits_start = self.pos;
        match self.peek() {
            Some(b'0') => {
                self.pos += 1;
                // A leading zero must stand alone: "0", "-0" is itself
                // rejected below as non-canonical negative zero, but
                // "01", "-01" etc are always malformed.
                if matches!(self.peek(), Some(b'0'..=b'9')) {
                    return Err(DecodeError::InvalidNumber { at: start });
                }
            }
            Some(b'1'..=b'9') => {
                while matches!(self.peek(), Some(b'0'..=b'9')) {
                    self.pos += 1;
                }
            }
            _ => return Err(DecodeError::InvalidNumber { at: start }),
        }
        // Floats are a structural rejection, not merely non-canonical:
        // the model has no Float variant at all.
        if matches!(self.peek(), Some(b'.') | Some(b'e') | Some(b'E')) {
            return Err(DecodeError::FloatNotAllowed { at: self.pos });
        }
        let digits = &self.input[digits_start..self.pos];
        if negative && digits == b"0" {
            // "-0" is non-canonical: the canonical integer form of zero
            // is "0", full stop.
            return Err(DecodeError::InvalidNumber { at: start });
        }
        let text = std::str::from_utf8(&self.input[start..self.pos])
            .map_err(|_| DecodeError::InvalidUtf8 { at: start })?;
        let n: i64 = text
            .parse()
            .map_err(|_| DecodeError::NumberOutOfRange { at: start })?;
        Ok(Value::Integer(n))
    }

    fn parse_string(&mut self) -> Result<String, DecodeError> {
        let quote_at = self.pos;
        debug_assert_eq!(self.peek(), Some(b'"'));
        self.pos += 1;
        let mut out: Vec<u8> = Vec::new();
        loop {
            let b = self.peek().ok_or(DecodeError::TruncatedInput { at: self.pos })?;
            match b {
                b'"' => {
                    self.pos += 1;
                    let s = String::from_utf8(out)
                        .map_err(|_| DecodeError::InvalidUtf8 { at: quote_at })?;
                    return Ok(s);
                }
                b'\\' => {
                    self.parse_escape(&mut out)?;
                }
                0x00..=0x1F => {
                    return Err(DecodeError::UnescapedControlChar { at: self.pos });
                }
                _ => {
                    out.push(b);
                    self.pos += 1;
                }
            }
            if out.len() > self.limits.max_string_bytes {
                return Err(DecodeError::StringTooLong { at: self.pos });
            }
        }
    }

    fn parse_escape(&mut self, out: &mut Vec<u8>) -> Result<(), DecodeError> {
        let esc_at = self.pos;
        self.pos += 1; // consume '\'
        let b = self.peek().ok_or(DecodeError::TruncatedInput { at: self.pos })?;
        match b {
            b'"' => {
                out.push(b'"');
                self.pos += 1;
            }
            b'\\' => {
                out.push(b'\\');
                self.pos += 1;
            }
            b'/' => {
                // Valid JSON, but not canonical: '/' never needs escaping.
                return Err(DecodeError::NonCanonicalEscape { at: esc_at });
            }
            b'b' => {
                out.push(0x08);
                self.pos += 1;
            }
            b'f' => {
                out.push(0x0C);
                self.pos += 1;
            }
            b'n' => {
                out.push(0x0A);
                self.pos += 1;
            }
            b'r' => {
                out.push(0x0D);
                self.pos += 1;
            }
            b't' => {
                out.push(0x09);
                self.pos += 1;
            }
            b'u' => {
                self.pos += 1;
                let cp = self.parse_hex4(esc_at)?;
                if (0xD800..=0xDBFF).contains(&cp) {
                    // High surrogate: canonical or not, this always
                    // encodes a codepoint >= 0x10000, which never needs
                    // escaping (direct UTF-8 is always available and
                    // shorter) -> non-canonical regardless of pairing.
                    if self.peek() == Some(b'\\') {
                        let save = self.pos;
                        self.pos += 1;
                        if self.peek() == Some(b'u') {
                            self.pos += 1;
                            let _low = self.parse_hex4(esc_at)?;
                        } else {
                            self.pos = save;
                        }
                    }
                    return Err(DecodeError::NonCanonicalEscape { at: esc_at });
                }
                if (0xDC00..=0xDFFF).contains(&cp) {
                    // Lone low surrogate: not valid UTF-16 at all.
                    return Err(DecodeError::InvalidEscape { at: esc_at });
                }
                // Short forms exist for 0x08,0x09,0x0A,0x0C,0x0D — using
                // \u00XX for those is valid JSON but not canonical.
                if matches!(cp, 0x08 | 0x09 | 0x0A | 0x0C | 0x0D) {
                    return Err(DecodeError::NonCanonicalEscape { at: esc_at });
                }
                if cp >= 0x20 {
                    // A printable character that never needed escaping.
                    return Err(DecodeError::NonCanonicalEscape { at: esc_at });
                }
                // A control character with no short form: \u00XX is the
                // canonical minimal representation.
                out.push(cp as u8);
            }
            _ => return Err(DecodeError::InvalidEscape { at: esc_at }),
        }
        Ok(())
    }

    fn parse_hex4(&mut self, esc_at: usize) -> Result<u32, DecodeError> {
        if self.pos + 4 > self.input.len() {
            return Err(DecodeError::TruncatedInput { at: self.pos });
        }
        let slice = &self.input[self.pos..self.pos + 4];
        let text = std::str::from_utf8(slice).map_err(|_| DecodeError::InvalidEscape { at: esc_at })?;
        let v = u32::from_str_radix(text, 16).map_err(|_| DecodeError::InvalidEscape { at: esc_at })?;
        self.pos += 4;
        Ok(v)
    }

    fn parse_array(&mut self) -> Result<Value, DecodeError> {
        debug_assert_eq!(self.peek(), Some(b'['));
        self.pos += 1;
        self.enter()?;
        let mut items = Vec::new();
        if self.peek() == Some(b']') {
            self.pos += 1;
            self.exit();
            return Ok(Value::Array(items));
        }
        loop {
            if is_ws(self.peek().unwrap_or(0)) {
                return Err(DecodeError::NonCanonicalWhitespace { at: self.pos });
            }
            let v = self.parse_value()?;
            items.push(v);
            if items.len() > self.limits.max_array_elems {
                return Err(DecodeError::ArrayTooLong { at: self.pos });
            }
            match self.peek() {
                Some(b',') => {
                    self.pos += 1;
                }
                Some(b']') => {
                    self.pos += 1;
                    self.exit();
                    return Ok(Value::Array(items));
                }
                Some(b) if is_ws(b) => {
                    return Err(DecodeError::NonCanonicalWhitespace { at: self.pos });
                }
                Some(_) => return Err(DecodeError::UnexpectedToken { at: self.pos }),
                None => return Err(DecodeError::TruncatedInput { at: self.pos }),
            }
        }
    }

    fn parse_object(&mut self) -> Result<Value, DecodeError> {
        debug_assert_eq!(self.peek(), Some(b'{'));
        self.pos += 1;
        self.enter()?;
        let mut entries: Vec<(String, Value)> = Vec::new();
        let mut last_key: Option<String> = None;
        if self.peek() == Some(b'}') {
            self.pos += 1;
            self.exit();
            return Ok(Value::Object(entries));
        }
        loop {
            match self.peek() {
                Some(b'"') => {}
                Some(b) if is_ws(b) => {
                    return Err(DecodeError::NonCanonicalWhitespace { at: self.pos })
                }
                Some(_) => return Err(DecodeError::UnexpectedToken { at: self.pos }),
                None => return Err(DecodeError::TruncatedInput { at: self.pos }),
            }
            let key_at = self.pos;
            let key = self.parse_string()?;
            if let Some(prev) = &last_key {
                match crate::canonical::jcs_key_cmp(&key, prev) {
                    std::cmp::Ordering::Equal => return Err(DecodeError::DuplicateKey { at: key_at }),
                    std::cmp::Ordering::Less => return Err(DecodeError::NonCanonicalKeyOrder { at: key_at }),
                    std::cmp::Ordering::Greater => {}
                }
            }
            match self.peek() {
                Some(b':') => self.pos += 1,
                Some(b) if is_ws(b) => {
                    return Err(DecodeError::NonCanonicalWhitespace { at: self.pos })
                }
                Some(_) => return Err(DecodeError::UnexpectedToken { at: self.pos }),
                None => return Err(DecodeError::TruncatedInput { at: self.pos }),
            }
            if is_ws(self.peek().unwrap_or(0)) {
                return Err(DecodeError::NonCanonicalWhitespace { at: self.pos });
            }
            let v = self.parse_value()?;
            entries.push((key.clone(), v));
            last_key = Some(key);
            if entries.len() > self.limits.max_object_entries {
                return Err(DecodeError::ObjectTooLong { at: self.pos });
            }
            match self.peek() {
                Some(b',') => {
                    self.pos += 1;
                }
                Some(b'}') => {
                    self.pos += 1;
                    self.exit();
                    return Ok(Value::Object(entries));
                }
                Some(b) if is_ws(b) => {
                    return Err(DecodeError::NonCanonicalWhitespace { at: self.pos });
                }
                Some(_) => return Err(DecodeError::UnexpectedToken { at: self.pos }),
                None => return Err(DecodeError::TruncatedInput { at: self.pos }),
            }
        }
    }
}
