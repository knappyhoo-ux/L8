use crate::canonical::canonical_encode;
use crate::value::Value;

/// BLAKE3 of arbitrary bytes. BLAKE3 is the ratified L8/1.0 primary hash
/// (SHA3-256 is the fallback, not implemented in this crate — this crate
/// only ever needs the primary path). Uses the vetted `blake3` crate
/// rather than a hand-rolled implementation: unlike the JSON decoder,
/// where strictness against a specific canonical grammar is the point,
/// a hash function is a well-specified primitive with no protocol-shaped
/// judgment calls to get right, so there's no benefit to rolling it by
/// hand the way Ed25519 was rolled elsewhere in this project.
pub fn blake3_hash(bytes: &[u8]) -> [u8; 32] {
    *blake3::hash(bytes).as_bytes()
}

/// Build the L8/1.0 signing payload for an attestation-shaped object:
/// canonical-encode `v` with the named keys removed from the top level,
/// then BLAKE3 it. Returns an error string if `v` is not an object.
///
/// This matches the ground truth established earlier in the project:
/// "signed payload = hash of canonical JSON with sig/auth_sig/wit
/// excluded." Only top-level keys are removed — this function does not
/// recurse into nested objects (the real schema never nests sig/auth_sig/
/// wit under anything else, so recursing would be solving a problem that
/// doesn't exist and would risk stripping a legitimately-named nested
/// field of the same name in some future claim body).
pub fn signing_payload(v: &Value, exclude_keys: &[&str]) -> Result<[u8; 32], String> {
    let entries = v
        .as_object()
        .ok_or_else(|| "signing_payload: value is not an object".to_string())?;
    let filtered: Vec<(String, Value)> = entries
        .iter()
        .filter(|(k, _)| !exclude_keys.contains(&k.as_str()))
        .cloned()
        .collect();
    let stripped = Value::Object(filtered);
    let bytes = canonical_encode(&stripped);
    Ok(blake3_hash(&bytes))
}
