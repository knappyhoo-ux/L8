/// Errors from typed structural validation of a decoded `Value` as an
/// L8/1.0 Attestation. This is a separate concern from `DecodeError`:
/// decoding answers "is this well-formed canonical JSON at all", this
/// answers "does it have the shape of a real Attestation" (same split
/// as H1.1 decode vs H1.2 structural validation on the CBOR side).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ValidationError {
    NotAnObject,
    MissingField(&'static str),
    WrongType(&'static str),
    UnknownClaimType(String),
    ClaimNotAnObject,
    MissingClaimField(&'static str),
    UnknownActionType(String),
    UnknownSuccessionReason(String),
    UnknownRevocationReason(String),
    UnknownIdentityKind(String),
}

impl ValidationError {
    /// See `DecodeError::tag` -- same rationale, added while porting H1.3 onto this crate.
    pub fn tag(&self) -> u8 {
        match self {
            ValidationError::NotAnObject => 0,
            ValidationError::MissingField(_) => 1,
            ValidationError::WrongType(_) => 2,
            ValidationError::UnknownClaimType(_) => 3,
            ValidationError::ClaimNotAnObject => 4,
            ValidationError::MissingClaimField(_) => 5,
            ValidationError::UnknownActionType(_) => 6,
            ValidationError::UnknownSuccessionReason(_) => 7,
            ValidationError::UnknownRevocationReason(_) => 8,
            ValidationError::UnknownIdentityKind(_) => 9,
        }
    }
    pub const TAG_COUNT: usize = 10;

    pub fn code_str(&self) -> &'static str {
        match self {
            ValidationError::NotAnObject => "NOT_AN_OBJECT",
            ValidationError::MissingField(_) => "MISSING_FIELD",
            ValidationError::WrongType(_) => "WRONG_TYPE",
            ValidationError::UnknownClaimType(_) => "UNKNOWN_CLAIM_TYPE",
            ValidationError::ClaimNotAnObject => "CLAIM_NOT_AN_OBJECT",
            ValidationError::MissingClaimField(_) => "MISSING_CLAIM_FIELD",
            ValidationError::UnknownActionType(_) => "UNKNOWN_ACTION_TYPE",
            ValidationError::UnknownSuccessionReason(_) => "UNKNOWN_SUCCESSION_REASON",
            ValidationError::UnknownRevocationReason(_) => "UNKNOWN_REVOCATION_REASON",
            ValidationError::UnknownIdentityKind(_) => "UNKNOWN_IDENTITY_KIND",
        }
    }
}
