/// Bounds enforced by the decoder before any allocation grows unbounded.
/// Mirrors the H1.1 Rust decoder's bounded-decoder philosophy, applied to
/// canonical JSON instead of canonical CBOR.
#[derive(Debug, Clone, Copy)]
pub struct Limits {
    pub max_depth: usize,
    pub max_string_bytes: usize,
    pub max_array_elems: usize,
    pub max_object_entries: usize,
    pub max_total_bytes: usize,
}

impl Default for Limits {
    fn default() -> Self {
        Limits {
            max_depth: 32,
            max_string_bytes: 1 << 20,      // 1 MiB
            max_array_elems: 4096,
            max_object_entries: 256,
            max_total_bytes: 8 << 20,       // 8 MiB
        }
    }
}
