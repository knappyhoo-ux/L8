//! H1.3/H1.4 emission: turn preserved failure records into signed L8 `anomaly` attestations.
//! Ported from l8p_core's CBOR/SHA3-256 emitter onto this crate's real canonical-JSON/BLAKE3
//! primitives. Differences from the l8p_core original: no envelope/length-prefix framing (a
//! canonical JSON attestation is already self-delimiting, so `build()` returns the raw bytes
//! directly); `blake3_hash` instead of `sha3_256`; the anomaly body's self-describing `hash`
//! field says `"blake3"`.
//!
//! PROPOSED design, pending confirmation (same status as it had in l8p_core, carried over
//! unchanged by this port):
//! * Only DIGESTS leave the boundary. The raw `capture` bytes stay in the local log.
//! * The anomaly body shape below is new (no ratified schema was available for it).
//! * `id` is derived from the record digest (idempotent); `prev` chains emitted attestations
//!   by BLAKE3 of the previous attestation's full canonical bytes; the timestamp is supplied
//!   by the caller (the log itself is clock-free).
//! * Records evicted before they could be emitted are announced with one `failure_gap`
//!   anomaly, never dropped silently.
pub mod checkpoint;
pub mod time;

use crate::crypto::encode_b64url;
use crate::failure::{FailureLog, FailureRecord, Stage};
use crate::hash::{blake3_hash, signing_payload};
use crate::value::Value as V;
use time::rfc3339_from_unix_ns;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct SignError;

/// Signing capability supplied by the caller (HSM, OS keystore, vetted library). The crate
/// never holds production keys.
pub trait Signer {
    fn public_key(&self) -> [u8; 32];
    fn sign(&self, msg: &[u8]) -> Result<[u8; 64], SignError>;
}

#[cfg(feature = "reference-signer")]
pub struct ReferenceSigner { seed: [u8; 32], pk: [u8; 32] }
#[cfg(feature = "reference-signer")]
impl ReferenceSigner {
    pub fn from_seed(seed: [u8; 32]) -> Self {
        ReferenceSigner { pk: crate::crypto::ed25519::public_key_from_seed(&seed), seed }
    }
}
#[cfg(feature = "reference-signer")]
impl Signer for ReferenceSigner {
    fn public_key(&self) -> [u8; 32] { self.pk }
    fn sign(&self, msg: &[u8]) -> Result<[u8; 64], SignError> {
        Ok(crate::crypto::ed25519::sign_reference(&self.seed, msg))
    }
}

#[derive(Clone, Debug)]
pub struct EmitConfig {
    pub subject: String,
    pub sentinel: String,
    pub scope: String,
    pub env: String,
}

impl EmitConfig {
    fn validate(&self) -> Result<(), &'static str> {
        if self.subject.is_empty() || self.subject.len() > 256 { return Err("subject must be 1..=256 bytes"); }
        for s in [&self.sentinel, &self.scope, &self.env] {
            if s.len() > 4096 { return Err("meta strings limited to 4096 bytes"); }
        }
        Ok(())
    }
}

#[derive(Debug, Default)]
pub struct EmitBatch {
    /// Complete canonical-JSON attestation bytes, ready for transport (no framing needed).
    pub attestations: Vec<Vec<u8>>,
    /// How many of `attestations` are `failure_gap` announcements.
    pub gaps: u64,
    /// Set if signing failed part-way; everything before the failure is still returned and the cursor stops there.
    pub error: Option<SignError>,
}

pub struct Emitter<S: Signer> {
    cfg: EmitConfig,
    signer: S,
    next_seq: u64,
    prev: Option<String>,
}

fn txt(s: &str) -> V { V::Str(s.to_string()) }
fn kvs(pairs: Vec<(&str, V)>) -> V { V::Object(pairs.into_iter().map(|(k, v)| (k.to_string(), v)).collect()) }
fn b64(d: &[u8]) -> V { V::Str(encode_b64url(d)) }

/// Deterministic UUID (version 8, RFC 4122 variant bits) from 16 bytes of a digest.
fn uuid_from(d: &[u8]) -> String {
    let mut b = [0u8; 16];
    b.copy_from_slice(&d[..16]);
    b[6] = (b[6] & 0x0f) | 0x80;
    b[8] = (b[8] & 0x3f) | 0x80;
    let h: String = b.iter().map(|x| format!("{:02x}", x)).collect();
    format!("{}-{}-{}-{}-{}", &h[0..8], &h[8..12], &h[12..16], &h[16..20], &h[20..32])
}

impl<S: Signer> Emitter<S> {
    pub fn new(cfg: EmitConfig, signer: S) -> Result<Self, &'static str> {
        cfg.validate()?;
        Ok(Emitter { cfg, signer, next_seq: 0, prev: None })
    }
    pub fn next_seq(&self) -> u64 { self.next_seq }

    fn build(&mut self, id: String, body: V, now_unix_ns: u64) -> Result<Vec<u8>, SignError> {
        let mut fields: Vec<(&str, V)> = vec![
            ("ver", txt("L8/1.0")),
            ("id", V::Str(id)),
            ("sub", txt(&self.cfg.subject)),
            ("claim", kvs(vec![("type", txt("anomaly")), ("body", body)])),
            ("ts_unix_ns", V::Integer(now_unix_ns as i64)),
            ("ts_rfc3339", txt(&rfc3339_from_unix_ns(now_unix_ns))),
            ("prev", match &self.prev { Some(p) => V::Str(p.clone()), None => V::Null }),
            ("pk", b64(&self.signer.public_key())),
            ("wit", V::Array(vec![])),
            ("meta", kvs(vec![("sentinel", txt(&self.cfg.sentinel)), ("scope", txt(&self.cfg.scope)), ("env", txt(&self.cfg.env))])),
        ];
        let unsigned = kvs(fields.clone());
        let payload = signing_payload(&unsigned, &["sig", "auth_sig", "wit"]).map_err(|_| SignError)?;
        let sig = self.signer.sign(&payload)?;
        fields.push(("sig", b64(&sig)));
        let body_bytes = crate::canonical::canonical_encode(&kvs(fields));
        self.prev = Some(encode_b64url(&blake3_hash(&body_bytes)));
        Ok(body_bytes)
    }

    /// Ratified H1.2 `anomaly` shape: `anomaly_id`/`category`/`severity`/`related_attestations`/
    /// `description`/`detected_by`, plus this emitter's own forensic extras alongside (this
    /// crate's `validate()` doesn't reject unknown fields, so both coexist). `anomaly_id`
    /// mirrors the attestation's own top-level `id` for a single-record anomaly. A real fix
    /// this session: this body previously used an ad-hoc, non-ratified shape under the
    /// mistaken assumption that no spec existed for `anomaly` -- one did, already on hand.
    fn record_body(id: &str, r: &FailureRecord, detected_by: &str) -> V {
        let stage = match r.kind.stage() { Stage::Wire => "wire", Stage::Structure => "structure", Stage::Signature => "signature" };
        kvs(vec![
            ("anomaly_id", txt(id)),
            ("category", txt("input_rejected")),
            ("severity", txt("info")),
            ("related_attestations", V::Array(vec![])),
            ("description", txt(&format!("rejected input at {} stage: {}", stage, r.kind.code_str()))),
            ("detected_by", txt(detected_by)),
            ("hash", txt("blake3")),
            ("stage", txt(stage)),
            ("code", txt(r.kind.code_str())),
            ("seq", V::Integer(r.seq as i64)),
            ("input_len", V::Integer(r.input_len as i64)),
            ("input_digest", b64(&r.input_digest)),
            ("record_digest", b64(&r.digest)),
            ("prev_record_digest", b64(&r.prev_digest)),
        ])
    }

    /// Emit a signed checkpoint carrying the log's head digest. Joins the same `prev` chain as
    /// record attestations; does not move the record cursor.
    pub fn emit_checkpoint(&mut self, log: &FailureLog, now_unix_ns: u64) -> Result<Vec<u8>, SignError> {
        let (head, total, evicted, anchor) = (log.head(), log.total_rejected(), log.evicted(), log.anchor());
        let mut pre = head.to_vec();
        pre.extend_from_slice(&total.to_be_bytes());
        pre.extend_from_slice(&evicted.to_be_bytes());
        pre.extend_from_slice(self.prev.as_deref().unwrap_or("").as_bytes());
        let id = uuid_from(&blake3_hash(&pre));
        let body = kvs(vec![
            ("anomaly_id", txt(&id)),
            ("category", txt("log_checkpoint")),
            ("severity", txt("info")),
            ("related_attestations", V::Array(vec![])),
            ("description", txt(&format!("log checkpoint: {} total rejected, {} evicted", total, evicted))),
            ("detected_by", txt(&self.cfg.subject)),
            ("hash", txt("blake3")),
            ("head_digest", b64(&head)),
            ("total_rejected", V::Integer(total as i64)),
            ("evicted", V::Integer(evicted as i64)),
            ("anchor_digest", b64(&anchor)),
        ]);
        self.build(id, body, now_unix_ns)
    }

    /// Emit an attestation for every record not yet emitted (plus one gap announcement if
    /// records were evicted before this cursor reached them).
    pub fn emit_pending(&mut self, log: &FailureLog, now_unix_ns: u64) -> EmitBatch {
        let mut out = EmitBatch::default();
        if self.next_seq < log.evicted() {
            let (from, to, anchor) = (self.next_seq, log.evicted(), log.anchor());
            let mut pre = anchor.to_vec();
            pre.extend_from_slice(&from.to_be_bytes());
            pre.extend_from_slice(&to.to_be_bytes());
            let id = uuid_from(&blake3_hash(&pre));
            let body = kvs(vec![
                ("anomaly_id", txt(&id)),
                ("category", txt("failure_gap")),
                ("severity", txt("warning")),
                ("related_attestations", V::Array(vec![])),
                ("description", txt(&format!("failure log evicted records {}..{} before they could be emitted", from, to))),
                ("detected_by", txt(&self.cfg.subject)),
                ("hash", txt("blake3")),
                ("from_seq", V::Integer(from as i64)),
                ("to_seq", V::Integer(to as i64)),
                ("anchor_digest", b64(&anchor)),
            ]);
            match self.build(id, body, now_unix_ns) {
                Ok(e) => { out.attestations.push(e); out.gaps += 1; self.next_seq = to; }
                Err(e) => { out.error = Some(e); return out; }
            }
        }
        let start = self.next_seq;
        for r in log.records().filter(|r| r.seq >= start) {
            let rec_id = uuid_from(&r.digest);
            let body = Self::record_body(&rec_id, r, &self.cfg.subject);
            match self.build(rec_id, body, now_unix_ns) {
                Ok(e) => { out.attestations.push(e); self.next_seq = r.seq + 1; }
                Err(e) => { out.error = Some(e); return out; }
            }
        }
        out
    }
}

/// Check the `prev` links across a sequence of emitted attestations (first must have `prev = null`).
/// Returns the index of the first broken link. Signatures are NOT checked here (use a verifying Gate).
pub fn verify_emitted_chain(attestations: &[Vec<u8>]) -> Result<(), usize> {
    let mut expected: Option<String> = None;
    for (i, e) in attestations.iter().enumerate() {
        let d = crate::decode::decode(e, &crate::limits::Limits::default()).map_err(|_| i)?;
        let prev = d.get("prev").cloned().ok_or(i)?;
        let got = match prev { V::Null => None, V::Str(s) => Some(s), _ => return Err(i) };
        if got != expected { return Err(i); }
        expected = Some(encode_b64url(&blake3_hash(e)));
    }
    Ok(())
}
