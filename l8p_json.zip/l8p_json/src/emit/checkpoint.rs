//! Externally anchored log heads. A checkpoint is a signed `anomaly` attestation carrying the
//! failure log's head digest, so tail truncation and wholesale rewrites of the local log
//! become detectable by anyone holding the emitter's public key and the latest checkpoint.
use crate::attestation::{validate, ClaimBody};
use crate::crypto::decode_b64url;
use crate::decode::decode;
use crate::failure::{LogError, LogSnapshot, GENESIS};
use crate::limits::Limits;
use crate::value::Value as V;
use crate::verify::verify_signatures;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Checkpoint {
    pub head: [u8; 32],
    pub total_rejected: u64,
    pub evicted: u64,
    pub anchor: [u8; 32],
    pub ts_unix_ns: i64,
    pub emitter_pk: [u8; 32],
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CheckpointError {
    /// Failed decode, structural validation, or signature verification.
    Invalid,
    /// Valid attestation, but not signed by the pinned emitter key.
    WrongKey,
    NotACheckpoint,
    BadBody,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum LogCheckError {
    /// The snapshot is internally inconsistent (its own chain fails).
    LogInvalid(LogError),
    /// The snapshot holds fewer rejections than the checkpoint attests: tail truncation or rollback.
    Truncated,
    /// The record at the checkpointed position differs from the attested head: rewrite.
    HeadMismatch,
    /// The retained window has moved past the checkpoint, so it can no longer be checked against this one.
    Unverifiable,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FreshnessError {
    /// A newer-looking checkpoint attests fewer rejections than one already accepted.
    Rollback,
    /// Two checkpoints attest the same count with different heads: the emitter signed two histories.
    Fork,
}

fn text_field(v: &V, k: &str) -> Option<String> {
    match v.get(k) { Some(V::Str(s)) => Some(s.clone()), _ => None }
}
fn int_field(v: &V, k: &str) -> Option<u64> {
    match v.get(k) { Some(V::Integer(n)) if *n >= 0 => Some(*n as u64), _ => None }
}
fn digest_field(v: &V, k: &str) -> Option<[u8; 32]> {
    let b = decode_b64url(&text_field(v, k)?)?;
    <[u8; 32]>::try_from(b.as_slice()).ok()
}

/// Full verification of a checkpoint attestation: decode, structure, signature, pinned emitter
/// key, body schema.
pub fn parse_checkpoint(bytes: &[u8], expected_pk: &[u8; 32]) -> Result<Checkpoint, CheckpointError> {
    let d = decode(bytes, &Limits::default()).map_err(|_| CheckpointError::Invalid)?;
    let att = validate(&d).map_err(|_| CheckpointError::Invalid)?;
    verify_signatures(&d, &att).map_err(|_| CheckpointError::Invalid)?;
    let pk_bytes = decode_b64url(&att.pk).ok_or(CheckpointError::Invalid)?;
    if pk_bytes.as_slice() != expected_pk.as_slice() { return Err(CheckpointError::WrongKey); }
    // `anomaly` is now a typed ClaimBody (ratified H1.2 shape: anomaly_id/category/severity/
    // related_attestations/description/detected_by) -- this crate's own emitter populates those
    // 6 required fields with `category: "log_checkpoint"` for checkpoints, plus its own forensic
    // extras (hash/head_digest/etc) alongside, which `AnomalyBody.raw` still carries whole.
    let anomaly = match &att.claim {
        ClaimBody::Anomaly(a) if a.category == "log_checkpoint" => a,
        _ => return Err(CheckpointError::NotACheckpoint),
    };
    let body = &anomaly.raw;
    let entries = body.as_object().ok_or(CheckpointError::BadBody)?;
    const KEYS: [&str; 11] = [
        "anomaly_id", "category", "severity", "related_attestations", "description", "detected_by",
        "hash", "head_digest", "total_rejected", "evicted", "anchor_digest",
    ];
    if entries.len() != KEYS.len() || !entries.iter().all(|(k, _)| KEYS.contains(&k.as_str())) {
        return Err(CheckpointError::BadBody);
    }
    if text_field(body, "hash").as_deref() != Some("blake3") { return Err(CheckpointError::BadBody); }
    let head = digest_field(body, "head_digest").ok_or(CheckpointError::BadBody)?;
    let anchor = digest_field(body, "anchor_digest").ok_or(CheckpointError::BadBody)?;
    let total = int_field(body, "total_rejected").ok_or(CheckpointError::BadBody)?;
    let evicted = int_field(body, "evicted").ok_or(CheckpointError::BadBody)?;
    if evicted > total { return Err(CheckpointError::BadBody); }
    if total == 0 && (head != GENESIS || anchor != GENESIS || evicted != 0) { return Err(CheckpointError::BadBody); }
    Ok(Checkpoint { head, total_rejected: total, evicted, anchor, ts_unix_ns: att.ts_unix_ns, emitter_pk: *expected_pk })
}

/// Check a log snapshot against an attested checkpoint. Detects tail truncation, rewrites and rollback.
pub fn check_log_against_checkpoint(snap: &LogSnapshot, cp: &Checkpoint) -> Result<(), LogCheckError> {
    snap.verify().map_err(LogCheckError::LogInvalid)?;
    if snap.next_seq < cp.total_rejected { return Err(LogCheckError::Truncated); }
    if cp.total_rejected == 0 { return Ok(()); }
    if snap.evicted == cp.evicted && snap.anchor != cp.anchor { return Err(LogCheckError::HeadMismatch); }
    let last = cp.total_rejected - 1;
    if last >= snap.evicted {
        let idx = (last - snap.evicted) as usize;
        match snap.records.get(idx) {
            Some(r) if r.digest == cp.head => Ok(()),
            _ => Err(LogCheckError::HeadMismatch),
        }
    } else if cp.total_rejected == snap.evicted {
        if snap.anchor == cp.head { Ok(()) } else { Err(LogCheckError::HeadMismatch) }
    } else {
        Err(LogCheckError::Unverifiable)
    }
}

/// A verifier must track the newest checkpoint it has accepted; an older (validly signed) one must not replace it.
pub fn check_freshness(prev: Option<&Checkpoint>, new: &Checkpoint) -> Result<(), FreshnessError> {
    match prev {
        None => Ok(()),
        Some(p) if new.total_rejected < p.total_rejected => Err(FreshnessError::Rollback),
        Some(p) if new.total_rejected == p.total_rejected && new.head != p.head => Err(FreshnessError::Fork),
        Some(_) => Ok(()),
    }
}
