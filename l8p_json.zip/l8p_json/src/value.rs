/// A decoded JSON value. There is deliberately no `Float` variant: the
/// ratified L8/1.0 canonical JSON form carries no floats anywhere, so
/// "no floats" is a type-level guarantee here, not just a runtime check
/// (mirrors H1.2's typed-`ClaimBody` approach rather than a generic map).
#[derive(Debug, Clone, PartialEq)]
pub enum Value {
    Null,
    Bool(bool),
    Integer(i64),
    Str(String),
    Array(Vec<Value>),
    /// Insertion order as encountered. The decoder only accepts objects
    /// whose keys already arrive in strict ascending byte order, so for
    /// anything that came through `decode()` this order IS the canonical
    /// order. Values built programmatically (not decoded) may hand keys
    /// in any order — `canonical_encode` sorts them regardless.
    Object(Vec<(String, Value)>),
}

impl Value {
    pub fn as_object(&self) -> Option<&[(String, Value)]> {
        match self {
            Value::Object(entries) => Some(entries),
            _ => None,
        }
    }

    pub fn get(&self, key: &str) -> Option<&Value> {
        self.as_object()?.iter().find(|(k, _)| k == key).map(|(_, v)| v)
    }
}
