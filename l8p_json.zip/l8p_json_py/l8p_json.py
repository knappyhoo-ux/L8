"""
l8p_json.py — Python counterpart to the Rust `l8p_json` crate.

Implements the same *strict-acceptance* canonical JSON grammar (JCS/RFC
8785-style): no insignificant whitespace, no floats, no leading zeros or
"-0", object keys in strict ascending byte order with no duplicates, and
minimal string escaping only. The goal is byte-for-byte parity with the
Rust decoder/encoder so the two sides of L8P can exchange attestations
and agree on hashes without either side being the "real" implementation.

This is a companion/round-trip-test module, not a hardened production
decoder — it hasn't had the Rust side's adversarial test suite run
against it yet. Treat any divergence found between this and the Rust
crate as a bug in whichever side disagrees with the spec, not
automatically a bug in this file.
"""
from __future__ import annotations

from dataclasses import dataclass

import blake3


@dataclass(frozen=True)
class Limits:
    """Bounds enforced by the decoder before any allocation grows unbounded.
    Mirrors the Rust `limits.rs` exactly -- restored here after this module's
    prior bounded-decoder support was lost when an older Python snapshot got
    re-uploaded in place of the newer one that had it."""
    max_depth: int = 32
    max_string_bytes: int = 1 << 20        # 1 MiB
    max_array_elems: int = 4096
    max_object_entries: int = 256
    max_total_bytes: int = 8 << 20         # 8 MiB


_DEFAULT_LIMITS = Limits()
_I64_MIN, _I64_MAX = -(2 ** 63), 2 ** 63 - 1


def _jcs_key(s: str) -> bytes:
    """RFC 8785 (JCS) key-sort key: the UTF-16BE encoding, compared byte-wise. This is NOT the
    same as UTF-8 byte order (equivalently, code-point order): they genuinely diverge for keys
    mixing a supplementary-plane character (>= U+10000, a UTF-16 surrogate pair starting at
    0xD800) against a BMP character in U+E000..=U+FFFF, where the surrogate pair's leading unit
    sorts below those BMP units despite representing a numerically far higher code point. Fixed
    here alongside the same fix on the Rust side -- previously this used plain UTF-8 byte order.
    """
    return s.encode("utf-16-be")


class CanonicalJSONError(ValueError):
    def __init__(self, code: str, pos: int | None = None):
        self.code = code
        self.pos = pos
        super().__init__(f"{code}" + (f" at {pos}" if pos is not None else ""))


_SHORT_ESCAPES = {0x08: "b", 0x09: "t", 0x0A: "n", 0x0C: "f", 0x0D: "r"}
_SHORT_ESCAPE_CODES = set(_SHORT_ESCAPES.keys())


class _Decoder:
    def __init__(self, data: bytes, limits: Limits):
        self.data = data
        self.pos = 0
        self.limits = limits
        self.depth = 0

    def enter(self):
        if self.depth >= self.limits.max_depth:
            self.err("DepthLimitExceeded")
        self.depth += 1

    def exit(self):
        self.depth -= 1

    def peek(self):
        return self.data[self.pos] if self.pos < len(self.data) else None

    def err(self, code, at=None):
        raise CanonicalJSONError(code, self.pos if at is None else at)

    def expect_literal(self, lit: bytes):
        if self.data[self.pos:self.pos + len(lit)] != lit:
            self.err("UnexpectedToken")
        self.pos += len(lit)

    def parse_value(self):
        b = self.peek()
        if b is None:
            self.err("TruncatedInput")
        if b in (0x20, 0x09, 0x0A, 0x0D):
            self.err("NonCanonicalWhitespace")
        if b == 0x6E:  # 'n'
            self.expect_literal(b"null")
            return None
        if b == 0x74:  # 't'
            self.expect_literal(b"true")
            return True
        if b == 0x66:  # 'f'
            self.expect_literal(b"false")
            return False
        if b == 0x22:  # '"'
            return self.parse_string()
        if b == 0x2D or 0x30 <= b <= 0x39:  # '-' or digit
            return self.parse_number()
        if b == 0x5B:  # '['
            return self.parse_array()
        if b == 0x7B:  # '{'
            return self.parse_object()
        self.err("UnexpectedToken")

    def parse_number(self):
        start = self.pos
        negative = False
        if self.peek() == 0x2D:
            negative = True
            self.pos += 1
        digits_start = self.pos
        b = self.peek()
        if b == 0x30:  # '0'
            self.pos += 1
            nb = self.peek()
            if nb is not None and 0x30 <= nb <= 0x39:
                self.err("InvalidNumber", start)
        elif b is not None and 0x31 <= b <= 0x39:
            while True:
                nb = self.peek()
                if nb is not None and 0x30 <= nb <= 0x39:
                    self.pos += 1
                else:
                    break
        else:
            self.err("InvalidNumber", start)
        nb = self.peek()
        if nb in (0x2E, 0x65, 0x45):  # '.', 'e', 'E'
            self.err("FloatNotAllowed")
        digits = self.data[digits_start:self.pos]
        if negative and digits == b"0":
            self.err("InvalidNumber", start)
        text = self.data[start:self.pos].decode("ascii")
        n = int(text)
        if not (_I64_MIN <= n <= _I64_MAX):
            self.err("NumberOutOfRange", start)
        return n

    def parse_string(self):
        assert self.peek() == 0x22
        quote_at = self.pos
        self.pos += 1
        out = bytearray()
        while True:
            b = self.peek()
            if b is None:
                self.err("TruncatedInput")
            if b == 0x22:
                self.pos += 1
                try:
                    return out.decode("utf-8")
                except UnicodeDecodeError:
                    self.err("InvalidUtf8", quote_at)
            if b == 0x5C:  # backslash
                self.parse_escape(out)
                if len(out) > self.limits.max_string_bytes:
                    self.err("StringTooLong")
                continue
            if b <= 0x1F:
                self.err("UnescapedControlChar")
            out.append(b)
            self.pos += 1
            if len(out) > self.limits.max_string_bytes:
                self.err("StringTooLong")

    def parse_escape(self, out: bytearray):
        esc_at = self.pos
        self.pos += 1
        b = self.peek()
        if b is None:
            self.err("TruncatedInput")
        if b == 0x22:
            out.append(0x22); self.pos += 1
        elif b == 0x5C:
            out.append(0x5C); self.pos += 1
        elif b == 0x2F:
            self.err("NonCanonicalEscape", esc_at)
        elif b == 0x62:
            out.append(0x08); self.pos += 1
        elif b == 0x66:
            out.append(0x0C); self.pos += 1
        elif b == 0x6E:
            out.append(0x0A); self.pos += 1
        elif b == 0x72:
            out.append(0x0D); self.pos += 1
        elif b == 0x74:
            out.append(0x09); self.pos += 1
        elif b == 0x75:
            self.pos += 1
            cp = self._hex4(esc_at)
            if 0xD800 <= cp <= 0xDBFF:
                if self.peek() == 0x5C:
                    save = self.pos
                    self.pos += 1
                    if self.peek() == 0x75:
                        self.pos += 1
                        self._hex4(esc_at)
                    else:
                        self.pos = save
                self.err("NonCanonicalEscape", esc_at)
            if 0xDC00 <= cp <= 0xDFFF:
                self.err("InvalidEscape", esc_at)
            if cp in _SHORT_ESCAPE_CODES:
                self.err("NonCanonicalEscape", esc_at)
            if cp >= 0x20:
                self.err("NonCanonicalEscape", esc_at)
            out.extend(chr(cp).encode("utf-8"))
        else:
            self.err("InvalidEscape", esc_at)

    def _hex4(self, esc_at):
        chunk = self.data[self.pos:self.pos + 4]
        if len(chunk) != 4:
            self.err("TruncatedInput")
        try:
            v = int(chunk.decode("ascii"), 16)
        except ValueError:
            self.err("InvalidEscape", esc_at)
        self.pos += 4
        return v

    def parse_array(self):
        self.pos += 1
        self.enter()
        items = []
        if self.peek() == 0x5D:
            self.pos += 1
            self.exit()
            return items
        while True:
            if self.peek() in (0x20, 0x09, 0x0A, 0x0D):
                self.err("NonCanonicalWhitespace")
            items.append(self.parse_value())
            if len(items) > self.limits.max_array_elems:
                self.err("ArrayTooLong")
            b = self.peek()
            if b == 0x2C:
                self.pos += 1
            elif b == 0x5D:
                self.pos += 1
                self.exit()
                return items
            elif b in (0x20, 0x09, 0x0A, 0x0D):
                self.err("NonCanonicalWhitespace")
            elif b is None:
                self.err("TruncatedInput")
            else:
                self.err("UnexpectedToken")

    def parse_object(self):
        self.pos += 1
        self.enter()
        entries = []
        last_key = None
        if self.peek() == 0x7D:
            self.pos += 1
            self.exit()
            return {}
        while True:
            if self.peek() != 0x22:
                if self.peek() in (0x20, 0x09, 0x0A, 0x0D):
                    self.err("NonCanonicalWhitespace")
                self.err("UnexpectedToken")
            key_at = self.pos
            key = self.parse_string()
            if last_key is not None:
                kb, pb = _jcs_key(key), _jcs_key(last_key)
                if kb == pb:
                    self.err("DuplicateKey", key_at)
                if kb < pb:
                    self.err("NonCanonicalKeyOrder", key_at)
            if self.peek() != 0x3A:
                if self.peek() in (0x20, 0x09, 0x0A, 0x0D):
                    self.err("NonCanonicalWhitespace")
                self.err("UnexpectedToken")
            self.pos += 1
            if self.peek() in (0x20, 0x09, 0x0A, 0x0D):
                self.err("NonCanonicalWhitespace")
            val = self.parse_value()
            entries.append((key, val))
            last_key = key
            if len(entries) > self.limits.max_object_entries:
                self.err("ObjectTooLong")
            b = self.peek()
            if b == 0x2C:
                self.pos += 1
            elif b == 0x7D:
                self.pos += 1
                self.exit()
                return dict(entries)
            elif b in (0x20, 0x09, 0x0A, 0x0D):
                self.err("NonCanonicalWhitespace")
            elif b is None:
                self.err("TruncatedInput")
            else:
                self.err("UnexpectedToken")


def decode(data: bytes, limits: Limits = _DEFAULT_LIMITS):
    if len(data) > limits.max_total_bytes:
        raise CanonicalJSONError("InputTooLarge")
    d = _Decoder(data, limits)
    v = d.parse_value()
    if d.pos != len(data):
        raise CanonicalJSONError("TrailingBytes", d.pos)
    return v


def _write_string(s: str, out: list):
    out.append('"')
    for b in s.encode("utf-8"):
        if b == 0x22:
            out.append('\\"')
        elif b == 0x5C:
            out.append("\\\\")
        elif b in _SHORT_ESCAPES:
            out.append("\\" + _SHORT_ESCAPES[b])
        elif b <= 0x1F:
            out.append(f"\\u{b:04x}")
        else:
            out.append(chr(b))
    out.append('"')


def canonical_encode(v) -> bytes:
    out: list[str] = []
    _write_value(v, out)
    # Build as latin-1 (byte-transparent) since _write_string emits raw
    # UTF-8 bytes reinterpreted as chr() one at a time above.
    return "".join(out).encode("latin-1")


def _write_value(v, out: list):
    if v is None:
        out.append("null")
    elif v is True:
        out.append("true")
    elif v is False:
        out.append("false")
    elif isinstance(v, int):
        out.append(str(v))
    elif isinstance(v, str):
        _write_string(v, out)
    elif isinstance(v, list):
        out.append("[")
        for i, item in enumerate(v):
            if i:
                out.append(",")
            _write_value(item, out)
        out.append("]")
    elif isinstance(v, dict):
        out.append("{")
        for i, k in enumerate(sorted(v.keys(), key=_jcs_key)):
            if i:
                out.append(",")
            _write_string(k, out)
            out.append(":")
            _write_value(v[k], out)
        out.append("}")
    else:
        raise TypeError(f"not encodable as canonical JSON: {type(v)}")


def blake3_hash(data: bytes) -> bytes:
    return blake3.blake3(data).digest()


def signing_payload(v: dict, exclude_keys) -> bytes:
    if not isinstance(v, dict):
        raise TypeError("signing_payload: value is not an object")
    stripped = {k: val for k, val in v.items() if k not in exclude_keys}
    return blake3_hash(canonical_encode(stripped))
