import pytest

from l8p_json import canonical_encode
from attestation import ValidationError
from verify import SigCode, SigError, encode_b64url, public_key_from_seed, sign_reference, signing_payload
from failure import Admission, Gate, LogConfig
from emit import Emitter, EmitConfig, ReferenceSigner, check_freshness, check_log_against_checkpoint, parse_checkpoint


def _uuid_from(d: bytes) -> str:
    b = bytearray(d[:16]); b[6] = (b[6] & 0x0F) | 0x80; b[8] = (b[8] & 0x3F) | 0x80
    h = b.hex()
    return f"{h[0:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:32]}"


def build_succession(old_seed: bytes, new_seed: bytes) -> bytes:
    old_pk, new_pk = public_key_from_seed(old_seed), public_key_from_seed(new_seed)
    body = {
        "prev_pk": encode_b64url(old_pk), "next_pk": encode_b64url(new_pk),
        "prev_fp": encode_b64url(old_pk), "next_fp": encode_b64url(new_pk),
        "reason": "key_rotation", "scope_unchanged": True,
    }
    fields = {
        "ver": "L8/1.0", "id": _uuid_from(bytes([7]) * 32), "sub": "agent://test-identity",
        "claim": {"type": "succession", "body": body},
        "ts_unix_ns": 1_800_000_000_000_000_000,
        "ts_rfc3339": "2026-09-25T00:00:00.000000000Z",
        "prev": None, "pk": encode_b64url(new_pk), "wit": [],
        "meta": {"sentinel": "test", "scope": "test", "env": "test"},
    }
    payload = signing_payload(fields, ("sig", "auth_sig", "wit"))
    fields["sig"] = encode_b64url(sign_reference(new_seed, payload))
    fields["auth_sig"] = encode_b64url(sign_reference(old_seed, payload))
    return canonical_encode(fields)


def test_valid_succession_is_accepted():
    b = build_succession(bytes([1]) * 32, bytes([2]) * 32)
    gate = Gate.new_verifying()
    result = gate.admit(b)
    assert isinstance(result, Admission.Accepted)
    assert gate.accepted_count() == 1


def test_corrupted_signature_is_rejected_and_preserved_in_the_failure_log():
    b = bytearray(build_succession(bytes([3]) * 32, bytes([4]) * 32))
    marker = b'"sig":"'
    start = bytes(b).find(marker) + len(marker)
    b[start + 2] ^= 0x01
    gate = Gate.new_verifying()
    result = gate.admit(bytes(b))
    assert isinstance(result, Admission.Rejected)
    assert result.seq == 0
    rec = next(gate.log.records())
    assert rec.kind.stage == "signature"
    assert rec.kind.code in (SigCode.SIGNATURE_INVALID, SigCode.AUTH_SIGNATURE_INVALID)
    assert gate.accepted_count() == 0


def test_non_canonical_json_is_rejected_at_the_wire_layer():
    gate = Gate.new()
    result = gate.admit(b'{ "a":1}')
    assert isinstance(result, Admission.Rejected)
    rec = next(gate.log.records())
    assert rec.kind.stage == "wire"
    assert rec.kind.code == "NonCanonicalWhitespace"


def test_missing_required_field_is_rejected_at_the_structure_layer():
    gate = Gate.new()
    result = gate.admit(canonical_encode({}))
    assert isinstance(result, Admission.Rejected)
    rec = next(gate.log.records())
    assert rec.kind.stage == "structure"
    assert rec.kind.code == "MissingField"


def _signer_and_cfg(seed: bytes, name: str):
    return ReferenceSigner(seed), EmitConfig(subject=f"agent://{name}", sentinel="test", scope="test", env="test")


def test_emitted_anomaly_attestations_pass_the_crate_own_verifying_gate():
    gate = Gate.new()
    gate.admit(b'{ "a":1}')
    gate.admit(canonical_encode({}))

    signer, cfg = _signer_and_cfg(bytes([9]) * 32, "emitter-test")
    emitter = Emitter(cfg, signer)
    batch = emitter.emit_pending(gate.log, 1_800_000_000_000_000_000)
    assert batch.error is None
    assert len(batch.attestations) == 2

    verifying = Gate.new_verifying()
    for att in batch.attestations:
        result = verifying.admit(att)
        assert isinstance(result, Admission.Accepted), f"expected acceptance, got {result}"


def test_checkpoint_round_trips_and_detects_truncation():
    gate = Gate.new()
    gate.admit(b'{ "a":1}')
    gate.admit(canonical_encode({}))

    emitter_seed = bytes([11]) * 32
    emitter_pk = public_key_from_seed(emitter_seed)
    signer, cfg = _signer_and_cfg(emitter_seed, "checkpoint-test")
    emitter = Emitter(cfg, signer)
    cp_bytes = emitter.emit_checkpoint(gate.log, 1_800_000_000_000_000_000)

    cp = parse_checkpoint(cp_bytes, emitter_pk)
    assert cp.total_rejected == 2

    full_snapshot = gate.log.snapshot()
    check_log_against_checkpoint(full_snapshot, cp)  # must not raise

    import dataclasses
    truncated_records = full_snapshot.records[:-1]
    truncated = dataclasses.replace(
        full_snapshot, records=truncated_records, next_seq=full_snapshot.next_seq - 1,
        head=truncated_records[-1].digest,
    )
    with pytest.raises(Exception, match="Truncated"):
        check_log_against_checkpoint(truncated, cp)

    stale = parse_checkpoint(cp_bytes, emitter_pk)
    check_freshness(stale, cp)  # identical checkpoint is not a rollback -- must not raise


def test_wire_and_structure_and_signature_codes_are_distinct_stages():
    # Basic sanity: three different rejection routes land in three different stages.
    gate = Gate.new_verifying()
    r1 = gate.admit(b'{ "a":1}')
    r2 = gate.admit(canonical_encode({}))
    b = bytearray(build_succession(bytes([5]) * 32, bytes([6]) * 32))
    marker = b'"sig":"'
    start = bytes(b).find(marker) + len(marker)
    b[start + 2] ^= 0x01
    r3 = gate.admit(bytes(b))
    assert all(isinstance(r, Admission.Rejected) for r in (r1, r2, r3))
    stages = [rec.kind.stage for rec in gate.log.records()]
    assert stages == ["wire", "structure", "signature"]
