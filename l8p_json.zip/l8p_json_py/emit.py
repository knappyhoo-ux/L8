"""
emit.py — H1.3/H1.4 emission: turn preserved failure records into signed
`anomaly` attestations, plus externally-anchored checkpoints. Python port
of the Rust `emit/{mod,checkpoint,time}.rs`.

Same PROPOSED status as the Rust side, carried over unchanged: only
digests leave the boundary (raw `capture` bytes stay in the local log);
the anomaly body shape has no ratified schema; `id` is derived from the
record digest (idempotent); `prev` chains emitted attestations by BLAKE3
of the previous attestation's full canonical bytes; timestamps are
caller-supplied (the log itself is clock-free).
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field
from typing import Optional

from l8p_json import blake3_hash, canonical_encode, decode, signing_payload
from failure import GENESIS, STAGE_SIGNATURE, STAGE_STRUCTURE, STAGE_WIRE, FailureLog, LogSnapshot
from verify import decode_b64url, encode_b64url


def rfc3339_from_unix_ns(ns: int) -> str:
    seconds, nanos = divmod(ns, 1_000_000_000)
    dt = _dt.datetime.fromtimestamp(seconds, tz=_dt.timezone.utc)
    return dt.strftime("%Y-%m-%dT%H:%M:%S") + f".{nanos:09d}Z"


def _uuid_from(d: bytes) -> str:
    b = bytearray(d[:16])
    b[6] = (b[6] & 0x0F) | 0x80
    b[8] = (b[8] & 0x3F) | 0x80
    h = b.hex()
    return f"{h[0:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:32]}"


class SignError(Exception):
    pass


class ReferenceSigner:
    """Test-only signer mirroring the Rust `reference-signer` feature."""
    def __init__(self, seed: bytes):
        from verify import public_key_from_seed
        self.seed = seed
        self.pk = public_key_from_seed(seed)

    def public_key(self) -> bytes:
        return self.pk

    def sign(self, msg: bytes) -> bytes:
        from verify import sign_reference
        return sign_reference(self.seed, msg)


@dataclass
class EmitConfig:
    subject: str
    sentinel: str
    scope: str
    env: str

    def validate(self) -> None:
        if not (1 <= len(self.subject.encode()) <= 256):
            raise ValueError("subject must be 1..=256 bytes")
        for s in (self.sentinel, self.scope, self.env):
            if len(s.encode()) > 4096:
                raise ValueError("meta strings limited to 4096 bytes")


@dataclass
class EmitBatch:
    attestations: list = field(default_factory=list)
    gaps: int = 0
    error: Optional[SignError] = None


_STAGE_LABEL = {STAGE_WIRE: "wire", STAGE_STRUCTURE: "structure", STAGE_SIGNATURE: "signature"}


class Emitter:
    def __init__(self, cfg: EmitConfig, signer):
        cfg.validate()
        self.cfg = cfg
        self.signer = signer
        self.next_seq = 0
        self.prev: Optional[str] = None

    def _build(self, att_id: str, body: dict, now_unix_ns: int) -> bytes:
        fields = {
            "ver": "L8/1.0",
            "id": att_id,
            "sub": self.cfg.subject,
            "claim": {"type": "anomaly", "body": body},
            "ts_unix_ns": now_unix_ns,
            "ts_rfc3339": rfc3339_from_unix_ns(now_unix_ns),
            "prev": self.prev,
            "pk": encode_b64url(self.signer.public_key()),
            "wit": [],
            "meta": {"sentinel": self.cfg.sentinel, "scope": self.cfg.scope, "env": self.cfg.env},
        }
        payload = signing_payload(fields, ("sig", "auth_sig", "wit"))
        sig = self.signer.sign(payload)
        fields["sig"] = encode_b64url(sig)
        body_bytes = canonical_encode(fields)
        self.prev = encode_b64url(blake3_hash(body_bytes))
        return body_bytes

    def _record_body(self, att_id: str, r) -> dict:
        """Ratified H1.2 anomaly shape: anomaly_id/category/severity/related_attestations/
        description/detected_by, plus this emitter's own forensic extras alongside (this
        crate's validate() doesn't reject unknown fields, so both coexist). A real fix this
        session: this body previously used an ad-hoc, non-ratified shape under the mistaken
        assumption that no spec existed for `anomaly` -- one did, already on hand."""
        stage = _STAGE_LABEL[r.kind.stage]
        return {
            "anomaly_id": att_id,
            "category": "input_rejected",
            "severity": "info",
            "related_attestations": [],
            "description": f"rejected input at {stage} stage: {r.kind.code}",
            "detected_by": self.cfg.subject,
            "hash": "blake3",
            "stage": stage,
            "code": r.kind.code,
            "seq": r.seq,
            "input_len": r.input_len,
            "input_digest": encode_b64url(r.input_digest),
            "record_digest": encode_b64url(r.digest),
            "prev_record_digest": encode_b64url(r.prev_digest),
        }

    def emit_checkpoint(self, log: FailureLog, now_unix_ns: int) -> bytes:
        head, total, evicted, anchor = log.head(), log.total_rejected(), log.evicted(), log.anchor()
        pre = head + total.to_bytes(8, "big") + evicted.to_bytes(8, "big") + (self.prev or "").encode()
        att_id = _uuid_from(blake3_hash(pre))
        body = {
            "anomaly_id": att_id,
            "category": "log_checkpoint",
            "severity": "info",
            "related_attestations": [],
            "description": f"log checkpoint: {total} total rejected, {evicted} evicted",
            "detected_by": self.cfg.subject,
            "hash": "blake3",
            "head_digest": encode_b64url(head),
            "total_rejected": total,
            "evicted": evicted,
            "anchor_digest": encode_b64url(anchor),
        }
        return self._build(att_id, body, now_unix_ns)

    def emit_pending(self, log: FailureLog, now_unix_ns: int) -> EmitBatch:
        out = EmitBatch()
        if self.next_seq < log.evicted():
            frm, to, anchor = self.next_seq, log.evicted(), log.anchor()
            pre = anchor + frm.to_bytes(8, "big") + to.to_bytes(8, "big")
            att_id = _uuid_from(blake3_hash(pre))
            body = {
                "anomaly_id": att_id,
                "category": "failure_gap",
                "severity": "warning",
                "related_attestations": [],
                "description": f"failure log evicted records {frm}..{to} before they could be emitted",
                "detected_by": self.cfg.subject,
                "hash": "blake3",
                "from_seq": frm, "to_seq": to, "anchor_digest": encode_b64url(anchor),
            }
            try:
                out.attestations.append(self._build(att_id, body, now_unix_ns))
                out.gaps += 1
                self.next_seq = to
            except SignError as e:
                out.error = e
                return out
        start = self.next_seq
        for r in log.records():
            if r.seq < start:
                continue
            try:
                rec_id = _uuid_from(r.digest)
                out.attestations.append(self._build(rec_id, self._record_body(rec_id, r), now_unix_ns))
                self.next_seq = r.seq + 1
            except SignError as e:
                out.error = e
                return out
        return out


def verify_emitted_chain(attestations: list) -> Optional[int]:
    """Returns the index of the first broken `prev` link, or None if the chain is intact.
    Signatures are NOT checked here -- use a verifying Gate for that."""
    expected: Optional[str] = None
    for i, e in enumerate(attestations):
        try:
            d = decode(e)
        except Exception:
            return i
        got = d.get("prev")
        if got != expected:
            return i
        expected = encode_b64url(blake3_hash(e))
    return None


# --- Checkpoints ---

class CheckpointError(Exception):
    pass


@dataclass(frozen=True)
class Checkpoint:
    head: bytes
    total_rejected: int
    evicted: int
    anchor: bytes
    ts_unix_ns: int
    emitter_pk: bytes


def parse_checkpoint(raw: bytes, expected_pk: bytes) -> Checkpoint:
    from attestation import validate
    from verify import verify_signatures

    try:
        d = decode(raw)
    except Exception as e:
        raise CheckpointError("Invalid") from e
    try:
        att = validate(d)
    except Exception as e:
        raise CheckpointError("Invalid") from e
    try:
        verify_signatures(d, att)
    except Exception as e:
        raise CheckpointError("Invalid") from e
    pk_bytes = decode_b64url(att.pk)
    if pk_bytes != expected_pk:
        raise CheckpointError("WrongKey")
    # `anomaly` is now a typed ClaimBody (ratified H1.2 shape) -- this crate's own emitter
    # populates the 6 required fields with category="log_checkpoint" for checkpoints, plus its
    # own forensic extras alongside, which AnomalyBody.raw still carries whole.
    if att.claim.claim_type != "anomaly" or att.claim.anomaly is None or att.claim.anomaly.category != "log_checkpoint":
        raise CheckpointError("NotACheckpoint")
    body = att.claim.anomaly.raw
    keys = {
        "anomaly_id", "category", "severity", "related_attestations", "description", "detected_by",
        "hash", "head_digest", "total_rejected", "evicted", "anchor_digest",
    }
    if set(body.keys()) != keys:
        raise CheckpointError("BadBody")
    if body.get("hash") != "blake3":
        raise CheckpointError("BadBody")
    try:
        head = decode_b64url(body["head_digest"])
        anchor = decode_b64url(body["anchor_digest"])
        total = body["total_rejected"]
        evicted = body["evicted"]
    except Exception as e:
        raise CheckpointError("BadBody") from e
    if len(head) != 32 or len(anchor) != 32:
        raise CheckpointError("BadBody")
    if not isinstance(total, int) or not isinstance(evicted, int) or evicted > total or total < 0 or evicted < 0:
        raise CheckpointError("BadBody")
    if total == 0 and (head != GENESIS or anchor != GENESIS or evicted != 0):
        raise CheckpointError("BadBody")
    return Checkpoint(head, total, evicted, anchor, att.ts_unix_ns, expected_pk)


def check_log_against_checkpoint(snap: LogSnapshot, cp: Checkpoint) -> None:
    snap.verify()  # raises LogError (LogInvalid-equivalent) on its own inconsistency
    if snap.next_seq < cp.total_rejected:
        raise CheckpointError("Truncated")
    if cp.total_rejected == 0:
        return
    if snap.evicted == cp.evicted and snap.anchor != cp.anchor:
        raise CheckpointError("HeadMismatch")
    last = cp.total_rejected - 1
    if last >= snap.evicted:
        idx = last - snap.evicted
        if idx < len(snap.records) and snap.records[idx].digest == cp.head:
            return
        raise CheckpointError("HeadMismatch")
    elif cp.total_rejected == snap.evicted:
        if snap.anchor == cp.head:
            return
        raise CheckpointError("HeadMismatch")
    raise CheckpointError("Unverifiable")


def check_freshness(prev: Optional[Checkpoint], new: Checkpoint) -> None:
    if prev is None:
        return
    if new.total_rejected < prev.total_rejected:
        raise CheckpointError("Rollback")
    if new.total_rejected == prev.total_rejected and new.head != prev.head:
        raise CheckpointError("Fork")
