"""
attestation.py — Python port of l8p_json's Rust `attestation.rs`.

Structural validation of a decoded canonical-JSON `Value` (here: plain
dict/list/str/int/bool/None from l8p_json.decode) as an L8/1.0
Attestation. Originally rebuilt fresh from the Rust source after an
earlier Python upload predated attestation.rs's existence; this revision
mirrors the Rust side's addition of the four other ratified H1.2 §3.1
typed claim bodies (identity, binding, null, anomaly) and the general
(non-revocation) `action` shape.

Same scope split as the Rust side: this checks presence/type of every
top-level field and dispatches the claim body. It does NOT check
signatures, `prev` chain linkage, witness validity, or Level.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional


class ValidationError(ValueError):
    def __init__(self, code: str, detail: str | None = None):
        self.code = code
        self.detail = detail
        msg = code if detail is None else f"{code}({detail!r})"
        super().__init__(msg)


def _get_str(v: dict, field: str) -> str:
    if field not in v:
        raise ValidationError("MissingField", field)
    x = v[field]
    if not isinstance(x, str):
        raise ValidationError("WrongType", field)
    return x


def _get_int(v: dict, field: str) -> int:
    if field not in v:
        raise ValidationError("MissingField", field)
    x = v[field]
    if not isinstance(x, int) or isinstance(x, bool):
        raise ValidationError("WrongType", field)
    return x


def _get_opt_str(v: dict, field: str) -> Optional[str]:
    if field not in v or v[field] is None:
        return None
    x = v[field]
    if not isinstance(x, str):
        raise ValidationError("WrongType", field)
    return x


def _get_bool(v: dict, field: str) -> bool:
    if field not in v:
        raise ValidationError("MissingField", field)
    x = v[field]
    if not isinstance(x, bool):
        raise ValidationError("WrongType", field)
    return x


def _get_list(v: dict, field: str) -> list:
    if field not in v:
        raise ValidationError("MissingField", field)
    x = v[field]
    if not isinstance(x, list):
        raise ValidationError("WrongType", field)
    return x


def _require(v: dict, field: str) -> Any:
    if field not in v:
        raise ValidationError("MissingField", field)
    return v[field]


REVOCATION_REASONS = ("user_request", "breach_response", "legal_order", "scheduled_expiration")
SUCCESSION_REASONS = ("key_rotation", "algorithm_migration", "compromise_recovery", "scheduled_evolution")
IDENTITY_KINDS = ("human", "machine", "agent")
KNOWN_CLAIM_TYPES = ("identity", "binding", "action", "null", "anomaly", "succession", "deployment", "witness")


@dataclass(frozen=True)
class IdentityRevocationBody:
    subject: str
    reason: str
    revoked_at: str
    effective_at: str
    authorized_by: str
    replaced_by: Optional[str]


def _parse_identity_revocation(body: dict) -> IdentityRevocationBody:
    reason = _get_str(body, "reason")
    if reason not in REVOCATION_REASONS:
        raise ValidationError("UnknownRevocationReason", reason)
    return IdentityRevocationBody(
        subject=_get_str(body, "subject"),
        reason=reason,
        revoked_at=_get_str(body, "revoked_at"),
        effective_at=_get_str(body, "effective_at"),
        authorized_by=_get_str(body, "authorized_by"),
        replaced_by=_get_opt_str(body, "replaced_by"),
    )


@dataclass(frozen=True)
class GeneralActionBody:
    """The general (non-revocation) `action` shape, per the ratified H1.2 spec §3.1:
    action_id, category, resource, params (Map), result."""
    action_id: str
    category: str
    resource: str
    params: dict
    result: Any
    raw: dict


def _try_parse_general_action(body: dict) -> Optional[GeneralActionBody]:
    try:
        action_id = _get_str(body, "action_id")
        category = _get_str(body, "category")
        resource = _get_str(body, "resource")
        params = body.get("params")
        if "params" not in body or not isinstance(params, dict):
            return None
        result = _require(body, "result")
        return GeneralActionBody(action_id, category, resource, params, result, body)
    except ValidationError:
        return None


@dataclass(frozen=True)
class ActionBody:
    """The ratified spec names exactly two `action` shapes -- identity_revocation, or the
    general shape -- but a real action_type the spec doesn't yet name won't carry the general
    shape's five required fields either. Mirrors the Rust side's graceful fallback (established
    by that side's already-shipped att_03 test): try General first, fall back to untyped `raw`
    only when it doesn't match AT ALL."""
    action_type: Optional[str]
    identity_revocation: Optional[IdentityRevocationBody] = None
    general: Optional[GeneralActionBody] = None
    raw: Optional[dict] = None


def _parse_action(body: dict) -> ActionBody:
    action_type = _get_opt_str(body, "action_type")
    if action_type == "identity_revocation":
        return ActionBody(action_type, identity_revocation=_parse_identity_revocation(body))
    general = _try_parse_general_action(body)
    if general is not None:
        return ActionBody(action_type, general=general)
    return ActionBody(action_type, raw=body)


@dataclass(frozen=True)
class SuccessionBody:
    prev_pk: str
    next_pk: str
    prev_fp: str
    next_fp: str
    reason: str
    scope_unchanged: bool


def _parse_succession(body: dict) -> SuccessionBody:
    reason = _get_str(body, "reason")
    if reason not in SUCCESSION_REASONS:
        raise ValidationError("UnknownSuccessionReason", reason)
    return SuccessionBody(
        prev_pk=_get_str(body, "prev_pk"),
        next_pk=_get_str(body, "next_pk"),
        prev_fp=_get_str(body, "prev_fp"),
        next_fp=_get_str(body, "next_fp"),
        reason=reason,
        scope_unchanged=_get_bool(body, "scope_unchanged"),
    )


@dataclass(frozen=True)
class IdentityBody:
    """Per the ratified H1.2 spec §3.1: uuid, pk, kind (human|machine|agent),
    delegate_of (Null or TextString), scope."""
    uuid: str
    pk: str
    kind: str
    delegate_of: Optional[str]
    scope: str


def _parse_identity(body: dict) -> IdentityBody:
    kind = _get_str(body, "kind")
    if kind not in IDENTITY_KINDS:
        raise ValidationError("UnknownIdentityKind", kind)
    return IdentityBody(
        uuid=_get_str(body, "uuid"), pk=_get_str(body, "pk"), kind=kind,
        delegate_of=_get_opt_str(body, "delegate_of"), scope=_get_str(body, "scope"),
    )


@dataclass(frozen=True)
class BindingBody:
    """Per the ratified H1.2 spec §3.1: uuid, pk, binding_sig."""
    uuid: str
    pk: str
    binding_sig: str


def _parse_binding(body: dict) -> BindingBody:
    return BindingBody(uuid=_get_str(body, "uuid"), pk=_get_str(body, "pk"), binding_sig=_get_str(body, "binding_sig"))


@dataclass(frozen=True)
class NullBody:
    """Per the ratified H1.2 spec §3.1: interval_start, interval_end, reason.
    No enum constraint on `reason` is given (unlike succession/revocation)."""
    interval_start: str
    interval_end: str
    reason: str


def _parse_null(body: dict) -> NullBody:
    return NullBody(
        interval_start=_get_str(body, "interval_start"),
        interval_end=_get_str(body, "interval_end"),
        reason=_get_str(body, "reason"),
    )


@dataclass(frozen=True)
class AnomalyBody:
    """Per the ratified H1.2 spec §3.1: anomaly_id, category, severity,
    related_attestations (Array), description, detected_by. No enum constraint given for
    category/severity. This is also the shape H1.3's own emitter produces (emit.py) -- a real
    gap found and fixed this session: the emitter originally used an ad-hoc shape under the
    mistaken, unchecked assumption that no ratified schema existed for `anomaly`."""
    anomaly_id: str
    category: str
    severity: str
    related_attestations: list
    description: str
    detected_by: str
    raw: dict


def _parse_anomaly(body: dict) -> AnomalyBody:
    related = _get_list(body, "related_attestations")
    for item in related:
        if not isinstance(item, str):
            raise ValidationError("WrongType", "related_attestations")
    return AnomalyBody(
        anomaly_id=_get_str(body, "anomaly_id"), category=_get_str(body, "category"),
        severity=_get_str(body, "severity"), related_attestations=list(related),
        description=_get_str(body, "description"), detected_by=_get_str(body, "detected_by"),
        raw=body,
    )


@dataclass(frozen=True)
class ClaimBody:
    """Six of the eight ratified H1.2 §3.1 claim-type shapes are typed: identity, binding,
    action, null, anomaly, succession. `deployment` and `witness` stay untyped (`raw` only) --
    the spec itself marks those two rows TBD, deliberately, not guessed at."""
    claim_type: str
    identity: Optional[IdentityBody] = None
    binding: Optional[BindingBody] = None
    action: Optional[ActionBody] = None
    null: Optional[NullBody] = None
    anomaly: Optional[AnomalyBody] = None
    succession: Optional[SuccessionBody] = None
    raw: Any = None  # populated for untyped claim types (deployment, witness)


def _parse_claim(claim: dict) -> ClaimBody:
    ctype = _get_str(claim, "type")
    if ctype not in KNOWN_CLAIM_TYPES:
        raise ValidationError("UnknownClaimType", ctype)
    if "body" not in claim:
        raise ValidationError("MissingClaimField", "body")
    body = claim["body"]
    if not isinstance(body, dict):
        raise ValidationError("ClaimNotAnObject")
    if ctype == "identity":
        return ClaimBody(ctype, identity=_parse_identity(body))
    if ctype == "binding":
        return ClaimBody(ctype, binding=_parse_binding(body))
    if ctype == "action":
        return ClaimBody(ctype, action=_parse_action(body))
    if ctype == "null":
        return ClaimBody(ctype, null=_parse_null(body))
    if ctype == "anomaly":
        return ClaimBody(ctype, anomaly=_parse_anomaly(body))
    if ctype == "succession":
        return ClaimBody(ctype, succession=_parse_succession(body))
    return ClaimBody(ctype, raw=body)


@dataclass(frozen=True)
class Attestation:
    ver: str
    id: str
    sub: str
    claim: ClaimBody
    ts_unix_ns: int
    ts_rfc3339: str
    prev: Optional[str]
    sig: str
    auth_sig: Optional[str]
    pk: str
    wit: list
    meta: Any


def validate(v: Any) -> Attestation:
    if not isinstance(v, dict):
        raise ValidationError("NotAnObject")
    if "claim" not in v:
        raise ValidationError("MissingField", "claim")
    claim_val = v["claim"]
    if not isinstance(claim_val, dict):
        raise ValidationError("WrongType", "claim")
    wit_val = v.get("wit", [])
    if not isinstance(wit_val, list):
        raise ValidationError("WrongType", "wit")
    return Attestation(
        ver=_get_str(v, "ver"),
        id=_get_str(v, "id"),
        sub=_get_str(v, "sub"),
        claim=_parse_claim(claim_val),
        ts_unix_ns=_get_int(v, "ts_unix_ns"),
        ts_rfc3339=_get_str(v, "ts_rfc3339"),
        prev=_get_opt_str(v, "prev"),
        sig=_get_str(v, "sig"),
        auth_sig=_get_opt_str(v, "auth_sig"),
        pk=_get_str(v, "pk"),
        wit=list(wit_val),
        meta=v.get("meta", {}),
    )
