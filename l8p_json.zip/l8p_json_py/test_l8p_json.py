"""
Adversarial test suite for l8p_json.py, mirroring tests/adversarial.rs in
the Rust crate case-for-case (same numbering scheme, JSON-NN) so the two
suites can be diffed against each other over time. Run with: pytest -q
"""
import pytest
import l8p_json as j


def decode_ok(b):
    return j.decode(b)


def decode_err(b):
    with pytest.raises(j.CanonicalJSONError) as ei:
        j.decode(b)
    return ei.value.code


# ---- JSON-01..08 ----

def test_json_01_accepts_minimal_object():
    assert decode_ok(b'{"a":1,"b":null}') == {"a": 1, "b": None}


@pytest.mark.parametrize("case", [
    b'{ "a":1}', b'{"a": 1}', b'{"a":1 }', b'[1, 2]', b' [1,2]',
])
def test_json_02_rejects_any_whitespace(case):
    assert decode_err(case) == "NonCanonicalWhitespace"


def test_json_03_rejects_duplicate_keys():
    assert decode_err(b'{"a":1,"a":2}') == "DuplicateKey"


def test_json_04_rejects_out_of_order_keys():
    assert decode_err(b'{"b":1,"a":2}') == "NonCanonicalKeyOrder"


@pytest.mark.parametrize("case", [b"01", b"-01", b"[01]"])
def test_json_05_rejects_leading_zero(case):
    assert decode_err(case) == "InvalidNumber"


def test_json_06_rejects_negative_zero():
    assert decode_err(b"-0") == "InvalidNumber"


@pytest.mark.parametrize("case", [b"1.5", b"1e10", b"1E10", b"[1.0]"])
def test_json_07_rejects_floats(case):
    assert decode_err(case) == "FloatNotAllowed"


def test_json_08_rejects_trailing_bytes():
    assert decode_err(b"1 ") == "TrailingBytes"
    assert decode_err(b"1junk") == "TrailingBytes"


# ---- JSON-09..15: string escaping canonicality ----

def test_json_09_rejects_escaped_solidus():
    assert decode_err(b'"\\/"') == "NonCanonicalEscape"


def test_json_10_rejects_unnecessary_unicode_escape():
    assert decode_err(b'"\\u0041"') == "NonCanonicalEscape"


def test_json_11_rejects_non_minimal_control_escape():
    assert decode_err(b'"\\u000a"') == "NonCanonicalEscape"


def test_json_12_accepts_minimal_control_escape_and_rejects_literal_control():
    assert decode_ok(b'"\\n"') == "\n"
    assert decode_err(b'"\x01"') == "UnescapedControlChar"


def test_json_13_accepts_required_short_form_for_uncommon_control_code():
    assert decode_ok(b'"\\u0001"') == "\u0001"


def test_json_14_rejects_surrogate_pair_as_noncanonical():
    assert decode_err(b'"\\ud83d\\ude00"') == "NonCanonicalEscape"


def test_json_15_rejects_lone_low_surrogate():
    assert decode_err(b'"\\udc00"') == "InvalidEscape"


# ---- JSON-21: truncation at every prefix, deterministic, never crashes with
# anything other than CanonicalJSONError ----

def test_json_21_truncation_at_every_prefix_never_crashes_and_is_determinate():
    full = b'{"a":1,"b":[2,3],"c":"x\\n"}'
    for i in range(len(full)):
        prefix = full[:i]
        try:
            r1 = decode_ok(prefix)
            pytest.fail(f"prefix len {i} unexpectedly decoded: {r1!r}")
        except j.CanonicalJSONError as e1:
            code1 = e1.code
        try:
            decode_ok(prefix)
            pytest.fail("nondeterministic: second decode succeeded")
        except j.CanonicalJSONError as e2:
            assert e2.code == code1, f"nondeterministic result at prefix len {i}"
    assert decode_ok(full) == {"a": 1, "b": [2, 3], "c": "x\n"}


# ---- JSON-22: single-byte mutation fuzz, never an uncaught exception ----

def test_json_22_single_byte_mutation_never_crashes_uncontrolled():
    full = bytearray(b'{"a":1,"b":[2,3],"c":"xy"}')
    for i in range(len(full)):
        for delta in (1, 37, 129, 255):
            mutated = bytearray(full)
            mutated[i] = (mutated[i] + delta) % 256
            try:
                j.decode(bytes(mutated))
            except j.CanonicalJSONError:
                pass
            # any other exception type is a real bug -> let it fail the test


# ---- JSON-23: deterministic PRNG fuzz over short random inputs ----

def test_json_23_prng_fuzz_no_uncontrolled_crashes():
    state = 0x9E3779B9

    def next_u32():
        nonlocal state
        state ^= (state << 13) & 0xFFFFFFFF
        state ^= (state >> 17)
        state ^= (state << 5) & 0xFFFFFFFF
        state &= 0xFFFFFFFF
        return state

    for _ in range(3000):
        length = next_u32() % 40
        data = bytes(next_u32() % 256 for _ in range(length))
        try:
            j.decode(data)
        except j.CanonicalJSONError:
            pass


# ---- JSON-24: canonical round trip ----

@pytest.mark.parametrize("case", [
    b'{"a":1,"b":[true,false,null],"c":"line\\n\\u0001"}',
    b'[]', b'{}', b'"hello world"', b'-123456789', b'0',
])
def test_json_24_decode_then_encode_round_trips_byte_identical(case):
    v = decode_ok(case)
    assert j.canonical_encode(v) == case


def test_json_25_encoder_sorts_keys_regardless_of_construction_order():
    v = {"z": 1, "a": 2}
    encoded = j.canonical_encode(v)
    assert encoded == b'{"a":2,"z":1}'
    assert decode_ok(encoded) == {"a": 2, "z": 1}


# ---- JSON-26..28: signing payload ----

def test_json_26_signing_payload_excludes_named_keys_and_is_deterministic():
    a = decode_ok(b'{"claim":1,"sig":"AAAA","wit":[]}')
    b = decode_ok(b'{"claim":1,"sig":"BBBB","wit":["x"]}')
    ha = j.signing_payload(a, {"sig", "auth_sig", "wit"})
    hb = j.signing_payload(b, {"sig", "auth_sig", "wit"})
    assert ha == hb
    c = decode_ok(b'{"claim":2,"sig":"AAAA","wit":[]}')
    hc = j.signing_payload(c, {"sig", "auth_sig", "wit"})
    assert ha != hc


def test_json_27_signing_payload_matches_direct_blake3_of_stripped_bytes():
    full = decode_ok(b'{"a":1,"sig":"AAAA"}')
    stripped_bytes = j.canonical_encode(decode_ok(b'{"a":1}'))
    expected = j.blake3_hash(stripped_bytes)
    got = j.signing_payload(full, {"sig", "auth_sig", "wit"})
    assert got == expected


def test_json_28_signing_payload_rejects_non_object():
    v = decode_ok(b"[1,2,3]")
    with pytest.raises(TypeError):
        j.signing_payload(v, {"sig"})


def test_json_30_repeated_decode_is_deterministic():
    data = b'{"a":[1,2,3],"b":{"c":null,"d":true}}'
    assert decode_ok(data) == decode_ok(data)


# ---- Cross-language fixed vector: same bytes and hash the Rust suite
# produced in the live interop check, pinned here so a future change to
# either side that breaks parity fails loudly and immediately. ----

def test_json_31_pinned_cross_language_vector_matches_rust():
    att = {
        "ver": "L8/1.0", "id": "a1", "sub": "agent-a",
        "claim": {"type": "succession", "body": {
            "prev_pk": "ppk", "next_pk": "npk", "prev_fp": "pf", "next_fp": "nf",
            "reason": "key_rotation", "scope_unchanged": True,
        }},
        "ts_unix_ns": 1758757200000000000, "ts_rfc3339": "2026-09-24T00:00:00Z",
        "prev": "blk0", "sig": "sigX", "pk": "newpk", "wit": ["w1"],
        "meta": {"sentinel": "s1", "scope": "global", "env": "prod"},
    }
    encoded = j.canonical_encode(att)
    assert encoded == (
        b'{"claim":{"body":{"next_fp":"nf","next_pk":"npk","prev_fp":"pf",'
        b'"prev_pk":"ppk","reason":"key_rotation","scope_unchanged":true},'
        b'"type":"succession"},"id":"a1","meta":{"env":"prod","scope":"global",'
        b'"sentinel":"s1"},"pk":"newpk","prev":"blk0","sig":"sigX","sub":"agent-a",'
        b'"ts_rfc3339":"2026-09-24T00:00:00Z","ts_unix_ns":1758757200000000000,'
        b'"ver":"L8/1.0","wit":["w1"]}'
    )
    payload = j.signing_payload(att, {"sig", "auth_sig", "wit"})
    assert payload.hex() == "1a70309fc04224fe845339272a44d5313d6fa0448fc6f5d5ac2fb2ef8d9a97a9"
