"""
failure.py — H1.3 failure-preserving log + admission gate, Python port of the
Rust `failure/{record,log,gate}.rs`. Same design: every rejected input is
preserved (bounded-capture, hash-chained), nothing is ever dropped silently
-- eviction is accounted for via `anchor`/`evicted`, not deletion.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, replace
from typing import Optional

from l8p_json import CanonicalJSONError, blake3_hash, decode
from attestation import ValidationError, validate
from verify import SigError, verify_signatures

GENESIS = bytes(32)

STAGE_WIRE, STAGE_STRUCTURE, STAGE_SIGNATURE = "wire", "structure", "signature"


@dataclass(frozen=True)
class FailureKind:
    stage: str
    code: str  # e.g. "TruncatedInput", "MissingField", "SIGNATURE_INVALID"

    @staticmethod
    def wire(e: CanonicalJSONError) -> "FailureKind":
        return FailureKind(STAGE_WIRE, e.code)

    @staticmethod
    def structure(e: ValidationError) -> "FailureKind":
        return FailureKind(STAGE_STRUCTURE, e.code)

    @staticmethod
    def signature(e: SigError) -> "FailureKind":
        return FailureKind(STAGE_SIGNATURE, e.code)


@dataclass(frozen=True)
class FailureRecord:
    seq: int
    kind: FailureKind
    input_len: int
    input_digest: bytes
    capture: bytes
    prev_digest: bytes
    digest: bytes

    def digest_preimage(self) -> bytes:
        out = bytearray()
        out.append(1)  # layout version
        out += self.seq.to_bytes(8, "big")
        code_bytes = f"{self.kind.stage}:{self.kind.code}".encode("utf-8")
        out += len(code_bytes).to_bytes(4, "big")
        out += code_bytes
        out += self.input_len.to_bytes(8, "big")
        out += self.input_digest
        out += len(self.capture).to_bytes(4, "big")
        out += self.capture
        out += self.prev_digest
        return bytes(out)

    def compute_digest(self) -> bytes:
        return blake3_hash(self.digest_preimage())


class LogError(Exception):
    pass


@dataclass
class LogSnapshot:
    records: list
    anchor: bytes
    evicted: int
    head: bytes
    next_seq: int

    def verify(self) -> None:
        if self.next_seq != self.evicted + len(self.records):
            raise LogError("CountMismatch")
        prev = self.anchor
        for i, r in enumerate(self.records):
            if r.seq != self.evicted + i:
                raise LogError(f"SeqGap@{i}")
            if r.prev_digest != prev:
                raise LogError(f"ChainBroken@{i}")
            if r.compute_digest() != r.digest:
                raise LogError(f"DigestMismatch@{i}")
            prev = r.digest
        if prev != self.head:
            raise LogError("HeadMismatch")

    def verify_against_head(self, expected_head: bytes) -> None:
        self.verify()
        if self.head != expected_head:
            raise LogError("HeadMismatch")


@dataclass
class LogConfig:
    max_records: int = 1024
    max_capture: int = 64


class FailureLog:
    def __init__(self, cfg: Optional[LogConfig] = None):
        self.cfg = cfg or LogConfig()
        if self.cfg.max_records <= 0:
            self.cfg.max_records = 1
        self._records: deque[FailureRecord] = deque()
        self._next_seq = 0
        self._head = GENESIS
        self._anchor = GENESIS
        self._evicted = 0

    def record(self, kind: FailureKind, raw_input: bytes) -> int:
        seq = self._next_seq
        cap = min(self.cfg.max_capture, len(raw_input))
        rec = FailureRecord(
            seq=seq, kind=kind, input_len=len(raw_input),
            input_digest=blake3_hash(raw_input), capture=bytes(raw_input[:cap]),
            prev_digest=self._head, digest=GENESIS,
        )
        rec = replace(rec, digest=rec.compute_digest())
        self._head = rec.digest
        self._next_seq += 1
        self._records.append(rec)
        while len(self._records) > self.cfg.max_records:
            old = self._records.popleft()
            self._anchor = old.digest
            self._evicted += 1
        return seq

    def retained(self) -> int: return len(self._records)
    def evicted(self) -> int: return self._evicted
    def total_rejected(self) -> int: return self._next_seq
    def head(self) -> bytes: return self._head
    def anchor(self) -> bytes: return self._anchor
    def records(self): return iter(self._records)

    def snapshot(self) -> LogSnapshot:
        return LogSnapshot(list(self._records), self._anchor, self._evicted, self._head, self._next_seq)

    def verify(self) -> None:
        self.snapshot().verify()


class Admission:
    @dataclass(frozen=True)
    class Accepted:
        attestation: object

    @dataclass(frozen=True)
    class Rejected:
        seq: int


class Gate:
    """`verify_sigs=False`: structural admission only. `True`: also H1.4 signature checks."""
    def __init__(self, verify_sigs: bool, log_cfg: Optional[LogConfig] = None):
        self.verify_sigs = verify_sigs
        self.log = FailureLog(log_cfg)
        self._accepted = 0

    @staticmethod
    def new(log_cfg: Optional[LogConfig] = None) -> "Gate":
        return Gate(False, log_cfg)

    @staticmethod
    def new_verifying(log_cfg: Optional[LogConfig] = None) -> "Gate":
        return Gate(True, log_cfg)

    def admit(self, raw_input: bytes):
        try:
            decoded = decode(raw_input)
        except CanonicalJSONError as e:
            seq = self.log.record(FailureKind.wire(e), raw_input)
            return Admission.Rejected(seq)
        try:
            att = validate(decoded)
        except ValidationError as e:
            seq = self.log.record(FailureKind.structure(e), raw_input)
            return Admission.Rejected(seq)
        if self.verify_sigs:
            try:
                verify_signatures(decoded, att)
            except SigError as e:
                seq = self.log.record(FailureKind.signature(e), raw_input)
                return Admission.Rejected(seq)
        self._accepted += 1
        return Admission.Accepted(att)

    def accepted_count(self) -> int:
        return self._accepted
