"""
verify.py — H1.4 signature verification, Python side.

Signing payload: BLAKE3 over the canonical JSON encoding of the attestation
object with sig/auth_sig/wit removed (l8p_json.signing_payload). Both `sig`
and (for succession) `auth_sig` sign that same digest.

Unlike the Rust crate (which hand-rolls Ed25519 to stay zero-dependency),
this companion module uses the `cryptography` package for the actual curve
arithmetic. That's a deliberate difference, not a shortcut: hand-rolling
Ed25519 point arithmetic in pure Python buys no protocol-specific rigor
(unlike the canonical-JSON grammar, which IS the thing under test) and
would just be slower, unaudited duplicate code for a well-specified
primitive with a vetted implementation already available.
"""
from __future__ import annotations

import base64
from dataclasses import dataclass
from typing import Optional

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

from l8p_json import signing_payload
from attestation import Attestation


class SigCode:
    BAD_ENCODING = "BAD_ENCODING"
    BAD_KEY_LENGTH = "BAD_KEY_LENGTH"
    BAD_SIG_LENGTH = "BAD_SIG_LENGTH"
    KEY_MISMATCH = "KEY_MISMATCH"
    SIGNATURE_INVALID = "SIGNATURE_INVALID"
    MISSING_AUTH_SIG = "MISSING_AUTH_SIG"
    AUTH_SIGNATURE_INVALID = "AUTH_SIGNATURE_INVALID"


@dataclass(frozen=True)
class SigError(Exception):
    code: str
    path: str


def decode_b64url(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    try:
        return base64.urlsafe_b64decode(s + pad)
    except Exception as e:
        raise SigError(SigCode.BAD_ENCODING, "") from e


def encode_b64url(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


def _key(s: str, path: str) -> bytes:
    b = decode_b64url(s)
    if len(b) != 32:
        raise SigError(SigCode.BAD_KEY_LENGTH, path)
    return b


def _sig(s: str, path: str) -> bytes:
    b = decode_b64url(s)
    if len(b) != 64:
        raise SigError(SigCode.BAD_SIG_LENGTH, path)
    return b


def _ed_verify(pk: bytes, msg: bytes, sig: bytes) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(pk).verify(sig, msg)
        return True
    except InvalidSignature:
        return False
    except Exception:
        return False


EXCLUDED = ("sig", "auth_sig", "wit")


def verify_signatures(decoded: dict, att: Attestation) -> None:
    """Raises SigError on failure; returns None on success."""
    pk = _key(att.pk, "pk")
    sg = _sig(att.sig, "sig")
    payload = signing_payload(decoded, EXCLUDED)
    if att.claim.claim_type == "succession":
        s = att.claim.succession
        prev_pk = _key(s.prev_pk, "claim.body.prev_pk")
        next_pk = _key(s.next_pk, "claim.body.next_pk")
        if next_pk != pk:
            raise SigError(SigCode.KEY_MISMATCH, "claim.body.next_pk")
        if not _ed_verify(pk, payload, sg):
            raise SigError(SigCode.SIGNATURE_INVALID, "sig")
        if att.auth_sig is None:
            raise SigError(SigCode.MISSING_AUTH_SIG, "auth_sig")
        auth = _sig(att.auth_sig, "auth_sig")
        if not _ed_verify(prev_pk, payload, auth):
            raise SigError(SigCode.AUTH_SIGNATURE_INVALID, "auth_sig")
        return
    if not _ed_verify(pk, payload, sg):
        raise SigError(SigCode.SIGNATURE_INVALID, "sig")


# --- reference signer, for tests only (mirrors Rust's `reference-signer` feature) ---

def public_key_from_seed(seed: bytes) -> bytes:
    from cryptography.hazmat.primitives import serialization
    priv = Ed25519PrivateKey.from_private_bytes(seed)
    return priv.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)


def sign_reference(seed: bytes, msg: bytes) -> bytes:
    priv = Ed25519PrivateKey.from_private_bytes(seed)
    return priv.sign(msg)
