import pytest

from l8p_json import decode, Limits
from attestation import ActionBody, ValidationError, validate


def _wrap(ctype: str, body: dict) -> bytes:
    import json as _json
    obj = {
        "claim": {"body": body, "type": ctype}, "id": "a", "meta": {}, "pk": "pk", "prev": None,
        "sig": "s", "sub": "agent", "ts_rfc3339": "t", "ts_unix_ns": 0, "ver": "L8/1.0", "wit": [],
    }
    # not canonical JSON (dict insertion order, not sorted) -- fine, we decode with the real
    # canonical encoder instead of hand-building bytes, mirroring how the rest of this suite does it.
    from l8p_json import canonical_encode
    return canonical_encode(obj)


def test_still_unestablished_claim_bodies_stay_untyped_not_guessed():
    for ctype in ("deployment", "witness"):
        v = decode(_wrap(ctype, {"whatever": 1}))
        att = validate(v)
        assert att.claim.claim_type == ctype
        assert att.claim.raw == {"whatever": 1}


def test_now_typed_claim_bodies_reject_a_non_conforming_minimal_body():
    for ctype in ("identity", "binding", "null", "anomaly"):
        v = decode(_wrap(ctype, {"whatever": 1}))
        with pytest.raises(ValidationError) as ei:
            validate(v)
        assert ei.value.code == "MissingField"


def test_minimal_conforming_bodies_validate_with_typed_shapes():
    cases = {
        "identity": {"delegate_of": None, "kind": "human", "pk": "pk", "scope": "s", "uuid": "u"},
        "binding": {"binding_sig": "bs", "pk": "pk", "uuid": "u"},
        "null": {"interval_end": "e", "interval_start": "s", "reason": "r"},
        "anomaly": {"anomaly_id": "aid", "category": "c", "description": "d", "detected_by": "db",
                    "related_attestations": [], "severity": "info"},
    }
    for ctype, body in cases.items():
        v = decode(_wrap(ctype, body))
        att = validate(v)
        assert getattr(att.claim, ctype) is not None, f"{ctype} should be typed"


def test_identity_rejects_unknown_kind():
    v = decode(_wrap("identity", {"delegate_of": None, "kind": "robot", "pk": "pk", "scope": "s", "uuid": "u"}))
    with pytest.raises(ValidationError) as ei:
        validate(v)
    assert ei.value.code == "UnknownIdentityKind"
    assert ei.value.detail == "robot"


def test_general_action_body_types_when_shape_matches():
    body = {"action_id": "aid", "category": "c", "params": {}, "resource": "r", "result": None}
    v = decode(_wrap("action", body))
    att = validate(v)
    assert isinstance(att.claim.action, ActionBody)
    assert att.claim.action.general is not None
    assert att.claim.action.general.action_id == "aid"
    assert att.claim.action.general.resource == "r"


def test_other_action_type_still_falls_back_to_untyped_when_general_shape_absent():
    v = decode(_wrap("action", {"action_type": "some_future_action", "x": 1}))
    att = validate(v)
    assert att.claim.action.general is None
    assert att.claim.action.identity_revocation is None
    assert att.claim.action.raw == {"action_type": "some_future_action", "x": 1}
