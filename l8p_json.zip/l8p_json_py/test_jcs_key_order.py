from l8p_json import CanonicalJSONError, Limits, canonical_encode, decode
import pytest

SUPP = "\U00010000"    # encodes to UTF-16 surrogate pair [0xD800, 0xDC00]
BMP_HIGH = "\uE000"    # encodes to a single UTF-16 unit 0xE000


def test_utf16_order_genuinely_diverges_from_utf8_byte_order_for_this_pair():
    byte_order = SUPP.encode("utf-8") > BMP_HIGH.encode("utf-8")
    utf16_order = SUPP.encode("utf-16-be") < BMP_HIGH.encode("utf-16-be")
    assert byte_order, "UTF-8 byte order: SUPP > BMP_HIGH"
    assert utf16_order, "UTF-16 code-unit order: SUPP < BMP_HIGH (the actual divergence)"


def test_encoder_sorts_keys_in_jcs_utf16_order_not_byte_order():
    encoded = canonical_encode({BMP_HIGH: 2, SUPP: 1})
    text = encoded.decode("utf-8")
    assert text.index(SUPP) < text.index(BMP_HIGH), f"expected SUPP key first under JCS order, got: {text!r}"


def test_decoder_accepts_jcs_order_and_rejects_byte_order_for_the_same_pair():
    jcs_order_bytes = canonical_encode({SUPP: 1, BMP_HIGH: 2})
    decode(jcs_order_bytes)  # must not raise

    byte_order_bytes = ('{"' + BMP_HIGH + '":2,"' + SUPP + '":1}').encode("utf-8")
    with pytest.raises(CanonicalJSONError) as ei:
        decode(byte_order_bytes)
    assert ei.value.code == "NonCanonicalKeyOrder"


def test_round_trip_still_holds_for_ascii_only_keys():
    encoded = canonical_encode({"ver": "L8/1.0", "id": "x", "sub": "agent://x"})
    assert canonical_encode(decode(encoded)) == encoded
