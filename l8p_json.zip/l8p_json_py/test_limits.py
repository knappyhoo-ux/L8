import pytest

from l8p_json import CanonicalJSONError, Limits, decode


def _err_code(data: bytes, limits: Limits) -> str:
    with pytest.raises(CanonicalJSONError) as ei:
        decode(data, limits)
    return ei.value.code


def test_json_16_rejects_depth_beyond_limit():
    l = Limits(max_depth=3)
    assert decode(b"[[[1]]]", l) == [[[1]]]  # depth 3, ok
    assert _err_code(b"[[[[1]]]]", l) == "DepthLimitExceeded"  # depth 4


def test_json_17_rejects_array_beyond_element_limit():
    l = Limits(max_array_elems=2)
    assert decode(b"[1,2]", l) == [1, 2]
    assert _err_code(b"[1,2,3]", l) == "ArrayTooLong"


def test_json_18_rejects_object_beyond_entry_limit():
    l = Limits(max_object_entries=1)
    assert decode(b'{"a":1}', l) == {"a": 1}
    assert _err_code(b'{"a":1,"b":2}', l) == "ObjectTooLong"


def test_json_19_rejects_input_beyond_total_size_budget():
    l = Limits(max_total_bytes=4)
    assert _err_code(b"[1,2]", l) == "InputTooLarge"


def test_json_20_rejects_string_beyond_length_limit():
    l = Limits(max_string_bytes=4)
    assert _err_code(b'"abcdefgh"', l) == "StringTooLong"


def test_default_limits_accept_ordinary_input():
    assert decode(b'{"a":[1,2,3],"b":"hello"}') == {"a": [1, 2, 3], "b": "hello"}


def test_number_out_of_range_beyond_i64():
    # i64::MAX = 9223372036854775807; one more digit's worth over is rejected so both
    # language sides agree on the same representable integer range.
    assert decode(b"9223372036854775807") == 9223372036854775807
    assert _err_code(b"99999999999999999999", Limits()) == "NumberOutOfRange"
    assert _err_code(b"-99999999999999999999", Limits()) == "NumberOutOfRange"
